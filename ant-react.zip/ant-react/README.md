# ANT — Move materials. Keep work moving.

A mobile-first material-request app for electrical construction. Field crews
(Foreman, Journeyman, Apprentice) request materials for a job site; the
warehouse (Manager, Worker) picks, packs, and ships them.

This is the React version of the original single-file ANT prototype.

## What's included

Everything from the original single-file prototype, rebuilt in React:

- **Field (Foreman, Journeyman, Apprentice):** login and new profile, Home with search, 32-area catalog with 324 configurable product families, Material Request, request details and submit, My Orders, Quick Reorder, Save as Job Kit, Job Kits and Create Job Kit, Projects with Overview / Materials / Orders / Deliveries / Team, team permissions, delivery confirmation, Profile with English/Español and Large Text.
- **Warehouse (Manager, Worker):** Home, Orders with filters, order checklist with shortages, Packing Mode, dispatch in strict order (Packed → Ready to Ship → Shipped → Completed), Inventory with restock, Suppliers, History, Profile.

## Demo logins

| Person | Role | PIN |
|---|---|---|
| Carlos | Foreman | 4827 |
| John Martinez | Journeyman (Can Request Materials on 7 Fairfield Rd) | 2211 |
| Daniel Perez | Apprentice (View Only on 7 Fairfield Rd) | 3322 |
| Ana | Warehouse Manager | 0000 |
| Michael Torres | Warehouse Worker | 8899 |

Data is saved in the browser (localStorage). "Reset demo data" on the first
screen restores the original demo projects, orders, and inventory.

## Run it on a computer

Requires Node.js 18 or newer.

```bash
npm install
npm run dev
```

Then open the address it prints (usually http://localhost:5173).

## Publish it on GitHub with a live link

1. Create a repository on github.com and upload every file and folder from this project, including the `.github` folder.
2. In the repository, open **Settings → Pages** and set **Source** to **GitHub Actions**.
3. Wait about a minute. The app is published at `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

Every later change pushed to `main` republishes the app automatically.

## Tests

```bash
npm test
```

Runs 82 end-to-end checks: the real app is loaded in a simulated browser and driven through every role by tapping the same buttons a user would (login, search, configuring products, submitting, reordering, Job Kits, projects and permissions, packing with shortages, dispatch order, delivery confirmation, language, and reloading the page).

## Project structure

```
src/
  data/        seed data, the 324-family catalog, strings (EN/ES), icons
  lib/         db (saving), store (app state), auth, permissions, catalog engine, cart, actions
  components/  shared UI pieces and the overlay sheets
  screens/     one file per area of the app
  styles.css   ANT visual identity (unchanged from the original)
```

## Things that are prototype-only

- **Login** is a 4-digit PIN checked in the browser (`src/lib/auth.js`). It is not real security, and it is isolated so real sign-in can replace it without touching permissions.
- **Saving** uses the browser's localStorage (`src/lib/db.js`). A real backend would replace that one file.
- **Manufacturer data**: part numbers and UPCs are intentionally empty. Breaker availability rules are conservative placeholders to confirm against manufacturer catalogs.
