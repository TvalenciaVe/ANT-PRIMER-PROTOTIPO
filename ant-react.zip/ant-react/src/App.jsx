import { useEffect } from 'react';
import { ui, useAppVersion, prefs } from './lib/store.js';
import { RoleSelect, ProfilePicker, Pin, NewProfileRole, NewProfile } from './screens/Login.jsx';
import { FieldHome, Category, Cart } from './screens/Field.jsx';
import { ProductSheet, FamilySheet, ProjectSwitcher, ChangeProjectWarning } from './components/Overlays.jsx';
import { Toast } from './components/common.jsx';
import { OrderForm, MyOrders, FieldProfile } from './screens/Requests.jsx';
import { JobKits, CreateKit } from './screens/Kits.jsx';
import { ReviewSheet, SaveKitSheet, KitDetailSheet } from './components/FieldSheets.jsx';
import { ManagerHome, WorkerHome, ManagerOrders, WarehousePacking, PackingMode, Inventory, Suppliers, History, WarehouseProfile, OrderDetailSheet, SupplierSheet } from './screens/Warehouse.jsx';
import { ProjectsList, AddProject, ProjectWorkspace, DuplicateProjectSheet, AddTeamMemberSheet, PermissionChangeSheet, DeliveryConfirmSheet } from './screens/Projects.jsx';

const SCREENS = {
  roleSelect: RoleSelect,
  foremanPicker: () => <ProfilePicker role="foreman" />,
  managerPicker: () => <ProfilePicker role="manager" />,
  pin: Pin, newProfileRole: NewProfileRole, newProfile: NewProfile,
  fHome: FieldHome, fCategory: Category, fCart: Cart,
  fOrderForm: OrderForm, fMyOrders: MyOrders, fProfile: FieldProfile, fJobKits: JobKits, fCreateKit: CreateKit,
  fProjects: ProjectsList, fAddProject: AddProject, fProjectWorkspace: ProjectWorkspace,
  mHome: ManagerHome, whHome: WorkerHome, mOrders: ManagerOrders, whPacking: WarehousePacking, whPackingMode: PackingMode,
  mInventory: Inventory, mSuppliers: Suppliers, mHistory: History, mProfile: WarehouseProfile,
};

// Same screens as the original where the warehouse order sheet can open.
const ORDER_SHEET_SCREENS = ['mOrders', 'mHistory', 'mHome', 'whHome', 'whPacking', 'mInventory'];

export default function App() {
  useAppVersion();
  useEffect(() => {
    document.getElementById('root').classList.toggle('text-large', prefs.textSize === 'large');
  });
  const Screen = SCREENS[ui.screen];
  return (
    <>
      {Screen ? <Screen /> : <RoleSelect />}
      {ui.modalProduct ? <ProductSheet /> : null}
      {ui.modalFamily ? <FamilySheet /> : null}
      {ui.modalKit ? <KitDetailSheet /> : null}
      {ui.saveKitOrderId ? <SaveKitSheet /> : null}
      {ui.reviewOpen ? <ReviewSheet /> : null}
      {ui.duplicateWarning ? <DuplicateProjectSheet /> : null}
      {ui.addTeamMemberOpen ? <AddTeamMemberSheet /> : null}
      {ui.permissionChangeConfirm ? <PermissionChangeSheet /> : null}
      {ui.deliveryConfirmOrderId ? <DeliveryConfirmSheet /> : null}
      {ui.openOrderId && ORDER_SHEET_SCREENS.indexOf(ui.screen) !== -1 ? <OrderDetailSheet /> : null}
      {ui.supplierOrderId ? <SupplierSheet /> : null}
      {ui.switcherOpen ? <ProjectSwitcher /> : null}
      {ui.changeProjectWarning ? <ChangeProjectWarning /> : null}
      <Toast />
    </>
  );
}
