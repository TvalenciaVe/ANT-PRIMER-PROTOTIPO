import { ui } from '../lib/store.js';
import { db } from '../lib/db.js';
import { t } from '../lib/i18n.js';
import { canRequestNow } from '../lib/permissions.js';
import { getProduct } from '../lib/catalog.js';
import { cartCount } from '../lib/cart.js';
import { combineDateTime, fmtNeeded, orderById } from '../lib/orders.js';
import { Icon, Sheet, MaterialRow, ErrorBanner } from './common.jsx';
import * as F from '../lib/actionsField.js';

export function ReviewSheet() {
  const d = ui.orderDraft;
  const ts = combineDateTime(d.neededDate, d.neededTime);
  return (
    <Sheet center onClose={F.closeReview}>
      <div className="section-pad" style={{ paddingTop: 22 }}>
        <div className="h1" style={{ marginBottom: 16 }}>Send material request?</div>
        <div className="spec-row"><span className="k">Project</span><span className="v">{ui.currentProject}</span></div>
        <div className="spec-row"><span className="k">Needed by</span><span className="v">{ts ? fmtNeeded(ts) : '\u2014'}</span></div>
        <div className="spec-row"><span className="k">Priority</span><span className="v">{d.priority}</span></div>
        <div className="spec-row"><span className="k">Materials</span><span className="v">{cartCount()} items, {ui.cart.length} lines</span></div>
        <div style={{ height: 20 }} />
        <button className="btn btn-primary" disabled={ui.sending} onClick={F.sendOrder} style={{ marginBottom: 10 }}>{ui.sending ? 'Sending…' : 'Send request'}</button>
        <button className="btn btn-secondary" disabled={ui.sending} onClick={F.closeReview}>Cancel</button>
      </div>
    </Sheet>
  );
}

export function SaveKitSheet() {
  const o = orderById(ui.saveKitOrderId);
  if (!o) return null;
  return (
    <Sheet center onClose={F.closeSaveAsKit}>
      <div className="section-pad" style={{ paddingTop: 22 }}>
        <div className="h1" style={{ marginBottom: 6 }}>Save as Job Kit</div>
        <div className="small muted" style={{ marginBottom: 16 }}>Save the {o.items.length} materials from {o.id} as a reusable kit in My Kits.</div>
        <ErrorBanner />
        <div className="field"><label htmlFor="savekit-name">Kit name</label>
          <input type="text" id="savekit-name" placeholder="e.g. Panel Installation" value={ui.saveKitName} onChange={(e) => F.setSaveKitName(e.target.value)} /></div>
        <button className="btn btn-primary" style={{ marginBottom: 10 }} onClick={F.confirmSaveAsKit}>Save kit</button>
        <button className="btn btn-secondary" onClick={F.closeSaveAsKit}>Cancel</button>
      </div>
    </Sheet>
  );
}

export function KitDetailSheet() {
  const kit = db.JOB_KITS.find((k) => k.id === ui.modalKit);
  if (!kit) return null;
  const can = canRequestNow();
  const items = ui.modalKitItems;
  return (
    <Sheet onClose={F.closeKit} title={kit.name}>
      <div className="detail-photo"><Icon name="box" /></div>
      <div className="section-pad" style={{ paddingBottom: 4 }}>
        {kit.description ? <div className="small muted" style={{ marginBottom: 10 }}>{kit.description}</div> : null}
        <div className="tiny muted" style={{ fontWeight: 700 }}>{items.length} materials · {kit.type} kit</div>
      </div>
      <div id="kit-detail-items">
        {items.map((it, idx) => {
          const p = getProduct(it.productId);
          return p ? <MaterialRow key={it.productId} p={p} qty={it.qty} meta={p.size || ''}
            onStep={(d) => F.stepKitItemQty(idx, d)} onSet={(v) => F.setKitItemQty(idx, v)} onRemove={() => F.removeKitItem(idx)} /> : null;
        })}
      </div>
      <div className="section-pad" style={{ paddingTop: 16 }}>
        {items.length === 0 ? <div className="empty" style={{ padding: '20px 0' }}><div className="etitle">No materials left in this kit</div></div> : null}
        <button className="btn btn-primary" disabled={items.length === 0 || !can} onClick={F.addKitToRequest}><Icon name="plus" /> Add kit to material request</button>
        {can ? null : <div className="tiny muted" style={{ textAlign: 'center', marginTop: 8 }}>{t('view_only_access_project')} {ui.currentProject}.</div>}
      </div>
    </Sheet>
  );
}
