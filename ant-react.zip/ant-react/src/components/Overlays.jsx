import { ui } from '../lib/store.js';
import { t } from '../lib/i18n.js';
import { canRequestNow, myProjects } from '../lib/permissions.js';
import {
  getProduct, brandOf, catLabel, familyById, variantOptions, familyBrands, familyUnits,
  familySelectionComplete, familyVariantId, familyDisplayName,
} from '../lib/catalog.js';
import { Icon, ProductImage, Sheet, QtyStepper } from './common.jsx';
import * as A from '../lib/actions.js';

function ViewOnlyNote() {
  return <div className="tiny muted" style={{ textAlign: 'center', marginTop: 8 }}>{t('view_only_access_project')} {ui.currentProject}.</div>;
}
function Chips({ options, isOn, onPick }) {
  return (
    <div className="chiprow" style={{ padding: '6px 0 10px' }}>
      {options.map((o, i) => <button key={o} className={'chip' + (isOn(o, i) ? ' on' : '')} onClick={() => onPick(o, i)}>{o}</button>)}
    </div>
  );
}

export function ProductSheet() {
  const p = getProduct(ui.modalProduct);
  if (!p) return null;
  const brand = brandOf(p, ui.modalBrand);
  const specs = [['Manufacturer', brand.mfr], ['Part number', brand.part || '\u2014'], ['Material', p.material],
    ['Size', p.size], ['Voltage rating', p.voltage], ['Amp rating', p.amp], ['Unit', p.unit]].filter((r) => r[1]);
  const can = canRequestNow();
  return (
    <Sheet onClose={A.closeProduct} title={catLabel(p.cat)}>
      <div className="detail-photo"><ProductImage p={p} large key={p.id} /></div>
      <div className="section-pad">
        <div className="h1">{p.name}</div>
        <div className="small muted" style={{ marginBottom: 14 }}>{p.desc}</div>
        {p.brands && p.brands.length > 1 ? (
          <>
            <div className="spec-block-title">Preferred brand</div>
            <Chips options={p.brands.map((b) => b.mfr)} isOn={(o, i) => ui.modalBrand === i} onPick={(o, i) => A.selectBrand(i)} />
            <div className="tiny muted" style={{ marginBottom: 4 }}>Saved as your default for this material.</div>
          </>
        ) : null}
        <div className="spec-block-title">Specifications</div>
        {specs.map((r) => <div className="spec-row" key={r[0]}><span className="k">{r[0]}</span><span className="v">{r[1]}</span></div>)}
        <div className="spec-block-title">Application</div>
        <div className="small" style={{ padding: '10px 0' }}>{p.application}</div>
        <div className="divider" />
        <div className="small" style={{ fontWeight: 700, marginBottom: 6 }}>Quantity ({p.unit})</div>
        <QtyStepper value={ui.modalQty} onStep={A.stepModalQty} onSet={A.setModalQty} inputId="modal-qty" />
        <div style={{ height: 16 }} />
        <button className="btn btn-primary" disabled={!can} onClick={A.addModalToCart}><Icon name="plus" /> Add to material request</button>
        {can ? null : <ViewOnlyNote />}
      </div>
    </Sheet>
  );
}

// One chip row per variant that applies to THIS family. Options are filtered
// live by dependsOn/constraints, so impossible combinations never appear.
export function FamilySheet() {
  const fam = familyById(ui.modalFamily);
  if (!fam) return null;
  const sel = ui.modalFamilySelection;
  const forKit = ui.familyTarget === 'kit';
  const brands = familyBrands(fam, sel);
  const units = familyUnits(fam);
  const unit = ui.modalFamilyUnit || fam.unit;
  const complete = familySelectionComplete(fam, sel);
  const related = (fam.frequentlyUsedWith || []).map(familyById).filter(Boolean).slice(0, 6);
  const canAdd = forKit || canRequestNow();
  const label = forKit ? 'Add to kit' : 'Add to material request';
  const photoOf = complete ? getProduct(familyVariantId(fam.id, sel, unit)) : fam;
  return (
    <Sheet onClose={A.closeFamily} title={catLabel(fam.cat)}>
      <div className="detail-photo"><ProductImage p={photoOf} large key={photoOf.id} /></div>
      <div className="section-pad">
        <div className="h1">{fam.name}</div>
        <div className="small muted" style={{ marginBottom: 14 }}>{fam.desc}</div>
        {fam.variants.map((v) => {
          const waiting = v.dependsOn && !sel[v.dependsOn];
          const dep = waiting ? fam.variants.find((x) => x.key === v.dependsOn) : null;
          return (
            <div key={v.key}>
              <div className="spec-block-title">{v.label}</div>
              {waiting
                ? <div className="tiny muted" style={{ padding: '6px 0 12px' }}>Choose {dep ? dep.label : 'the option above'} first.</div>
                : <Chips options={variantOptions(fam, v, sel)} isOn={(o) => sel[v.key] === o} onPick={(o, i) => A.selectFamilyVariant(v.key, i)} />}
            </div>
          );
        })}
        {brands.length > 1 ? (
          <><div className="spec-block-title">Brand (optional)</div>
            <Chips options={brands.map((b) => b.mfr)} isOn={(o, i) => ui.modalFamilyBrand === i} onPick={(o, i) => A.selectFamilyBrand(i)} /></>
        ) : null}
        {units.length > 1 ? (
          <><div className="spec-block-title">Unit</div>
            <Chips options={units} isOn={(o) => unit === o} onPick={(o) => A.selectFamilyUnit(o)} /></>
        ) : null}
        <div className="divider" />
        <div className="small" style={{ fontWeight: 700, marginBottom: 6 }}>Quantity ({unit})</div>
        <QtyStepper value={ui.modalFamilyQty} onStep={A.stepFamilyQty} onSet={A.setFamilyQty} inputId="family-qty" />
        {complete ? (
          <div className="info-card" style={{ marginTop: 16 }}>
            <div className="tiny muted" style={{ fontWeight: 700 }}>You are requesting</div>
            <div style={{ fontWeight: 700, fontSize: 16, marginTop: 3 }}>{familyDisplayName(fam, sel)}</div>
            <div className="tiny muted" style={{ marginTop: 2 }}>Unit: {unit}{brands[ui.modalFamilyBrand] ? ' \u00b7 ' + brands[ui.modalFamilyBrand].mfr : ''}</div>
          </div>
        ) : null}
        <div style={{ height: 16 }} />
        <button className="btn btn-primary" disabled={!canAdd || !complete} onClick={A.addFamilyToCart}><Icon name="plus" /> {label}</button>
        {canAdd ? null : <ViewOnlyNote />}
        {!complete ? <div className="tiny muted" style={{ textAlign: 'center', marginTop: 8 }}>Choose an option for each field above to continue.</div> : null}
        {related.length ? (
          <>
            <div className="divider" />
            <div className="spec-block-title">Frequently used with</div>
            {related.map((r) => (
              <button key={r.id} className="cat-row" onClick={() => A.openFamily(r.id)}>
                <span className="cat-row-label" style={{ fontSize: 16 }}>{r.name}</span><Icon name="chev" />
              </button>
            ))}
          </>
        ) : null}
      </div>
    </Sheet>
  );
}

export function ProjectSwitcher() {
  return (
    <Sheet onClose={A.closeSwitcher} title="Select project">
      <div className="section-pad" style={{ paddingTop: 0 }}>
        {myProjects(ui.currentUser).map((p) => {
          const cur = p.name === ui.currentProject;
          return (
            <button key={p.id} className="profile-pick" onClick={() => A.selectProject(p.name)}>
              <div className="ricon" style={{ background: 'var(--sunken)', width: 42, height: 42, borderRadius: 10 }}><Icon name={cur ? 'check' : 'projects'} /></div>
              <div><div className="pname">{p.name}</div><div className="pmeta">{p.status}</div></div>
              {cur ? <span className="badge badge-current" style={{ marginLeft: 'auto' }}>Current</span> : <div className="chev"><Icon name="chev" /></div>}
            </button>
          );
        })}
      </div>
    </Sheet>
  );
}

export function ChangeProjectWarning() {
  const w = ui.changeProjectWarning;
  if (!w) return null;
  return (
    <Sheet center onClose={A.cancelChangeProject}>
      <div className="section-pad" style={{ paddingTop: 22 }}>
        <div className="h1" style={{ marginBottom: 6 }}>Change project?</div>
        <div className="small muted" style={{ marginBottom: 16 }}>
          This material request currently belongs to <b style={{ color: 'var(--ink)' }}>{w.from}</b>. Changing the project will move this request to <b style={{ color: 'var(--ink)' }}>{w.to}</b>.
        </div>
        <button className="btn btn-primary" style={{ marginBottom: 10 }} onClick={A.confirmChangeProject}>Change project</button>
        <button className="btn btn-secondary" onClick={A.cancelChangeProject}>Cancel</button>
      </div>
    </Sheet>
  );
}
