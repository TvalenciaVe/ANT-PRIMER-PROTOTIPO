import { useState } from 'react';
import { ICON } from '../data/icons.js';
import { ui, prefs } from '../lib/store.js';
import { t } from '../lib/i18n.js';
import { productImage, catInitials, familySpecRange } from '../lib/catalog.js';
import { cartCount } from '../lib/cart.js';
import * as A from '../lib/actions.js';

// Icons are static, trusted SVG strings from the original prototype.
export function Icon({ name, className }) {
  return <span className={className || ''} style={{ display: 'inline-flex' }} dangerouslySetInnerHTML={{ __html: ICON[name] || '' }} />;
}

// Real photo when a verified image exists; otherwise the category monogram.
// A photo that fails to load also falls back to the monogram, never a broken icon.
export function ProductImage({ p, large }) {
  const img = productImage(p);
  const [broken, setBroken] = useState(false);
  if (img && !broken) {
    return (
      <img src={large ? img.urlLarge || img.url : img.url} alt={img.alt} loading="lazy" onError={() => setBroken(true)}
        style={{ width: '100%', height: '100%', objectFit: 'contain', padding: large ? 16 : 0 }} />
    );
  }
  return <span>{catInitials(p.cat)}</span>;
}

export function ProductCard({ p }) {
  return (
    <button className="prodcard" onClick={() => A.openProduct(p.id)}>
      <div className="thumb"><ProductImage p={p} /></div>
      <div className="pbody">
        <div className="pname">{p.name}</div>
        {p.size ? <div className="pspec">{p.size}</div> : null}
        <div className="punit">{p.unit}</div>
      </div>
    </button>
  );
}

// Recently / Most Used: tapping the card opens details; "Add" adds 1 directly.
export function ProductCardWithAdd({ p }) {
  return (
    <div className="prodcard prodcard-add">
      <button onClick={() => A.openProduct(p.id)}>
        <div className="thumb"><ProductImage p={p} /></div>
        <div className="pbody">
          <div className="pname">{p.name}</div>
          {p.size ? <div className="pspec">{p.size}</div> : null}
          <div className="punit">{p.unit}</div>
        </div>
      </button>
      <button className="quick-add-btn" onClick={() => A.quickAddToCart(p.id)}><Icon name="plus" /> <span>{t('add')}</span></button>
    </div>
  );
}

export function FamilyCard({ fam }) {
  return (
    <button className="prodcard" onClick={() => A.openFamily(fam.id)}>
      <div className="thumb"><ProductImage p={fam} /></div>
      <div className="pbody">
        <div className="pname">{fam.name}</div>
        <div className="pspec">{familySpecRange(fam)}</div>
        <div className="punit">{fam.unit}</div>
      </div>
    </button>
  );
}
// Lists can freely mix families and legacy products.
export const CatalogCard = ({ item }) => (item.variants ? <FamilyCard fam={item} /> : <ProductCard p={item} />);

export function Sheet({ onClose, title, center, children }) {
  return (
    <div className={'modal-overlay' + (center ? ' center' : '')} onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="sheet">
        {center ? null : <div className="sheet-handle" />}
        {title != null ? (
          <div className="sheet-header">
            <div className="stitle">{title}</div>
            <button className="icon-btn" onClick={onClose} aria-label="Close"><Icon name="close" /></button>
          </div>
        ) : null}
        {children}
      </div>
    </div>
  );
}

export function QtyStepper({ value, onStep, onSet, small, inputId }) {
  return (
    <div className={small ? 'qty-stepper-sm' : 'qty-stepper'}>
      <button onClick={() => onStep(-1)} aria-label="Decrease"><Icon name="minus" /></button>
      <input type="number" id={inputId} min="1" value={value} onChange={(e) => onSet(e.target.value)} />
      <button onClick={() => onStep(1)} aria-label="Increase"><Icon name="plus" /></button>
    </div>
  );
}

export function Header({ onBack, title, sub, subId, children }) {
  return (
    <div className="app-header">
      {onBack ? <button className="icon-btn" onClick={onBack} aria-label="Back"><Icon name="back" /></button> : null}
      <div><div className="htitle">{title}</div>{sub != null ? <div className="hsub" id={subId}>{sub}</div> : null}</div>
      {children}
    </div>
  );
}

export function Empty({ icon, title, children }) {
  return (
    <div className="empty">
      {icon ? <Icon name={icon} /> : null}
      <div className="etitle">{title}</div>
      {children}
    </div>
  );
}

export function FieldNav({ active }) {
  const items = [
    { k: 'home', label: t('home'), icon: 'home', go: 'fHome' },
    { k: 'projects', label: t('projects'), icon: 'projects', go: 'fProjects' },
    { k: 'orders', label: t('orders'), icon: 'orders', go: 'fMyOrders' },
    { k: 'profile', label: t('profile'), icon: 'profile', go: 'fProfile' },
  ];
  return (
    <div className="bottomnav">
      {items.map((it) => (
        <button key={it.k} className={'navitem' + (active === it.k ? ' active' : '')} onClick={() => A.fNavTo(it.k, it.go)}>
          <Icon name={it.icon} /><span>{it.label}</span>
        </button>
      ))}
    </div>
  );
}

export function CartFab() {
  const n = cartCount();
  if (!n) return null;
  return (
    <button className="fab-cart" onClick={() => A.goto('fCart')}>
      <span className="fcount">{n}</span> View material request <Icon name="chev" />
    </button>
  );
}

export function Toast() {
  if (!ui.toast) return null;
  return <div className="toast" role="status"><Icon name="check" /><span>{ui.toast}</span></div>;
}

export function ErrorBanner() {
  if (!ui.errorBanner) return null;
  return <div className="alert-banner" role="alert"><Icon name="alert" /><span>{ui.errorBanner}</span></div>;
}

// Editable material line used by the cart, Job Kit detail and Create Job Kit.
export function MaterialRow({ p, qty, meta, onStep, onSet, onRemove }) {
  return (
    <div className="cart-item">
      <div className="thumb"><ProductImage p={p} key={p.id} /></div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div className="ciname">{p.name}</div>
        <div className="cimeta">{meta}</div>
        <div className="ciqty">
          <QtyStepper small value={qty} onStep={onStep} onSet={onSet} />
          <span className="unit-tag">{p.unit}</span>
        </div>
      </div>
      <button className="cart-remove" onClick={onRemove} aria-label={'Remove ' + p.name}><Icon name="close" /></button>
    </div>
  );
}

export function Preferences() {
  const Seg = ({ value, options, onPick }) => (
    <div className="segment" style={{ margin: 0 }}>
      {options.map(([v, label]) => <button key={v} className={value === v ? 'on' : ''} onClick={() => onPick(v)}>{label}</button>)}
    </div>
  );
  return (
    <>
      <div className="h2" style={{ margin: '22px 0 12px' }}>{t('preferences')}</div>
      <div className="info-card">
        <div className="tiny muted" style={{ fontWeight: 700, marginBottom: 8 }}>{t('language')}</div>
        <div style={{ marginBottom: 16 }}><Seg value={prefs.language} options={[['en', 'English'], ['es', 'Español']]} onPick={A.setLanguage} /></div>
        <div className="tiny muted" style={{ fontWeight: 700, marginBottom: 8 }}>{t('text_size')}</div>
        <Seg value={prefs.textSize} options={[['standard', t('standard')], ['large', t('large')]]} onPick={A.setTextSize} />
      </div>
    </>
  );
}
