/* ===== GENERATED CATALOG DATA (gen_catalog.py) — do not hand-edit; regenerate instead ===== */
export const MASTER_AREAS = [{"key": "a01", "label": "Wire & Cable", "initials": "W&C"}, {"key": "a02", "label": "Conduit & Raceways", "initials": "CN"}, {"key": "a03", "label": "Conduit Fittings", "initials": "CF"}, {"key": "a04", "label": "Boxes & Covers", "initials": "BX"}, {"key": "a05", "label": "Conduit Bodies", "initials": "CB"}, {"key": "a06", "label": "Supports & Fastening", "initials": "SP"}, {"key": "a07", "label": "Wire Connectors & Terminations", "initials": "WT"}, {"key": "a08", "label": "Grounding & Bonding", "initials": "GB"}, {"key": "a09", "label": "Wiring Devices", "initials": "WD"}, {"key": "a10", "label": "Panels & Distribution", "initials": "PD"}, {"key": "a11", "label": "Breakers", "initials": "BK"}, {"key": "a12", "label": "Service & Metering", "initials": "SM"}, {"key": "a13", "label": "Disconnects & Fuses", "initials": "DF"}, {"key": "a14", "label": "Lighting", "initials": "LT"}, {"key": "a15", "label": "Lighting Controls & Sensors", "initials": "LC"}, {"key": "a16", "label": "Motors & Motor Controls", "initials": "MC"}, {"key": "a17", "label": "Transformers", "initials": "TX"}, {"key": "a18", "label": "HVAC Electrical", "initials": "HV"}, {"key": "a19", "label": "Generator & Backup Power", "initials": "GN"}, {"key": "a20", "label": "EV Charging", "initials": "EV"}, {"key": "a21", "label": "Surge & Power Quality", "initials": "SG"}, {"key": "a22", "label": "Low Voltage & Data", "initials": "LV"}, {"key": "a23", "label": "Fire Alarm", "initials": "FA"}, {"key": "a24", "label": "Security & Access Control", "initials": "SC"}, {"key": "a25", "label": "Cable Tray & Wireway", "initials": "CT"}, {"key": "a26", "label": "Junction / Pull Boxes & Enclosures", "initials": "EN"}, {"key": "a27", "label": "Weatherproof & Specialty Fittings", "initials": "WP"}, {"key": "a28", "label": "Temporary Power", "initials": "TP"}, {"key": "a29", "label": "Firestop", "initials": "FS"}, {"key": "a30", "label": "Consumables & Chemicals", "initials": "CC"}, {"key": "a31", "label": "Wire & Cable Management", "initials": "WM"}, {"key": "a32", "label": "Identification & Labeling", "initials": "ID"}];
export const CATALOG_GROUPS = [{"key": "g01", "label": "Wire & Cable", "areas": ["a01"]}, {"key": "g02", "label": "Conduit & Raceways", "areas": ["a02", "a25"]}, {"key": "g03", "label": "Fittings & Conduit Bodies", "areas": ["a03", "a05", "a27"]}, {"key": "g04", "label": "Boxes & Enclosures", "areas": ["a04", "a26"]}, {"key": "g05", "label": "Supports & Fastening", "areas": ["a06"]}, {"key": "g06", "label": "Connectors & Grounding", "areas": ["a07", "a08"]}, {"key": "g07", "label": "Wiring Devices", "areas": ["a09"]}, {"key": "g08", "label": "Electrical Distribution", "areas": ["a10", "a11", "a12", "a13", "a17", "a21"]}, {"key": "g09", "label": "Lighting & Controls", "areas": ["a14", "a15"]}, {"key": "g10", "label": "Equipment & Specialty Power", "areas": ["a16", "a18", "a19", "a20", "a28"]}, {"key": "g11", "label": "Low Voltage & Life Safety", "areas": ["a22", "a23", "a24"]}, {"key": "g12", "label": "Consumables & Labeling", "areas": ["a29", "a30", "a31", "a32"]}];
export const LEGACY_SUPERSEDED = {"wc1": "pf-thhn", "wc2": "pf-thhn", "wc3": "pf-thhn", "wc4": "pf-thhn", "wc5": "pf-mc", "wc6": "pf-nmb", "wc7": "pf-ser", "cn1": "cn-family-emt", "cn2": "cn-family-emt", "cn3": "cn-family-emt", "cn4": "pf-pvc40", "cn5": "pf-rmc", "cn6": "pf-fmc", "cn7": "pf-lfmc", "cf1": "pf-emt-connector", "cf2": "pf-emt-comp-connector", "cf3": "pf-emt-coupling", "cf4": "pf-cb-lb", "cf5": "pf-insulating-bushing", "cf6": "pf-locknut", "cf7": "pf-pvc-male", "bx1": "pf-box-4sq", "bx2": "pf-box-cover", "bx3": "pf-box-411", "bx4": "pf-handy-box", "bx5": "pf-jbox", "bx6": "pf-wp-box", "sp1": "pf-strut", "sp2": "pf-strut", "sp3": "pf-rod", "sp4": "pf-beam-clamp", "sp5": "pf-strap-1h", "sp6": "pf-jhook", "pd1": "pf-load-center", "pd2": "pf-breaker", "pd3": "pf-breaker", "pd4": "pf-safety-switch", "pd5": "pf-ct-cabinet", "pd6": "pf-fuse", "wd1": "pf-rcpt-duplex", "wd2": "pf-rcpt-gfci", "wd3": "pf-switch", "wd4": "pf-switch", "wd5": "pf-rcpt-usb", "wd6": "pf-wall-plate", "lt1": "pf-troffer", "lt2": "pf-linear", "lt3": "pf-recessed", "lt4": "pf-emergency", "lt5": "pf-wallpack", "lt6": "pf-emergency", "lv1": "pf-cat", "lv2": "pf-coax", "lv3": "pf-fa-cable", "lv4": "pf-speaker", "lv5": "pf-cat", "lv6": "pf-lv-bracket", "fa1": "pf-concrete-screw", "fa2": "pf-hollow-anchor", "fa3": "pf-metal-screw", "fa4": "pf-cable-tie", "fa5": "pf-nm-connector", "fa6": "pf-machine-screw", "ee1": "pf-dry-transformer", "ee2": "pf-starter", "ee3": "pf-contactor", "ee4": "pf-spd", "ee5": "pf-time-clock", "ee6": "pf-photocell"};
export const PRODUCT_FAMILIES = [
{
"id": "pf-thhn",
"cat": "a01",
"sub": "Building Wire",
"name": "THHN / THWN-2 Copper",
"desc": "Copper building wire for conduit and raceway runs, in standard branch-circuit and feeder colors.",
"aliases": [
"thhn",
"thwn",
"thwn-2",
"building wire",
"wire",
"copper wire",
"branch wire"
],
"unit": "FT",
"altUnits": [
"ROLL",
"REEL"
],
"variants": [
{
"key": "gauge",
"label": "Gauge",
"options": [
"#14",
"#12",
"#10",
"#8",
"#6",
"#4",
"#3",
"#2",
"#1",
"1/0",
"2/0",
"3/0",
"4/0",
"250 kcmil",
"300 kcmil",
"350 kcmil",
"400 kcmil",
"500 kcmil",
"600 kcmil",
"750 kcmil",
"1000 kcmil"
]
},
{
"key": "color",
"label": "Color",
"options": [
"Black",
"White",
"Red",
"Blue",
"Green",
"Brown",
"Orange",
"Yellow",
"Gray",
"Purple",
"Pink"
]
},
{
"key": "conductor",
"label": "Conductor",
"options": [
"Stranded",
"Solid"
]
}
],
"brandOptions": [
"Southwire",
"Encore Wire",
"Cerrowire"
],
"imageFamilyKey": "wc-thhn-thwn",
"frequentlyUsedWith": [
"cn-family-emt",
"pf-emt-connector",
"pf-winenut",
"pf-pulling-lube",
"pf-pull-line",
"pf-tape"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"gauge": [
"#8",
"#6",
"#4",
"#3",
"#2",
"#1",
"1/0",
"2/0",
"3/0",
"4/0",
"250 kcmil",
"300 kcmil",
"350 kcmil",
"400 kcmil",
"500 kcmil",
"600 kcmil",
"750 kcmil",
"1000 kcmil"
]
},
"limit": {
"conductor": [
"Stranded"
]
}
},
{
"when": {
"gauge": [
"#6",
"#4",
"#3",
"#2",
"#1"
]
},
"limit": {
"color": [
"Black",
"White",
"Red",
"Blue",
"Green"
]
}
},
{
"when": {
"gauge": [
"1/0",
"2/0",
"3/0",
"4/0",
"250 kcmil",
"300 kcmil",
"350 kcmil",
"400 kcmil",
"500 kcmil",
"600 kcmil",
"750 kcmil",
"1000 kcmil"
]
},
"limit": {
"color": [
"Black",
"White",
"Green"
]
}
}
]
},
{
"id": "pf-xhhw-cu",
"cat": "a01",
"sub": "Building Wire",
"name": "XHHW / XHHW-2 Copper",
"desc": "Select the options that apply to request the exact xhhw / xhhw-2 copper you need.",
"aliases": [
"xhhw",
"xhhw-2",
"xhhw copper"
],
"unit": "FT",
"altUnits": [
"REEL"
],
"variants": [
{
"key": "gauge",
"label": "Gauge",
"options": [
"#14",
"#12",
"#10",
"#8",
"#6",
"#4",
"#3",
"#2",
"#1",
"1/0",
"2/0",
"3/0",
"4/0",
"250 kcmil",
"300 kcmil",
"350 kcmil",
"400 kcmil",
"500 kcmil",
"600 kcmil",
"750 kcmil",
"1000 kcmil"
]
},
{
"key": "color",
"label": "Color",
"options": [
"Black",
"White",
"Red",
"Blue",
"Green"
]
}
],
"brandOptions": [
"Southwire",
"Encore Wire",
"Cerrowire"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-pulling-lube",
"pf-pull-line"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-xhhw-al",
"cat": "a01",
"sub": "Building Wire",
"name": "XHHW-2 Aluminum",
"desc": "Select the options that apply to request the exact xhhw-2 aluminum you need.",
"aliases": [
"aluminum wire",
"al wire",
"xhhw aluminum",
"aluminum feeder"
],
"unit": "FT",
"altUnits": [
"REEL"
],
"variants": [
{
"key": "gauge",
"label": "Gauge",
"options": [
"#6",
"#4",
"#2",
"#1",
"1/0",
"2/0",
"3/0",
"4/0",
"250 kcmil",
"300 kcmil",
"350 kcmil",
"400 kcmil",
"500 kcmil",
"600 kcmil",
"750 kcmil",
"1000 kcmil"
]
},
{
"key": "color",
"label": "Color",
"options": [
"Black"
]
}
],
"brandOptions": [
"Southwire",
"Encore Wire"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-lug",
"pf-sealant"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-rhh-rhw",
"cat": "a01",
"sub": "Building Wire",
"name": "RHH / RHW / RHW-2",
"desc": "Select the options that apply to request the exact rhh / rhw / rhw-2 you need.",
"aliases": [
"rhh",
"rhw",
"rhw-2",
"rubber insulated"
],
"unit": "FT",
"altUnits": [
"REEL"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"RHH",
"RHW",
"RHW-2"
]
},
{
"key": "gauge",
"label": "Gauge",
"options": [
"#14",
"#12",
"#10",
"#8",
"#6",
"#4",
"#3",
"#2",
"#1",
"1/0",
"2/0",
"3/0",
"4/0",
"250 kcmil",
"300 kcmil",
"350 kcmil",
"400 kcmil",
"500 kcmil",
"600 kcmil",
"750 kcmil",
"1000 kcmil"
]
},
{
"key": "color",
"label": "Color",
"options": [
"Black"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-nmb",
"cat": "a01",
"sub": "Residential Cable",
"name": "NM-B / Romex Cable",
"desc": "Non-metallic sheathed cable (with ground) for interior residential and light-commercial branch circuits.",
"aliases": [
"romex",
"romex wire",
"house wire",
"nm",
"nm-b",
"nmb",
"nonmetallic cable",
"12/2 romex",
"14/2 romex"
],
"unit": "FT",
"altUnits": [
"ROLL"
],
"variants": [
{
"key": "config",
"label": "Configuration",
"options": [
"14/2",
"14/3",
"12/2",
"12/3",
"10/2",
"10/3",
"8/2",
"8/3",
"6/2",
"6/3"
]
},
{
"key": "length",
"label": "Package",
"options": [
"Cut to length",
"25 ft coil",
"50 ft coil",
"100 ft coil",
"250 ft coil",
"1000 ft reel"
]
}
],
"brandOptions": [
"Southwire",
"Cerrowire"
],
"imageFamilyKey": "wc-romex-nm-b",
"frequentlyUsedWith": [
"pf-nm-connector",
"pf-cable-staple",
"pf-nm-box",
"pf-winenut"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-ufb",
"cat": "a01",
"sub": "Residential Cable",
"name": "UF-B Cable",
"desc": "Select the options that apply to request the exact uf-b cable you need.",
"aliases": [
"uf",
"uf-b",
"ufb",
"direct burial cable",
"underground feeder"
],
"unit": "FT",
"altUnits": [
"ROLL"
],
"variants": [
{
"key": "config",
"label": "Configuration",
"options": [
"14/2",
"14/3",
"12/2",
"12/3",
"10/2",
"10/3"
]
},
{
"key": "length",
"label": "Package",
"options": [
"Cut to length",
"25 ft coil",
"50 ft coil",
"100 ft coil",
"250 ft coil",
"1000 ft reel"
]
}
],
"brandOptions": [
"Southwire",
"Cerrowire"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-mc",
"cat": "a01",
"sub": "MC / Armored Cable",
"name": "MC Cable (Standard)",
"desc": "Metal-clad armored cable for commercial branch circuits without conduit.",
"aliases": [
"mc",
"mc cable",
"metal clad",
"armored cable",
"12/2 mc",
"mc wire"
],
"unit": "FT",
"altUnits": [
"ROLL",
"REEL"
],
"variants": [
{
"key": "config",
"label": "Configuration",
"options": [
"14/2",
"14/3",
"14/4",
"12/2",
"12/3",
"12/4",
"10/2",
"10/3",
"10/4",
"8/3",
"6/3"
]
},
{
"key": "armor",
"label": "Armor",
"options": [
"Aluminum",
"Steel"
],
"default": "Aluminum"
},
{
"key": "length",
"label": "Package",
"options": [
"Cut to length",
"250 ft coil",
"1000 ft reel"
]
}
],
"brandOptions": [
"AFC Cable Systems",
"Southwire",
"Encore Wire"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-mc-connector",
"pf-antishort",
"pf-mc-strap",
"pf-mc-beam-clip",
"pf-box-4sq"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-mcap",
"cat": "a01",
"sub": "MC / Armored Cable",
"name": "MCAP Cable",
"desc": "Select the options that apply to request the exact mcap cable you need.",
"aliases": [
"mcap",
"mc ap",
"mc with bonding wire"
],
"unit": "FT",
"altUnits": [
"ROLL",
"REEL"
],
"variants": [
{
"key": "config",
"label": "Configuration",
"options": [
"14/2",
"12/2",
"12/3",
"10/2",
"10/3"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-mc-connector",
"pf-antishort",
"pf-mc-strap"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-mc-hcf",
"cat": "a01",
"sub": "MC / Armored Cable",
"name": "Healthcare / HCF MC Cable",
"desc": "Select the options that apply to request the exact healthcare / hcf mc cable you need.",
"aliases": [
"hcf",
"hcf mc",
"hospital grade mc",
"healthcare mc"
],
"unit": "FT",
"altUnits": [
"ROLL",
"REEL"
],
"variants": [
{
"key": "config",
"label": "Configuration",
"options": [
"12/2",
"12/3",
"10/2",
"10/3"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-mc-connector",
"pf-antishort"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-mc-ig",
"cat": "a01",
"sub": "MC / Armored Cable",
"name": "Isolated Ground MC Cable",
"desc": "Select the options that apply to request the exact isolated ground mc cable you need.",
"aliases": [
"ig mc",
"isolated ground mc"
],
"unit": "FT",
"altUnits": [
"ROLL",
"REEL"
],
"variants": [
{
"key": "config",
"label": "Configuration",
"options": [
"12/2",
"12/3",
"10/2",
"10/3"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-mc-connector",
"pf-rcpt-ig"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-mc-fa",
"cat": "a01",
"sub": "MC / Armored Cable",
"name": "Fire Alarm MC Cable",
"desc": "Select the options that apply to request the exact fire alarm mc cable you need.",
"aliases": [
"fire alarm mc",
"red mc",
"mc fpl"
],
"unit": "FT",
"altUnits": [
"ROLL"
],
"variants": [
{
"key": "config",
"label": "Configuration",
"options": [
"18/2",
"16/2",
"14/2",
"12/2"
]
},
{
"key": "shield",
"label": "Shielding",
"options": [
"Unshielded",
"Shielded"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-mc-connector"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a23"
]
},
{
"id": "pf-mc-lum",
"cat": "a01",
"sub": "MC / Armored Cable",
"name": "Luminary / Fixture MC Cable",
"desc": "Select the options that apply to request the exact luminary / fixture mc cable you need.",
"aliases": [
"mc lum",
"luminary",
"fixture mc",
"dimming mc",
"mc with dimming"
],
"unit": "FT",
"altUnits": [
"ROLL"
],
"variants": [
{
"key": "config",
"label": "Configuration",
"options": [
"12/2 + 16/2 Dimming",
"12/3 + 16/2 Dimming",
"10/2 + 16/2 Dimming"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-fixture-whip",
"pf-mc-connector"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-mc-hl",
"cat": "a01",
"sub": "MC / Armored Cable",
"name": "MC-HL Cable",
"desc": "Select the options that apply to request the exact mc-hl cable you need.",
"aliases": [
"mc-hl",
"mchl",
"hazardous location cable"
],
"unit": "FT",
"altUnits": [
"REEL"
],
"variants": [
{
"key": "config",
"label": "Configuration",
"options": [
"12/3",
"10/3",
"8/3",
"6/3",
"4/3"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-cord-grip"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-ac-bx",
"cat": "a01",
"sub": "MC / Armored Cable",
"name": "AC Cable (BX)",
"desc": "Select the options that apply to request the exact ac cable (bx) you need.",
"aliases": [
"bx",
"ac cable",
"armored bx"
],
"unit": "FT",
"altUnits": [
"ROLL"
],
"variants": [
{
"key": "config",
"label": "Configuration",
"options": [
"14/2",
"14/3",
"12/2",
"12/3",
"10/2",
"10/3"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-mc-connector",
"pf-antishort"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-ser",
"cat": "a01",
"sub": "Service Entrance",
"name": "SER Cable",
"desc": "Select the options that apply to request the exact ser cable you need.",
"aliases": [
"ser",
"se cable",
"service entrance",
"service cable",
"4/0 ser"
],
"unit": "FT",
"altUnits": [
"REEL"
],
"variants": [
{
"key": "material",
"label": "Conductor",
"options": [
"Aluminum",
"Copper"
]
},
{
"key": "config",
"label": "Configuration",
"options": [
"6-6-6-6",
"4-4-4-6",
"2-2-2-4",
"1/0-1/0-1/0-2",
"2/0-2/0-2/0-1",
"4/0-4/0-4/0-2/0"
]
}
],
"brandOptions": [
"Southwire",
"Encore Wire"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-meter-socket",
"pf-load-center",
"pf-cord-grip"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-seu",
"cat": "a01",
"sub": "Service Entrance",
"name": "SEU Cable",
"desc": "Select the options that apply to request the exact seu cable you need.",
"aliases": [
"seu",
"service entrance u"
],
"unit": "FT",
"altUnits": [
"REEL"
],
"variants": [
{
"key": "material",
"label": "Conductor",
"options": [
"Aluminum",
"Copper"
]
},
{
"key": "config",
"label": "Configuration",
"options": [
"6-6-6",
"4-4-6",
"2-2-4",
"1/0-1/0-2",
"2/0-2/0-1",
"4/0-4/0-2/0"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-weatherhead",
"pf-meter-socket"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-use",
"cat": "a01",
"sub": "Service Entrance",
"name": "USE / USE-2 Wire",
"desc": "Select the options that apply to request the exact use / use-2 wire you need.",
"aliases": [
"use",
"use-2",
"underground service entrance"
],
"unit": "FT",
"altUnits": [
"REEL"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"USE",
"USE-2"
]
},
{
"key": "material",
"label": "Conductor",
"options": [
"Aluminum",
"Copper"
]
},
{
"key": "gauge",
"label": "Gauge",
"options": [
"#6",
"#4",
"#2",
"#1",
"1/0",
"2/0",
"3/0",
"4/0",
"250 kcmil",
"350 kcmil",
"500 kcmil"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-urd",
"cat": "a01",
"sub": "Service Entrance",
"name": "URD Cable",
"desc": "Select the options that apply to request the exact urd cable you need.",
"aliases": [
"urd",
"underground distribution",
"direct burial service"
],
"unit": "FT",
"altUnits": [
"REEL"
],
"variants": [
{
"key": "config",
"label": "Configuration",
"options": [
"2-2-2",
"1/0-1/0-1/0",
"2/0-2/0-2/0",
"4/0-4/0-4/0",
"350-350-350"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-mhf",
"cat": "a01",
"sub": "Service Entrance",
"name": "Mobile Home Feeder",
"desc": "Select the options that apply to request the exact mobile home feeder you need.",
"aliases": [
"mobile home feeder",
"mhf",
"mobile home wire"
],
"unit": "FT",
"altUnits": [
"REEL"
],
"variants": [
{
"key": "config",
"label": "Configuration",
"options": [
"6-6-6-8",
"4-4-4-6",
"2-2-2-4",
"1/0-1/0-1/0-2",
"2/0-2/0-2/0-1",
"4/0-4/0-4/0-2/0"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-service-drop",
"cat": "a01",
"sub": "Service Entrance",
"name": "Service Drop Cable",
"desc": "Select the options that apply to request the exact service drop cable you need.",
"aliases": [
"triplex",
"quadruplex",
"service drop",
"overhead service"
],
"unit": "FT",
"altUnits": [
"REEL"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Triplex",
"Quadruplex"
]
},
{
"key": "size",
"label": "Size",
"options": [
"#6",
"#4",
"#2",
"1/0",
"2/0",
"4/0"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-mast-hardware"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-cord",
"cat": "a01",
"sub": "Portable Cord",
"name": "Portable Cord",
"desc": "Select the options that apply to request the exact portable cord you need.",
"aliases": [
"so cord",
"soow",
"sjoow",
"sjeoow",
"seoow",
"stw",
"sjt",
"svt",
"portable cord",
"cord",
"flexible cord"
],
"unit": "FT",
"altUnits": [
"REEL"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"SJOOW",
"SOOW",
"SJEOOW",
"SEOOW",
"STW",
"SJT",
"SVT"
]
},
{
"key": "gauge",
"label": "Gauge",
"options": [
"18 AWG",
"16 AWG",
"14 AWG",
"12 AWG",
"10 AWG",
"8 AWG",
"6 AWG"
]
},
{
"key": "conductors",
"label": "Conductors",
"options": [
"2",
"3",
"4",
"5"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-cord-grip",
"pf-cord-connector"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"SVT"
]
},
"limit": {
"gauge": [
"18 AWG",
"16 AWG"
]
}
},
{
"when": {
"type": [
"SJOOW",
"SJEOOW",
"SJT"
]
},
"limit": {
"gauge": [
"18 AWG",
"16 AWG",
"14 AWG",
"12 AWG",
"10 AWG"
]
}
}
]
},
{
"id": "pf-tray-cable",
"cat": "a01",
"sub": "Specialty & Control Cable",
"name": "Tray Cable (TC / TC-ER)",
"desc": "Select the options that apply to request the exact tray cable (tc / tc-er) you need.",
"aliases": [
"tray cable",
"tc",
"tc-er",
"tcer"
],
"unit": "FT",
"altUnits": [
"REEL"
],
"variants": [
{
"key": "rating",
"label": "Rating",
"options": [
"TC",
"TC-ER"
]
},
{
"key": "gauge",
"label": "Gauge",
"options": [
"18 AWG",
"16 AWG",
"14 AWG",
"12 AWG",
"10 AWG",
"8 AWG",
"6 AWG"
]
},
{
"key": "conductors",
"label": "Conductors",
"options": [
"2",
"3",
"4",
"5",
"7",
"9",
"12"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-cable-tray",
"pf-cord-grip"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-control-cable",
"cat": "a01",
"sub": "Specialty & Control Cable",
"name": "Control Cable",
"desc": "Select the options that apply to request the exact control cable you need.",
"aliases": [
"control wire",
"multiconductor"
],
"unit": "FT",
"altUnits": [
"REEL"
],
"variants": [
{
"key": "gauge",
"label": "Gauge",
"options": [
"18 AWG",
"16 AWG",
"14 AWG",
"12 AWG"
]
},
{
"key": "conductors",
"label": "Conductors",
"options": [
"2",
"3",
"4",
"5",
"7",
"9",
"12"
]
},
{
"key": "shield",
"label": "Shielding",
"options": [
"Unshielded",
"Shielded"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-vfd-cable",
"cat": "a01",
"sub": "Specialty & Control Cable",
"name": "VFD Cable",
"desc": "Select the options that apply to request the exact vfd cable you need.",
"aliases": [
"vfd cable",
"drive cable"
],
"unit": "FT",
"altUnits": [
"REEL"
],
"variants": [
{
"key": "gauge",
"label": "Gauge",
"options": [
"14 AWG",
"12 AWG",
"10 AWG",
"8 AWG",
"6 AWG",
"4 AWG",
"2 AWG"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-vfd"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-thermostat",
"cat": "a01",
"sub": "Specialty & Control Cable",
"name": "Thermostat Cable",
"desc": "Select the options that apply to request the exact thermostat cable you need.",
"aliases": [
"thermostat wire",
"tstat wire",
"18/5",
"18/8",
"hvac control wire"
],
"unit": "FT",
"altUnits": [
"ROLL"
],
"variants": [
{
"key": "gauge",
"label": "Gauge",
"options": [
"18 AWG",
"20 AWG"
]
},
{
"key": "conductors",
"label": "Conductors",
"options": [
"2",
"3",
"4",
"5",
"6",
"7",
"8",
"10"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-lv-transformer"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a18"
]
},
{
"id": "pf-bell-wire",
"cat": "a01",
"sub": "Specialty & Control Cable",
"name": "Bell / Doorbell Wire",
"desc": "Select the options that apply to request the exact bell / doorbell wire you need.",
"aliases": [
"doorbell wire",
"bell wire"
],
"unit": "FT",
"altUnits": [
"ROLL"
],
"variants": [
{
"key": "gauge",
"label": "Gauge",
"options": [
"18/2",
"20/2",
"22/2"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-lv-transformer"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-landscape",
"cat": "a01",
"sub": "Specialty & Control Cable",
"name": "Landscape Lighting Wire",
"desc": "Select the options that apply to request the exact landscape lighting wire you need.",
"aliases": [
"landscape wire",
"low voltage lighting wire"
],
"unit": "FT",
"altUnits": [
"ROLL"
],
"variants": [
{
"key": "gauge",
"label": "Gauge",
"options": [
"16/2",
"14/2",
"12/2",
"10/2"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-lv-transformer",
"pf-wp-connector"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-speaker",
"cat": "a01",
"sub": "Specialty & Control Cable",
"name": "Speaker Wire",
"desc": "Select the options that apply to request the exact speaker wire you need.",
"aliases": [
"speaker cable",
"audio wire"
],
"unit": "FT",
"altUnits": [
"ROLL"
],
"variants": [
{
"key": "gauge",
"label": "Gauge",
"options": [
"18/2",
"16/2",
"16/4",
"14/2",
"14/4",
"12/2"
]
},
{
"key": "rating",
"label": "Rating",
"options": [
"Standard",
"In-Wall (CL2)",
"Plenum (CL3P)"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-security-cable",
"cat": "a01",
"sub": "Specialty & Control Cable",
"name": "Security / Alarm Cable",
"desc": "Select the options that apply to request the exact security / alarm cable you need.",
"aliases": [
"alarm wire",
"security wire",
"alarm cable"
],
"unit": "FT",
"altUnits": [
"ROLL"
],
"variants": [
{
"key": "config",
"label": "Configuration",
"options": [
"22/2",
"22/4",
"22/6",
"18/2",
"18/4"
]
},
{
"key": "shield",
"label": "Shielding",
"options": [
"Unshielded",
"Shielded"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-sec-sensor"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a24"
]
},
{
"id": "pf-access-cable",
"cat": "a01",
"sub": "Specialty & Control Cable",
"name": "Access-Control Composite Cable",
"desc": "Select the options that apply to request the exact access-control composite cable you need.",
"aliases": [
"access control cable",
"composite cable"
],
"unit": "FT",
"altUnits": [
"REEL"
],
"variants": [
{
"key": "rating",
"label": "Rating",
"options": [
"Riser",
"Plenum"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-keypad"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a24"
]
},
{
"id": "pf-fa-cable",
"cat": "a01",
"sub": "Fire Alarm Cable",
"name": "Fire Alarm Cable (FPL / FPLR / FPLP)",
"desc": "Select the options that apply to request the exact fire alarm cable (fpl / fplr / fplp) you need.",
"aliases": [
"fire alarm wire",
"fire alarm cable",
"fplp",
"fplr",
"fpl",
"red wire",
"18/2 fire"
],
"unit": "FT",
"altUnits": [
"ROLL",
"REEL"
],
"variants": [
{
"key": "rating",
"label": "Rating",
"options": [
"FPL",
"FPLR",
"FPLP"
]
},
{
"key": "config",
"label": "Configuration",
"options": [
"18/2",
"18/4",
"16/2",
"16/4",
"14/2",
"14/4",
"12/2"
]
},
{
"key": "shield",
"label": "Shielding",
"options": [
"Unshielded",
"Shielded"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-fa-detector",
"pf-fa-notification",
"pf-fa-backbox"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a23"
]
},
{
"id": "pf-cat",
"cat": "a01",
"sub": "Data / Communications",
"name": "Category Cable (Cat5e / Cat6 / Cat6A)",
"desc": "Select the options that apply to request the exact category cable (cat5e / cat6 / cat6a) you need.",
"aliases": [
"cat6",
"cat 6",
"cat5e",
"cat5",
"cat6a",
"ethernet cable",
"data cable",
"network cable",
"data wire"
],
"unit": "FT",
"altUnits": [
"BOX",
"REEL"
],
"variants": [
{
"key": "category",
"label": "Category",
"options": [
"Cat5e",
"Cat6",
"Cat6A"
]
},
{
"key": "shield",
"label": "Shielding",
"options": [
"Unshielded (UTP)",
"Shielded (F/UTP)"
]
},
{
"key": "rating",
"label": "Rating",
"options": [
"Riser (CMR)",
"Plenum (CMP)",
"Outdoor",
"Direct Burial"
]
},
{
"key": "color",
"label": "Jacket Color",
"options": [
"Blue",
"Gray",
"White",
"Yellow",
"Green",
"Orange",
"Red",
"Black"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-data-jack",
"pf-patch-panel",
"pf-jhook",
"pf-bridle-ring"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a22"
]
},
{
"id": "pf-coax",
"cat": "a01",
"sub": "Data / Communications",
"name": "Coax Cable",
"desc": "Select the options that apply to request the exact coax cable you need.",
"aliases": [
"coax",
"rg6",
"rg-6",
"rg11",
"tv cable",
"cable tv"
],
"unit": "FT",
"altUnits": [
"BOX",
"REEL"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"RG6",
"RG6 Quad Shield",
"RG11",
"RG59"
]
},
{
"key": "rating",
"label": "Rating",
"options": [
"Standard",
"Riser",
"Plenum",
"Direct Burial",
"Messengered"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-coax-hardware"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a22"
]
},
{
"id": "pf-fiber",
"cat": "a01",
"sub": "Data / Communications",
"name": "Fiber Optic Cable",
"desc": "Select the options that apply to request the exact fiber optic cable you need.",
"aliases": [
"fiber",
"fibre",
"fiber optic",
"single mode",
"multimode",
"sm fiber",
"mm fiber"
],
"unit": "FT",
"altUnits": [
"REEL"
],
"variants": [
{
"key": "mode",
"label": "Mode",
"options": [
"Single-Mode (OS2)",
"Multimode (OM3)",
"Multimode (OM4)"
]
},
{
"key": "count",
"label": "Fiber Count",
"options": [
"2",
"6",
"12",
"24",
"48"
]
},
{
"key": "rating",
"label": "Rating",
"options": [
"Riser (OFNR)",
"Plenum (OFNP)",
"Indoor/Outdoor",
"Armored"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-fiber-hardware"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a22"
]
},
{
"id": "cn-family-emt",
"cat": "a02",
"sub": "EMT",
"name": "EMT Conduit",
"desc": "Galvanized steel electrical metallic tubing for exposed and concealed branch and feeder raceways.",
"aliases": [
"emt",
"thinwall",
"thin wall",
"electrical metallic tubing",
"pipe",
"conduit",
"emt pipe"
],
"unit": "EA",
"altUnits": [
"FT"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
},
{
"key": "length",
"label": "Length",
"options": [
"10' stick"
]
}
],
"brandOptions": [
"Allied Tube & Conduit",
"Wheatland Tube",
"Republic Conduit"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-emt-connector",
"pf-emt-coupling",
"pf-strap-1h",
"pf-pull-elbow",
"pf-emt-comp-connector"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-rmc",
"cat": "a02",
"sub": "Rigid / IMC",
"name": "Rigid Metal Conduit (RMC)",
"desc": "Select the options that apply to request the exact rigid metal conduit (rmc) you need.",
"aliases": [
"rigid",
"rmc",
"grc",
"heavy wall",
"rigid pipe",
"galvanized rigid"
],
"unit": "EA",
"altUnits": [
"FT"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\"",
"5\"",
"6\""
]
},
{
"key": "material",
"label": "Material",
"options": [
"Galvanized Steel",
"Aluminum",
"Stainless Steel"
],
"default": "Galvanized Steel"
}
],
"brandOptions": [
"Allied Tube & Conduit",
"Wheatland Tube"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-rigid-coupling",
"pf-locknut",
"pf-groundbushing",
"pf-strap-1h"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-imc",
"cat": "a02",
"sub": "Rigid / IMC",
"name": "Intermediate Metal Conduit (IMC)",
"desc": "Select the options that apply to request the exact intermediate metal conduit (imc) you need.",
"aliases": [
"imc",
"intermediate"
],
"unit": "EA",
"altUnits": [
"FT"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
}
],
"brandOptions": [
"Allied Tube & Conduit",
"Wheatland Tube"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-rigid-coupling",
"pf-locknut",
"pf-groundbushing"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-pvc40",
"cat": "a02",
"sub": "PVC",
"name": "PVC Conduit Schedule 40",
"desc": "Select the options that apply to request the exact pvc conduit schedule 40 you need.",
"aliases": [
"pvc",
"sch 40",
"schedule 40",
"pvc pipe",
"plastic conduit",
"gray pvc"
],
"unit": "EA",
"altUnits": [
"FT"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\"",
"5\"",
"6\""
]
},
{
"key": "length",
"label": "Length",
"options": [
"10' stick",
"20' stick"
],
"default": "10' stick"
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-pvc-coupling",
"pf-pvc-male",
"pf-pvc-sweep",
"pf-pvc-cement"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-pvc80",
"cat": "a02",
"sub": "PVC",
"name": "PVC Conduit Schedule 80",
"desc": "Select the options that apply to request the exact pvc conduit schedule 80 you need.",
"aliases": [
"sch 80",
"schedule 80",
"pvc 80"
],
"unit": "EA",
"altUnits": [
"FT"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\"",
"5\"",
"6\""
]
},
{
"key": "length",
"label": "Length",
"options": [
"10' stick",
"20' stick"
],
"default": "10' stick"
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-pvc-coupling",
"pf-pvc-male",
"pf-pvc-sweep",
"pf-pvc-cement"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-fmc",
"cat": "a02",
"sub": "Flexible",
"name": "Flexible Metal Conduit (FMC)",
"desc": "Select the options that apply to request the exact flexible metal conduit (fmc) you need.",
"aliases": [
"flex",
"greenfield",
"fmc",
"flexible conduit",
"flex conduit"
],
"unit": "ROLL",
"altUnits": [
"FT"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"3/8\"",
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\""
]
},
{
"key": "material",
"label": "Material",
"options": [
"Steel",
"Aluminum"
]
},
{
"key": "wall",
"label": "Wall",
"options": [
"Standard Wall",
"Reduced Wall"
],
"default": "Standard Wall"
},
{
"key": "length",
"label": "Coil Length",
"options": [
"25 ft",
"50 ft",
"100 ft"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-flex-connector",
"pf-antishort",
"pf-flex-coupling"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-lfmc",
"cat": "a02",
"sub": "Flexible",
"name": "Liquidtight Flexible Metal Conduit (LFMC)",
"desc": "Select the options that apply to request the exact liquidtight flexible metal conduit (lfmc) you need.",
"aliases": [
"liquidtight",
"liquid tight",
"sealtite",
"seal tight",
"lfmc",
"lt flex"
],
"unit": "ROLL",
"altUnits": [
"FT"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"3/8\"",
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"4\""
]
},
{
"key": "length",
"label": "Coil Length",
"options": [
"25 ft",
"50 ft",
"100 ft"
]
}
],
"brandOptions": [],
"imageFamilyKey": "cn-liquidtight",
"frequentlyUsedWith": [
"pf-lt-connector",
"pf-lt-coupling"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a27"
]
},
{
"id": "pf-lfnc",
"cat": "a02",
"sub": "Flexible",
"name": "Liquidtight Flexible Nonmetallic Conduit (LFNC)",
"desc": "Select the options that apply to request the exact liquidtight flexible nonmetallic conduit (lfnc) you need.",
"aliases": [
"lfnc",
"carflex",
"nonmetallic liquidtight",
"plastic liquidtight"
],
"unit": "ROLL",
"altUnits": [
"FT"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"3/8\"",
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\""
]
},
{
"key": "length",
"label": "Coil Length",
"options": [
"25 ft",
"50 ft",
"100 ft"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-lt-connector"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "cn-family-ent",
"cat": "a02",
"sub": "ENT",
"name": "Electrical Nonmetallic Tubing (ENT)",
"desc": "Flexible corrugated nonmetallic raceway for concealed work in walls and slabs.",
"aliases": [
"ent",
"smurf",
"smurf tube",
"blue tube",
"blue flex",
"nonmetallic tubing"
],
"unit": "ROLL",
"altUnits": [
"FT"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-ent-fitting",
"pf-nm-box"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-emt-connector",
"cat": "a03",
"sub": "EMT Fittings",
"name": "EMT Set-Screw Connector",
"desc": "Terminates EMT conduit at boxes and enclosures.",
"aliases": [
"emt connector",
"set screw connector",
"set-screw connector",
"ss connector",
"box connector",
"insulated connector"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
},
{
"key": "insulation",
"label": "Insulation",
"options": [
"Standard",
"Insulated"
]
},
{
"key": "material",
"label": "Material",
"options": [
"Any",
"Zinc Die-Cast",
"Steel"
],
"default": "Any"
}
],
"brandOptions": [
"Bridgeport Fittings",
"Thomas & Betts",
"Arlington Industries"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"cn-family-emt",
"pf-locknut",
"pf-emt-coupling",
"pf-strap-1h"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-emt-comp-connector",
"cat": "a03",
"sub": "EMT Fittings",
"name": "EMT Compression Connector",
"desc": "Select the options that apply to request the exact emt compression connector you need.",
"aliases": [
"compression connector",
"comp connector",
"raintight connector",
"rain tight connector",
"emt compression"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
},
{
"key": "insulation",
"label": "Insulation",
"options": [
"Standard",
"Insulated"
]
},
{
"key": "rating",
"label": "Rating",
"options": [
"Standard",
"Raintight"
],
"default": "Standard"
}
],
"brandOptions": [
"Bridgeport Fittings",
"Thomas & Betts",
"Arlington Industries"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"cn-family-emt",
"pf-locknut",
"pf-emt-comp-coupling"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a27"
]
},
{
"id": "pf-emt-coupling",
"cat": "a03",
"sub": "EMT Fittings",
"name": "EMT Set-Screw Coupling",
"desc": "Joins two lengths of EMT conduit in a straight run.",
"aliases": [
"emt coupling",
"set screw coupling",
"ss coupling",
"coupling"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
},
{
"key": "material",
"label": "Material",
"options": [
"Any",
"Zinc Die-Cast",
"Steel"
],
"default": "Any"
}
],
"brandOptions": [
"Bridgeport Fittings",
"Thomas & Betts",
"Arlington Industries"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"cn-family-emt",
"pf-emt-connector"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-emt-comp-coupling",
"cat": "a03",
"sub": "EMT Fittings",
"name": "EMT Compression Coupling",
"desc": "Select the options that apply to request the exact emt compression coupling you need.",
"aliases": [
"compression coupling",
"raintight coupling",
"comp coupling"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
},
{
"key": "rating",
"label": "Rating",
"options": [
"Standard",
"Raintight"
],
"default": "Standard"
}
],
"brandOptions": [
"Bridgeport Fittings",
"Thomas & Betts",
"Arlington Industries"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"cn-family-emt"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a27"
]
},
{
"id": "pf-emt-elbow",
"cat": "a03",
"sub": "EMT Fittings",
"name": "EMT Elbow (Factory Bend)",
"desc": "Select the options that apply to request the exact emt elbow (factory bend) you need.",
"aliases": [
"emt elbow",
"factory elbow",
"emt 90",
"sweep"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
},
{
"key": "angle",
"label": "Angle",
"options": [
"90°",
"45°"
],
"default": "90°"
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-emt-coupling"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-pull-elbow",
"cat": "a03",
"sub": "EMT Fittings",
"name": "Pull Elbow",
"desc": "Select the options that apply to request the exact pull elbow you need.",
"aliases": [
"pull elbow",
"pulling elbow",
"lb elbow"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\""
]
},
{
"key": "type",
"label": "Type",
"options": [
"Set-Screw",
"Compression"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"cn-family-emt"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-offset-connector",
"cat": "a03",
"sub": "EMT Fittings",
"name": "Offset Connector",
"desc": "Select the options that apply to request the exact offset connector you need.",
"aliases": [
"offset connector",
"box offset",
"kick connector"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"cn-family-emt"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-emt-flex",
"cat": "a03",
"sub": "EMT Fittings",
"name": "EMT-to-Flex Combination Coupling",
"desc": "Select the options that apply to request the exact emt-to-flex combination coupling you need.",
"aliases": [
"emt to flex",
"flex to emt",
"combination coupling",
"transition coupling"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-fmc"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-rigid-coupling",
"cat": "a03",
"sub": "Rigid / IMC Fittings",
"name": "Rigid / IMC Threaded Coupling",
"desc": "Select the options that apply to request the exact rigid / imc threaded coupling you need.",
"aliases": [
"rigid coupling",
"threaded coupling",
"grc coupling"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\"",
"5\"",
"6\""
]
},
{
"key": "material",
"label": "Material",
"options": [
"Steel",
"Aluminum"
],
"default": "Steel"
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-rmc"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-rigid-connector",
"cat": "a03",
"sub": "Rigid / IMC Fittings",
"name": "Rigid / IMC Threadless Connector",
"desc": "Select the options that apply to request the exact rigid / imc threadless connector you need.",
"aliases": [
"threadless connector",
"rigid connector",
"threadless coupling"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
},
{
"key": "type",
"label": "Type",
"options": [
"Connector",
"Coupling"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-rmc"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-nipple",
"cat": "a03",
"sub": "Rigid / IMC Fittings",
"name": "Conduit Nipple",
"desc": "Select the options that apply to request the exact conduit nipple you need.",
"aliases": [
"nipple",
"close nipple",
"running thread",
"all thread nipple",
"offset nipple",
"threaded nipple"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Close Nipple",
"Threaded Nipple",
"Running Thread Nipple",
"Offset Nipple"
]
},
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
},
{
"key": "length",
"label": "Length",
"options": [
"Close",
"2\"",
"3\"",
"4\"",
"6\"",
"8\"",
"12\"",
"Standard"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-locknut",
"pf-insulating-bushing"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Close Nipple"
]
},
"limit": {
"length": [
"Close"
]
}
},
{
"when": {
"type": [
"Offset Nipple"
]
},
"limit": {
"length": [
"Standard"
]
}
},
{
"when": {
"type": [
"Threaded Nipple",
"Running Thread Nipple"
]
},
"limit": {
"length": [
"2\"",
"3\"",
"4\"",
"6\"",
"8\"",
"12\""
]
}
}
]
},
{
"id": "pf-reducing-bushing",
"cat": "a03",
"sub": "Rigid / IMC Fittings",
"name": "Reducing Bushing",
"desc": "Select the options that apply to request the exact reducing bushing you need.",
"aliases": [
"reducing bushing",
"reducer bushing",
"threaded reducer"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"3/4\" x 1/2\"",
"1\" x 3/4\"",
"1\" x 1/2\"",
"1-1/4\" x 1\"",
"1-1/2\" x 1-1/4\"",
"2\" x 1-1/2\"",
"2\" x 1\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-reducing-washer"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-insulating-bushing",
"cat": "a03",
"sub": "Rigid / IMC Fittings",
"name": "Insulating Bushing",
"desc": "Select the options that apply to request the exact insulating bushing you need.",
"aliases": [
"plastic bushing",
"insulated bushing",
"bushing",
"pvc bushing",
"end bushing"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\"",
"5\"",
"6\""
]
},
{
"key": "material",
"label": "Material",
"options": [
"Plastic",
"Insulated Metallic"
]
}
],
"brandOptions": [
"Bridgeport Fittings",
"Thomas & Betts",
"Arlington Industries"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-locknut",
"pf-rmc"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-locknut",
"cat": "a03",
"sub": "Rigid / IMC Fittings",
"name": "Locknut",
"desc": "Select the options that apply to request the exact locknut you need.",
"aliases": [
"locknut",
"lock nut",
"bonding locknut",
"grounding locknut",
"sealing locknut"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\"",
"5\"",
"6\""
]
},
{
"key": "type",
"label": "Type",
"options": [
"Standard",
"Bonding",
"Sealing"
],
"default": "Standard"
}
],
"brandOptions": [
"Bridgeport Fittings",
"Thomas & Betts",
"Arlington Industries"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-emt-connector",
"pf-insulating-bushing"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a08"
]
},
{
"id": "pf-hub",
"cat": "a03",
"sub": "Rigid / IMC Fittings",
"name": "Watertight Hub (Myers-Type)",
"desc": "Select the options that apply to request the exact watertight hub (myers-type) you need.",
"aliases": [
"myers hub",
"myers",
"watertight hub",
"hub",
"meter hub"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
},
{
"key": "material",
"label": "Material",
"options": [
"Zinc Die-Cast",
"Aluminum"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-rmc"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a27"
]
},
{
"id": "pf-rigid-elbow",
"cat": "a03",
"sub": "Rigid / IMC Fittings",
"name": "Rigid / IMC Elbow",
"desc": "Select the options that apply to request the exact rigid / imc elbow you need.",
"aliases": [
"rigid elbow",
"rigid 90",
"rigid sweep",
"grc elbow"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\"",
"5\"",
"6\""
]
},
{
"key": "angle",
"label": "Angle",
"options": [
"90°",
"45°"
]
},
{
"key": "material",
"label": "Material",
"options": [
"Galvanized Steel",
"Aluminum"
],
"default": "Galvanized Steel"
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-rigid-coupling"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-pvc-coupling",
"cat": "a03",
"sub": "PVC Fittings",
"name": "PVC Coupling",
"desc": "Select the options that apply to request the exact pvc coupling you need.",
"aliases": [
"pvc coupling",
"repair coupling",
"slip coupling"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\"",
"5\"",
"6\""
]
},
{
"key": "type",
"label": "Type",
"options": [
"Standard",
"Repair (Slip)"
],
"default": "Standard"
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-pvc40",
"pf-pvc-cement"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-pvc-male",
"cat": "a03",
"sub": "PVC Fittings",
"name": "PVC Male / Terminal Adapter",
"desc": "Select the options that apply to request the exact pvc male / terminal adapter you need.",
"aliases": [
"male adapter",
"ma",
"terminal adapter",
"ta",
"pvc adapter"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\"",
"5\"",
"6\""
]
},
{
"key": "type",
"label": "Type",
"options": [
"Male Adapter",
"Terminal Adapter"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-pvc40",
"pf-locknut",
"pf-pvc-cement"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-pvc-female",
"cat": "a03",
"sub": "PVC Fittings",
"name": "PVC Female Adapter",
"desc": "Select the options that apply to request the exact pvc female adapter you need.",
"aliases": [
"female adapter",
"fa adapter"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\"",
"5\"",
"6\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-pvc40",
"pf-pvc-cement"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-pvc-bellend",
"cat": "a03",
"sub": "PVC Fittings",
"name": "PVC Bell End",
"desc": "Select the options that apply to request the exact pvc bell end you need.",
"aliases": [
"bell end",
"bellend",
"end bell"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\"",
"5\"",
"6\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-pvc40"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-pvc-sweep",
"cat": "a03",
"sub": "PVC Fittings",
"name": "PVC Sweep / Elbow",
"desc": "Select the options that apply to request the exact pvc sweep / elbow you need.",
"aliases": [
"sweep",
"pvc 90",
"pvc elbow",
"long sweep",
"long radius sweep",
"pvc 45",
"90"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\"",
"5\"",
"6\""
]
},
{
"key": "angle",
"label": "Angle",
"options": [
"22.5°",
"30°",
"45°",
"90°"
]
},
{
"key": "radius",
"label": "Radius",
"options": [
"Standard Radius",
"Long Radius"
],
"default": "Standard Radius"
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-pvc40",
"pf-pvc-cement"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-pvc-expansion",
"cat": "a03",
"sub": "PVC Fittings",
"name": "PVC Expansion Fitting",
"desc": "Select the options that apply to request the exact pvc expansion fitting you need.",
"aliases": [
"expansion fitting",
"expansion joint"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\"",
"5\"",
"6\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-pvc40",
"pf-pvc-cement"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-pvc-reducer",
"cat": "a03",
"sub": "PVC Fittings",
"name": "PVC Reducer",
"desc": "Select the options that apply to request the exact pvc reducer you need.",
"aliases": [
"pvc reducer",
"reducing coupling"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"3/4\" x 1/2\"",
"1\" x 3/4\"",
"1-1/4\" x 1\"",
"1-1/2\" x 1-1/4\"",
"2\" x 1-1/2\"",
"3\" x 2\"",
"4\" x 3\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-pvc-cement"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-flex-connector",
"cat": "a03",
"sub": "FMC Fittings",
"name": "Flex Connector",
"desc": "Select the options that apply to request the exact flex connector you need.",
"aliases": [
"flex connector",
"greenfield connector",
"squeeze connector",
"screw in connector",
"90 flex connector",
"fmc connector"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"3/8\"",
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\""
]
},
{
"key": "angle",
"label": "Angle",
"options": [
"Straight",
"90°"
]
},
{
"key": "type",
"label": "Type",
"options": [
"Squeeze",
"Screw-In",
"Clamp"
]
}
],
"brandOptions": [
"Bridgeport Fittings",
"Thomas & Betts",
"Arlington Industries"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-fmc",
"pf-antishort",
"pf-locknut"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-flex-coupling",
"cat": "a03",
"sub": "FMC Fittings",
"name": "Flex Coupling",
"desc": "Select the options that apply to request the exact flex coupling you need.",
"aliases": [
"flex coupling",
"fmc coupling"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"3/8\"",
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-fmc"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-lt-connector",
"cat": "a03",
"sub": "Liquidtight Fittings",
"name": "Liquidtight Connector",
"desc": "Select the options that apply to request the exact liquidtight connector you need.",
"aliases": [
"liquidtight connector",
"sealtite connector",
"lt connector",
"liquid tight connector"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"3/8\"",
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"4\""
]
},
{
"key": "angle",
"label": "Angle",
"options": [
"Straight",
"45°",
"90°"
]
},
{
"key": "insulation",
"label": "Insulation",
"options": [
"Standard",
"Insulated"
],
"default": "Standard"
}
],
"brandOptions": [
"Bridgeport Fittings",
"Thomas & Betts",
"Arlington Industries"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-lfmc",
"pf-locknut"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a27"
]
},
{
"id": "pf-lt-coupling",
"cat": "a03",
"sub": "Liquidtight Fittings",
"name": "Liquidtight Coupling",
"desc": "Select the options that apply to request the exact liquidtight coupling you need.",
"aliases": [
"liquidtight coupling",
"sealtite coupling"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"3/8\"",
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"4\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-lfmc"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-ent-fitting",
"cat": "a03",
"sub": "ENT Fittings",
"name": "ENT Fitting",
"desc": "Select the options that apply to request the exact ent fitting you need.",
"aliases": [
"ent coupling",
"ent connector",
"smurf connector",
"smurf coupling",
"ent adapter"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Coupling",
"Connector",
"Box Adapter",
"Male Adapter",
"Transition Adapter"
]
},
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"cn-family-ent"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-mc-connector",
"cat": "a03",
"sub": "MC / AC Fittings",
"name": "MC Connector",
"desc": "Secures MC/AC armored cable to a box or enclosure.",
"aliases": [
"mc connector",
"bx connector",
"snap in connector",
"duplex connector",
"90 mc connector",
"armored cable connector"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Cable Size",
"options": [
"14/2",
"14/3",
"12/2",
"12/3",
"12/4",
"10/2",
"10/3",
"10/4",
"8/3",
"6/3"
]
},
{
"key": "style",
"label": "Style",
"options": [
"Snap-In",
"Screw-In",
"Clamp"
]
},
{
"key": "angle",
"label": "Angle",
"options": [
"Straight",
"90°"
],
"default": "Straight"
},
{
"key": "entries",
"label": "Entries",
"options": [
"Single",
"Duplex"
],
"default": "Single"
},
{
"key": "insulation",
"label": "Insulation",
"options": [
"Standard",
"Insulated"
],
"default": "Standard"
}
],
"brandOptions": [
"Bridgeport Fittings",
"Thomas & Betts",
"Arlington Industries"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-mc",
"pf-antishort",
"pf-mc-strap"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-mc-flex",
"cat": "a03",
"sub": "MC / AC Fittings",
"name": "MC / Flex Combination Connector",
"desc": "Select the options that apply to request the exact mc / flex combination connector you need.",
"aliases": [
"mc flex connector",
"combination connector"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Trade Size",
"options": [
"3/8\"",
"1/2\"",
"3/4\""
]
}
],
"brandOptions": [
"Bridgeport Fittings",
"Thomas & Betts",
"Arlington Industries"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-mc",
"pf-fmc"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-mc-watertight",
"cat": "a03",
"sub": "MC / AC Fittings",
"name": "Wet-Location MC Connector",
"desc": "Select the options that apply to request the exact wet-location mc connector you need.",
"aliases": [
"watertight mc connector",
"wet location mc",
"teck connector"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Trade Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-mc-hl"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a27"
]
},
{
"id": "pf-antishort",
"cat": "a03",
"sub": "MC / AC Fittings",
"name": "Anti-Short Bushing",
"desc": "Protects conductor insulation where the armor is cut back on MC/AC cable or flex.",
"aliases": [
"redhead",
"red head",
"redheads",
"mc bushing",
"anti short",
"anti-short",
"antishort"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Cable Size",
"options": [
"14/2",
"12/2",
"10/2",
"12/3",
"10/3",
"14/3",
"12/4",
"10/4",
"8/3",
"6/3"
]
}
],
"brandOptions": [
"Bridgeport Fittings",
"Thomas & Betts"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-mc",
"pf-mc-connector"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-nm-connector",
"cat": "a03",
"sub": "MC / AC Fittings",
"name": "NM Cable Connector",
"desc": "Select the options that apply to request the exact nm cable connector you need.",
"aliases": [
"romex connector",
"nm connector",
"romex clamp",
"cable clamp connector"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Metal Clamp",
"Plastic Push-In"
]
},
{
"key": "size",
"label": "Size",
"options": [
"3/8\"",
"1/2\"",
"3/4\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-nmb"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-box-4sq",
"cat": "a04",
"sub": "Metal Boxes",
"name": "4\" Square / 1900 Box",
"desc": "Standard 4\" square steel box for devices and junctions.",
"aliases": [
"1900",
"1900 box",
"4 square",
"four square",
"4x4 box",
"4 inch square",
"4sq",
"square box"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "depth",
"label": "Depth",
"options": [
"1-1/4\"",
"1-1/2\"",
"2-1/8\""
]
},
{
"key": "ko",
"label": "Knockouts",
"options": [
"1/2\" KOs",
"3/4\" KOs",
"1/2\" & 3/4\" Combo"
],
"default": "1/2\" & 3/4\" Combo"
},
{
"key": "mount",
"label": "Mounting",
"options": [
"No Bracket",
"With Bracket"
],
"default": "No Bracket"
}
],
"brandOptions": [
"Steel City",
"RACO"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-mudring",
"pf-ground-screw",
"pf-ground-pigtail",
"pf-emt-connector",
"pf-mc-connector",
"pf-box-cover"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-box-411",
"cat": "a04",
"sub": "Metal Boxes",
"name": "4-11/16\" Square Box",
"desc": "Select the options that apply to request the exact 4-11/16\" square box you need.",
"aliases": [
"4 11/16",
"4-11/16",
"five square",
"big square",
"411 box"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "depth",
"label": "Depth",
"options": [
"1-1/2\"",
"2-1/8\""
]
},
{
"key": "ko",
"label": "Knockouts",
"options": [
"1/2\" KOs",
"3/4\" KOs",
"1/2\" & 3/4\" Combo"
],
"default": "1/2\" & 3/4\" Combo"
},
{
"key": "mount",
"label": "Mounting",
"options": [
"No Bracket",
"With Bracket"
],
"default": "No Bracket"
}
],
"brandOptions": [
"Steel City",
"RACO"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-mudring",
"pf-ground-screw",
"pf-ground-pigtail",
"pf-box-cover"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-handy-box",
"cat": "a04",
"sub": "Metal Boxes",
"name": "Handy Box / Utility Box",
"desc": "Select the options that apply to request the exact handy box / utility box you need.",
"aliases": [
"handy box",
"utility box",
"surface box"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "depth",
"label": "Depth",
"options": [
"1-1/2\"",
"1-7/8\"",
"2-1/8\""
]
}
],
"brandOptions": [
"Steel City",
"RACO"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-box-cover",
"pf-emt-connector"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-switch-box",
"cat": "a04",
"sub": "Metal Boxes",
"name": "Switch Box (Gangable)",
"desc": "Select the options that apply to request the exact switch box (gangable) you need.",
"aliases": [
"switch box",
"gem box",
"gangable box",
"device box",
"single gang box"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "depth",
"label": "Depth",
"options": [
"2\"",
"2-1/2\"",
"3-1/2\""
]
},
{
"key": "mount",
"label": "Mounting",
"options": [
"No Bracket",
"Side Bracket",
"Nail-On"
]
}
],
"brandOptions": [
"Steel City",
"RACO"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-ground-screw"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-masonry-box",
"cat": "a04",
"sub": "Metal Boxes",
"name": "Masonry Box",
"desc": "Select the options that apply to request the exact masonry box you need.",
"aliases": [
"masonry box",
"block box"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "gang",
"label": "Gang",
"options": [
"1-Gang",
"2-Gang",
"3-Gang",
"4-Gang"
]
},
{
"key": "depth",
"label": "Depth",
"options": [
"2-1/2\"",
"3-1/2\""
]
}
],
"brandOptions": [
"Steel City",
"RACO"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-ground-screw"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-octagon-box",
"cat": "a04",
"sub": "Metal Boxes",
"name": "Octagon Box",
"desc": "Select the options that apply to request the exact octagon box you need.",
"aliases": [
"octagon box",
"oct box",
"4 oct",
"ceiling box metal"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"3-1/2\"",
"4\""
]
},
{
"key": "depth",
"label": "Depth",
"options": [
"1-1/2\"",
"2-1/8\""
]
}
],
"brandOptions": [
"Steel City",
"RACO"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-box-cover",
"pf-fixture-box"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-round-box",
"cat": "a04",
"sub": "Metal Boxes",
"name": "Round / Pancake Box",
"desc": "Select the options that apply to request the exact round / pancake box you need.",
"aliases": [
"pancake box",
"round box",
"shallow box"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Round",
"Pancake"
]
},
{
"key": "depth",
"label": "Depth",
"options": [
"1/2\"",
"1-1/2\""
]
}
],
"brandOptions": [
"Steel City",
"RACO"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Pancake"
]
},
"limit": {
"depth": [
"1/2\""
]
}
}
]
},
{
"id": "pf-slab-box",
"cat": "a04",
"sub": "Metal Boxes",
"name": "Concrete / Slab Box",
"desc": "Select the options that apply to request the exact concrete / slab box you need.",
"aliases": [
"slab box",
"concrete box",
"concrete ring",
"deck box"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "depth",
"label": "Depth",
"options": [
"3\"",
"4\"",
"6\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-pvc40",
"cn-family-ent"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-fan-box",
"cat": "a04",
"sub": "Metal Boxes",
"name": "Fan-Rated Box",
"desc": "Select the options that apply to request the exact fan-rated box you need.",
"aliases": [
"fan box",
"fan rated box",
"fan brace",
"ceiling fan box"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "material",
"label": "Material",
"options": [
"Metal",
"Nonmetallic"
]
},
{
"key": "type",
"label": "Type",
"options": [
"New Work",
"Old Work",
"Brace Kit"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-box-cover"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-fixture-box",
"cat": "a04",
"sub": "Metal Boxes",
"name": "Fixture-Rated Ceiling Box",
"desc": "Select the options that apply to request the exact fixture-rated ceiling box you need.",
"aliases": [
"fixture box",
"ceiling box",
"light box"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "material",
"label": "Material",
"options": [
"Metal",
"Nonmetallic"
]
},
{
"key": "type",
"label": "Type",
"options": [
"New Work",
"Old Work"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-box-cover"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-nm-box",
"cat": "a04",
"sub": "Nonmetallic Boxes",
"name": "Nonmetallic Device Box",
"desc": "Select the options that apply to request the exact nonmetallic device box you need.",
"aliases": [
"blue box",
"plastic box",
"old work box",
"new work box",
"remodel box",
"nonmetallic box",
"cut in box",
"multi gang box"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "work",
"label": "Installation",
"options": [
"New Work",
"Old Work"
]
},
{
"key": "gang",
"label": "Gang",
"options": [
"1-Gang",
"2-Gang",
"3-Gang",
"4-Gang"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-nmb",
"pf-wall-plate"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-wp-box",
"cat": "a04",
"sub": "Weatherproof Boxes",
"name": "Weatherproof Box",
"desc": "Select the options that apply to request the exact weatherproof box you need.",
"aliases": [
"bell box",
"fs box",
"fd box",
"weatherproof box",
"wp box",
"outdoor box"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Bell Box",
"FS Box",
"FD Box",
"Round Weatherproof Box"
]
},
{
"key": "gang",
"label": "Gang",
"options": [
"1-Gang",
"2-Gang"
]
},
{
"key": "holes",
"label": "Hubs",
"options": [
"3 Hole",
"4 Hole",
"5 Hole"
]
},
{
"key": "hub",
"label": "Hub Size",
"options": [
"1/2\"",
"3/4\"",
"1\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-wp-cover",
"pf-rcpt-gfci",
"pf-hub"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Round Weatherproof Box"
]
},
"limit": {
"gang": [
"1-Gang"
]
}
}
],
"alsoIn": [
"a27"
]
},
{
"id": "pf-floor-box",
"cat": "a04",
"sub": "Floor Boxes",
"name": "Floor Box",
"desc": "Select the options that apply to request the exact floor box you need.",
"aliases": [
"floor box",
"floor outlet box"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Single-Gang",
"Multi-Gang",
"Recessed",
"Flush",
"Concrete (Pour-In)",
"Raised-Floor"
]
},
{
"key": "material",
"label": "Material",
"options": [
"Cast Iron",
"Steel",
"Nonmetallic"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-rcpt-floor"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-poke-thru",
"cat": "a04",
"sub": "Floor Boxes",
"name": "Poke-Through Device",
"desc": "Select the options that apply to request the exact poke-through device you need.",
"aliases": [
"poke through",
"pokethru",
"poke-thru"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Core Size",
"options": [
"3\"",
"4\"",
"6\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-rcpt-floor"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-mudring",
"cat": "a04",
"sub": "Mud / Plaster Rings",
"name": "Mud Ring (Plaster Ring)",
"desc": "Brings a recessed box out to the finished wall surface.",
"aliases": [
"mud ring",
"plaster ring",
"device ring",
"raised ring",
"ring",
"4 square mud ring",
"1900 ring"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "gang",
"label": "Gang",
"options": [
"1-Gang",
"2-Gang",
"3-Gang",
"4-Gang"
]
},
{
"key": "depth",
"label": "Depth",
"options": [
"Flat",
"1/4\"",
"1/2\"",
"5/8\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\""
]
},
{
"key": "boxSize",
"label": "Fits Box",
"options": [
"4\" Square",
"4-11/16\" Square",
"Multi-Gang Box"
]
},
{
"key": "opening",
"label": "Opening",
"options": [
"Device",
"Round (Fixture)"
],
"default": "Device"
}
],
"brandOptions": [
"Steel City",
"RACO"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-box-4sq",
"pf-box-411",
"pf-wall-plate"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"boxSize": [
"4\" Square",
"4-11/16\" Square"
]
},
"limit": {
"gang": [
"1-Gang",
"2-Gang"
]
}
},
{
"when": {
"boxSize": [
"Multi-Gang Box"
]
},
"limit": {
"gang": [
"3-Gang",
"4-Gang"
]
}
}
]
},
{
"id": "pf-box-cover",
"cat": "a04",
"sub": "Covers",
"name": "Box Cover",
"desc": "Select the options that apply to request the exact box cover you need.",
"aliases": [
"cover",
"blank cover",
"raised cover",
"industrial cover",
"square cover",
"blank plate",
"handy box cover",
"flat cover"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "boxSize",
"label": "Fits Box",
"options": [
"4\" Square",
"4-11/16\" Square",
"Octagon / Round 4\"",
"Handy Box"
]
},
{
"key": "style",
"label": "Style",
"options": [
"Blank (Flat)",
"Raised Blank",
"Duplex Receptacle",
"Decora / GFCI",
"Toggle Switch",
"Single Receptacle",
"Round (Fixture)"
]
},
{
"key": "material",
"label": "Material",
"options": [
"Steel",
"Nonmetallic"
],
"default": "Steel"
}
],
"brandOptions": [
"Steel City",
"RACO"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-box-4sq",
"pf-box-screw"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"boxSize": [
"Handy Box"
]
},
"limit": {
"style": [
"Blank (Flat)",
"Duplex Receptacle",
"Decora / GFCI",
"Toggle Switch"
]
}
},
{
"when": {
"boxSize": [
"Octagon / Round 4\""
]
},
"limit": {
"style": [
"Blank (Flat)",
"Round (Fixture)"
]
}
}
]
},
{
"id": "pf-wp-cover",
"cat": "a04",
"sub": "Covers",
"name": "Weatherproof Cover",
"desc": "Select the options that apply to request the exact weatherproof cover you need.",
"aliases": [
"bubble cover",
"in use cover",
"in-use cover",
"extra duty cover",
"while in use",
"wp cover",
"weatherproof cover"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Flip Lid",
"Extra-Duty In-Use (Bubble)",
"Blank"
]
},
{
"key": "config",
"label": "Opening",
"options": [
"Duplex",
"Decora / GFCI",
"Toggle",
"Blank"
]
},
{
"key": "gang",
"label": "Gang",
"options": [
"1-Gang",
"2-Gang"
]
},
{
"key": "orient",
"label": "Orientation",
"options": [
"Vertical",
"Horizontal"
],
"default": "Vertical"
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-wp-box",
"pf-rcpt-gfci"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Blank"
]
},
"limit": {
"config": [
"Blank"
]
}
}
],
"alsoIn": [
"a27",
"a18"
]
},
{
"id": "pf-box-extension",
"cat": "a04",
"sub": "Box Accessories",
"name": "Box Extension / Extender",
"desc": "Select the options that apply to request the exact box extension / extender you need.",
"aliases": [
"goof ring",
"extension ring",
"box extender",
"spark guard",
"box extension"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Box Extension Ring",
"Box Extender (Goof Ring)",
"Spark Guard"
]
},
{
"key": "size",
"label": "Fits",
"options": [
"4\" Square",
"4-11/16\" Square",
"Single Gang",
"Octagon"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-box-screw"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-ground-screw",
"cat": "a04",
"sub": "Box Accessories",
"name": "Ground Screw",
"desc": "Select the options that apply to request the exact ground screw you need.",
"aliases": [
"green screw",
"ground screw",
"grounding screw"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"10-32 x 3/8\"",
"10-32 x 1/2\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-ground-pigtail",
"pf-box-4sq"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-ground-pigtail",
"cat": "a04",
"sub": "Box Accessories",
"name": "Grounding Pigtail",
"desc": "Select the options that apply to request the exact grounding pigtail you need.",
"aliases": [
"pigtail",
"ground pigtail",
"ground tail",
"green pigtail",
"grounding tail"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Bare Copper",
"Green Insulated"
]
},
{
"key": "gauge",
"label": "Gauge",
"options": [
"#12",
"#10"
]
},
{
"key": "length",
"label": "Length",
"options": [
"6\"",
"8\"",
"12\""
],
"default": "6\""
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-ground-screw"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-box-screw",
"cat": "a04",
"sub": "Box Accessories",
"name": "Box / Cover / Device Screw",
"desc": "Select the options that apply to request the exact box / cover / device screw you need.",
"aliases": [
"box screws",
"device screws",
"cover screws",
"6-32 screw",
"8-32 screw"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Box Screw",
"Cover Screw",
"Device Screw"
]
},
{
"key": "thread",
"label": "Thread",
"options": [
"6-32",
"8-32",
"10-32"
]
},
{
"key": "length",
"label": "Length",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/2\"",
"2\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-ko-seal",
"cat": "a04",
"sub": "Box Accessories",
"name": "Knockout Seal / Plug",
"desc": "Select the options that apply to request the exact knockout seal / plug you need.",
"aliases": [
"ko seal",
"knockout seal",
"ko plug",
"knockout plug",
"ko closure",
"ko cover"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"KO Seal",
"KO Plug (Push-In)"
]
},
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-reducing-washer",
"cat": "a04",
"sub": "Box Accessories",
"name": "Reducing Washer",
"desc": "Select the options that apply to request the exact reducing washer you need.",
"aliases": [
"reducing washer",
"reducing washers",
"reducer washer"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"3/4\" x 1/2\"",
"1\" x 1/2\"",
"1\" x 3/4\"",
"1-1/4\" x 1\"",
"1-1/2\" x 1-1/4\"",
"2\" x 1-1/2\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-locknut"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-nail-plate",
"cat": "a04",
"sub": "Box Accessories",
"name": "Nail Plate / Stud Guard",
"desc": "Select the options that apply to request the exact nail plate / stud guard you need.",
"aliases": [
"nail plate",
"stud guard",
"protection plate",
"stud plate"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Nail Plate",
"Stud Guard"
]
},
{
"key": "length",
"label": "Size",
"options": [
"Standard",
"Long"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-nmb"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-cb-lb",
"cat": "a05",
"sub": "Conduit Bodies",
"name": "LB Conduit Body",
"desc": "Select the options that apply to request the exact lb conduit body you need.",
"aliases": [
"lb",
"lb fitting",
"lb body",
"condulet",
"pull fitting",
"lb conduit body"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
},
{
"key": "material",
"label": "Material",
"options": [
"Aluminum",
"Malleable Iron",
"PVC"
]
},
{
"key": "conduit",
"label": "Conduit Type",
"options": [
"Rigid / IMC (Threaded)",
"EMT (Set-Screw)",
"EMT (Compression)",
"PVC"
]
}
],
"brandOptions": [],
"imageFamilyKey": "cf-conduit-bodies",
"frequentlyUsedWith": [
"pf-cb-cover",
"pf-cb-gasket"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"material": [
"PVC"
]
},
"limit": {
"conduit": [
"PVC"
]
}
},
{
"when": {
"conduit": [
"PVC"
]
},
"limit": {
"material": [
"PVC"
]
}
}
]
},
{
"id": "pf-cb-ll",
"cat": "a05",
"sub": "Conduit Bodies",
"name": "LL Conduit Body",
"desc": "Select the options that apply to request the exact ll conduit body you need.",
"aliases": [
"ll",
"ll fitting",
"ll body"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
},
{
"key": "material",
"label": "Material",
"options": [
"Aluminum",
"Malleable Iron",
"PVC"
]
},
{
"key": "conduit",
"label": "Conduit Type",
"options": [
"Rigid / IMC (Threaded)",
"EMT (Set-Screw)",
"EMT (Compression)",
"PVC"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-cb-cover",
"pf-cb-gasket"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"material": [
"PVC"
]
},
"limit": {
"conduit": [
"PVC"
]
}
},
{
"when": {
"conduit": [
"PVC"
]
},
"limit": {
"material": [
"PVC"
]
}
}
]
},
{
"id": "pf-cb-lr",
"cat": "a05",
"sub": "Conduit Bodies",
"name": "LR Conduit Body",
"desc": "Select the options that apply to request the exact lr conduit body you need.",
"aliases": [
"lr",
"lr fitting",
"lr body"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
},
{
"key": "material",
"label": "Material",
"options": [
"Aluminum",
"Malleable Iron",
"PVC"
]
},
{
"key": "conduit",
"label": "Conduit Type",
"options": [
"Rigid / IMC (Threaded)",
"EMT (Set-Screw)",
"EMT (Compression)",
"PVC"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-cb-cover",
"pf-cb-gasket"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"material": [
"PVC"
]
},
"limit": {
"conduit": [
"PVC"
]
}
},
{
"when": {
"conduit": [
"PVC"
]
},
"limit": {
"material": [
"PVC"
]
}
}
]
},
{
"id": "pf-cb-c",
"cat": "a05",
"sub": "Conduit Bodies",
"name": "C Conduit Body",
"desc": "Select the options that apply to request the exact c conduit body you need.",
"aliases": [
"c",
"c body",
"c fitting",
"c conduit body"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
},
{
"key": "material",
"label": "Material",
"options": [
"Aluminum",
"Malleable Iron",
"PVC"
]
},
{
"key": "conduit",
"label": "Conduit Type",
"options": [
"Rigid / IMC (Threaded)",
"EMT (Set-Screw)",
"EMT (Compression)",
"PVC"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-cb-cover",
"pf-cb-gasket"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"material": [
"PVC"
]
},
"limit": {
"conduit": [
"PVC"
]
}
},
{
"when": {
"conduit": [
"PVC"
]
},
"limit": {
"material": [
"PVC"
]
}
}
]
},
{
"id": "pf-cb-t",
"cat": "a05",
"sub": "Conduit Bodies",
"name": "T Conduit Body",
"desc": "Select the options that apply to request the exact t conduit body you need.",
"aliases": [
"t",
"t body",
"t fitting",
"tee body"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
},
{
"key": "material",
"label": "Material",
"options": [
"Aluminum",
"Malleable Iron",
"PVC"
]
},
{
"key": "conduit",
"label": "Conduit Type",
"options": [
"Rigid / IMC (Threaded)",
"EMT (Set-Screw)",
"EMT (Compression)",
"PVC"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-cb-cover",
"pf-cb-gasket"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"material": [
"PVC"
]
},
"limit": {
"conduit": [
"PVC"
]
}
},
{
"when": {
"conduit": [
"PVC"
]
},
"limit": {
"material": [
"PVC"
]
}
}
]
},
{
"id": "pf-cb-x",
"cat": "a05",
"sub": "Conduit Bodies",
"name": "X Conduit Body",
"desc": "Select the options that apply to request the exact x conduit body you need.",
"aliases": [
"x",
"x body",
"cross body"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
},
{
"key": "material",
"label": "Material",
"options": [
"Aluminum",
"Malleable Iron",
"PVC"
]
},
{
"key": "conduit",
"label": "Conduit Type",
"options": [
"Rigid / IMC (Threaded)",
"EMT (Set-Screw)",
"EMT (Compression)",
"PVC"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-cb-cover",
"pf-cb-gasket"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"material": [
"PVC"
]
},
"limit": {
"conduit": [
"PVC"
]
}
},
{
"when": {
"conduit": [
"PVC"
]
},
"limit": {
"material": [
"PVC"
]
}
}
]
},
{
"id": "pf-cb-cover",
"cat": "a05",
"sub": "Conduit Body Accessories",
"name": "Conduit Body Cover",
"desc": "Select the options that apply to request the exact conduit body cover you need.",
"aliases": [
"conduit body cover",
"lb cover",
"condulet cover"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
},
{
"key": "material",
"label": "Material",
"options": [
"Steel",
"Aluminum",
"PVC"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-cb-gasket",
"pf-cb-screws"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-cb-gasket",
"cat": "a05",
"sub": "Conduit Body Accessories",
"name": "Conduit Body Gasket",
"desc": "Select the options that apply to request the exact conduit body gasket you need.",
"aliases": [
"conduit body gasket",
"lb gasket"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-cb-cover"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-cb-screws",
"cat": "a05",
"sub": "Conduit Body Accessories",
"name": "Conduit Body Cover Screws",
"desc": "Select the options that apply to request the exact conduit body cover screws you need.",
"aliases": [
"lb screws",
"cover screws"
],
"unit": "PACK",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Fits Size",
"options": [
"1/2\"–3/4\"",
"1\"–2\"",
"2-1/2\"–4\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-cb-cover"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-strap-1h",
"cat": "a06",
"sub": "Conduit Supports",
"name": "One-Hole Strap",
"desc": "Select the options that apply to request the exact one-hole strap you need.",
"aliases": [
"one hole strap",
"1 hole strap",
"strap",
"emt strap",
"conduit strap"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "conduit",
"label": "Conduit Type",
"options": [
"EMT",
"Rigid / IMC",
"PVC"
]
},
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
},
{
"key": "material",
"label": "Material",
"options": [
"Steel",
"Malleable Iron",
"PVC"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"cn-family-emt",
"pf-metal-screw",
"pf-concrete-screw"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"conduit": [
"PVC"
]
},
"limit": {
"material": [
"PVC"
]
}
},
{
"when": {
"material": [
"PVC"
]
},
"limit": {
"conduit": [
"PVC"
]
}
}
]
},
{
"id": "pf-strap-2h",
"cat": "a06",
"sub": "Conduit Supports",
"name": "Two-Hole Strap",
"desc": "Select the options that apply to request the exact two-hole strap you need.",
"aliases": [
"two hole strap",
"2 hole strap"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "conduit",
"label": "Conduit Type",
"options": [
"EMT",
"Rigid / IMC",
"PVC"
]
},
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
},
{
"key": "material",
"label": "Material",
"options": [
"Steel",
"PVC"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"cn-family-emt",
"pf-metal-screw"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"conduit": [
"PVC"
]
},
"limit": {
"material": [
"PVC"
]
}
},
{
"when": {
"material": [
"PVC"
]
},
"limit": {
"conduit": [
"PVC"
]
}
}
]
},
{
"id": "pf-conduit-hanger",
"cat": "a06",
"sub": "Conduit Supports",
"name": "Conduit Hanger",
"desc": "Select the options that apply to request the exact conduit hanger you need.",
"aliases": [
"conduit hanger",
"clevis",
"clevis hanger",
"pipe hanger"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Standard Hanger",
"Clevis Hanger"
]
},
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
},
{
"key": "rod",
"label": "Rod Size",
"options": [
"1/4\"",
"3/8\"",
"1/2\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-rod",
"pf-nut"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-minerallac",
"cat": "a06",
"sub": "Conduit Supports",
"name": "Mineralac-Type Strap",
"desc": "Select the options that apply to request the exact mineralac-type strap you need.",
"aliases": [
"mineralac",
"minerallac",
"hanger strap"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-rod"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-standoff-strap",
"cat": "a06",
"sub": "Conduit Supports",
"name": "Stand-Off Strap (Clamp-Back)",
"desc": "Select the options that apply to request the exact stand-off strap (clamp-back) you need.",
"aliases": [
"standoff strap",
"clamp back",
"pipe spacer",
"stand off"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-mc-strap",
"cat": "a06",
"sub": "Cable Supports",
"name": "MC Strap / Clip",
"desc": "Select the options that apply to request the exact mc strap / clip you need.",
"aliases": [
"mc strap",
"mc clip",
"mc staple",
"bx strap"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"One-Hole MC Strap",
"Two-Hole MC Strap",
"Push-On MC Clip"
]
},
{
"key": "cables",
"label": "Cables",
"options": [
"1 Cable",
"2 Cables"
],
"default": "1 Cable"
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-mc"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-cable-stacker",
"cat": "a06",
"sub": "Cable Supports",
"name": "Cable Stacker",
"desc": "Select the options that apply to request the exact cable stacker you need.",
"aliases": [
"stacker",
"cable stacker",
"mc stacker"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "capacity",
"label": "Capacity",
"options": [
"2 Cables",
"4 Cables",
"6 Cables"
]
},
{
"key": "mount",
"label": "Mounting",
"options": [
"Stud (Side Mount)",
"Threaded Rod",
"Beam Flange"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-mc"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-jhook",
"cat": "a06",
"sub": "Cable Supports",
"name": "J-Hook",
"desc": "Select the options that apply to request the exact j-hook you need.",
"aliases": [
"j hook",
"jhook",
"j-hook",
"cat hook",
"cable hook"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"3/4\"",
"1-5/16\"",
"1-1/2\"",
"2\"",
"4\""
]
},
{
"key": "mount",
"label": "Mounting",
"options": [
"Beam Clamp",
"Screw-On",
"Threaded Rod",
"Wire / Ceiling Wire"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-cat",
"pf-bridle-ring"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a22"
]
},
{
"id": "pf-bridle-ring",
"cat": "a06",
"sub": "Cable Supports",
"name": "Bridle Ring",
"desc": "Select the options that apply to request the exact bridle ring you need.",
"aliases": [
"bridal ring",
"bridle ring",
"d ring"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/4\"",
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"2\""
]
},
{
"key": "mount",
"label": "Mounting",
"options": [
"Screw",
"Beam Clamp",
"Threaded Rod"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-cat",
"pf-jhook"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a22"
]
},
{
"id": "pf-cable-staple",
"cat": "a06",
"sub": "Cable Supports",
"name": "Cable Staple (NM)",
"desc": "Select the options that apply to request the exact cable staple (nm) you need.",
"aliases": [
"romex staple",
"staple",
"nm staple",
"cable staple"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Plastic Insulated",
"Metal"
]
},
{
"key": "size",
"label": "Size",
"options": [
"Single Cable",
"Stacked (2 Cables)"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-nmb"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-beam-clamp",
"cat": "a06",
"sub": "Beam Attachments",
"name": "Beam Clamp",
"desc": "Select the options that apply to request the exact beam clamp you need.",
"aliases": [
"beam clamp",
"c clamp",
"c-clamp",
"hammer on clamp",
"rod clamp",
"beam attachment"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Standard Beam Clamp",
"C-Clamp",
"Hammer-On Beam Clamp",
"Rod-to-Beam Clamp"
]
},
{
"key": "rod",
"label": "Rod Size",
"options": [
"1/4\"",
"3/8\"",
"1/2\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-rod",
"pf-nut",
"pf-washer"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-purlin-clip",
"cat": "a06",
"sub": "Beam Attachments",
"name": "Purlin / Flange Clip",
"desc": "Select the options that apply to request the exact purlin / flange clip you need.",
"aliases": [
"purlin clip",
"flange clip"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Purlin Clip",
"Flange Clip"
]
},
{
"key": "flange",
"label": "Flange Thickness",
"options": [
"1/8\"–1/4\"",
"1/4\"–1/2\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-conduit-beam-clip",
"cat": "a06",
"sub": "Beam Attachments",
"name": "Conduit-to-Beam Clip",
"desc": "Select the options that apply to request the exact conduit-to-beam clip you need.",
"aliases": [
"conduit clip",
"beam clip",
"conduit to beam"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Conduit Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\""
]
},
{
"key": "flange",
"label": "Flange Thickness",
"options": [
"1/8\"–1/4\"",
"1/4\"–1/2\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"cn-family-emt"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-mc-beam-clip",
"cat": "a06",
"sub": "Beam Attachments",
"name": "MC-to-Beam Clip",
"desc": "Select the options that apply to request the exact mc-to-beam clip you need.",
"aliases": [
"mc clip",
"mc beam clip",
"mc to beam"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "capacity",
"label": "Capacity",
"options": [
"1 Cable",
"2 Cables",
"4 Cables"
]
},
{
"key": "flange",
"label": "Flange Thickness",
"options": [
"1/8\"–1/4\"",
"1/4\"–1/2\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-mc"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-box-beam-hanger",
"cat": "a06",
"sub": "Beam Attachments",
"name": "Box-to-Beam Hanger",
"desc": "Select the options that apply to request the exact box-to-beam hanger you need.",
"aliases": [
"box hanger",
"box to beam"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "flange",
"label": "Flange Thickness",
"options": [
"1/8\"–1/4\"",
"1/4\"–1/2\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-box-4sq"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-strut",
"cat": "a06",
"sub": "Strut / Unistrut",
"name": "Strut Channel",
"desc": "Select the options that apply to request the exact strut channel you need.",
"aliases": [
"unistrut",
"strut",
"kindorf",
"channel",
"uni-strut",
"b-line",
"superstrut",
"unistrut channel"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "profile",
"label": "Profile",
"options": [
"1-5/8\" x 1-5/8\"",
"1-5/8\" x 13/16\""
]
},
{
"key": "style",
"label": "Style",
"options": [
"Slotted",
"Solid",
"Back-to-Back"
]
},
{
"key": "length",
"label": "Length",
"options": [
"10'",
"20'"
],
"default": "10'"
},
{
"key": "finish",
"label": "Finish",
"options": [
"Pre-Galvanized",
"Hot-Dip Galvanized",
"Stainless Steel"
],
"default": "Pre-Galvanized"
}
],
"brandOptions": [
"Unistrut",
"Eaton B-Line"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-strut-nut",
"pf-strut-bolt",
"pf-strut-clamp",
"pf-rod",
"pf-strut-fitting"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-strut-nut",
"cat": "a06",
"sub": "Strut / Unistrut",
"name": "Strut Nut",
"desc": "Select the options that apply to request the exact strut nut you need.",
"aliases": [
"spring nut",
"channel nut",
"uni nut",
"strut nut",
"cone nut"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Spring Nut",
"Channel Nut (No Spring)",
"Cone Nut"
]
},
{
"key": "thread",
"label": "Thread",
"options": [
"1/4\"",
"5/16\"",
"3/8\"",
"1/2\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-strut",
"pf-strut-bolt"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-strut-washer",
"cat": "a06",
"sub": "Strut / Unistrut",
"name": "Strut Washer",
"desc": "Select the options that apply to request the exact strut washer you need.",
"aliases": [
"square washer",
"strut washer"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Square Washer",
"Strut Washer (Channel)"
]
},
{
"key": "bolt",
"label": "Bolt Size",
"options": [
"1/4\"",
"3/8\"",
"1/2\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-strut"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-strut-bolt",
"cat": "a06",
"sub": "Strut / Unistrut",
"name": "Strut Bolt (Hex Cap Screw)",
"desc": "Select the options that apply to request the exact strut bolt (hex cap screw) you need.",
"aliases": [
"strut bolt",
"hex cap screw"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/4\"",
"3/8\"",
"1/2\""
]
},
{
"key": "length",
"label": "Length",
"options": [
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-strut-nut"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-strut-fitting",
"cat": "a06",
"sub": "Strut / Unistrut",
"name": "Strut Fitting",
"desc": "Select the options that apply to request the exact strut fitting you need.",
"aliases": [
"strut fitting",
"unistrut fitting",
"angle fitting",
"flat plate",
"post base",
"splice plate",
"wing fitting"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Post Base",
"Angle Fitting",
"90° Fitting",
"T-Fitting",
"U-Fitting",
"Flat Plate",
"Splice Plate",
"Wing Fitting"
]
},
{
"key": "holes",
"label": "Holes",
"options": [
"2-Hole",
"3-Hole",
"4-Hole",
"5-Hole"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-strut",
"pf-strut-nut",
"pf-strut-bolt"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-strut-clamp",
"cat": "a06",
"sub": "Strut / Unistrut",
"name": "Strut Conduit / Pipe Clamp",
"desc": "Select the options that apply to request the exact strut conduit / pipe clamp you need.",
"aliases": [
"unistrut clamp",
"strut strap",
"cushion clamp",
"cushioned clamp",
"pipe clamp"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Strut Clamp (Standard)",
"Cushioned Clamp",
"Pipe Clamp"
]
},
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-strut",
"cn-family-emt"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-strut-endcap",
"cat": "a06",
"sub": "Strut / Unistrut",
"name": "Strut End Cap",
"desc": "Select the options that apply to request the exact strut end cap you need.",
"aliases": [
"end cap",
"strut cap"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "profile",
"label": "Profile",
"options": [
"1-5/8\" x 1-5/8\"",
"1-5/8\" x 13/16\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-strut"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-rod",
"cat": "a06",
"sub": "Threaded Rod",
"name": "Threaded Rod (All-Thread)",
"desc": "Select the options that apply to request the exact threaded rod (all-thread) you need.",
"aliases": [
"all thread",
"allthread",
"threaded rod",
"rod",
"ready rod",
"redi rod"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/4\"",
"3/8\"",
"1/2\"",
"5/8\"",
"3/4\""
]
},
{
"key": "length",
"label": "Length",
"options": [
"3'",
"6'",
"10'",
"12'"
],
"default": "10'"
},
{
"key": "material",
"label": "Material",
"options": [
"Zinc-Plated Steel",
"Hot-Dip Galvanized",
"Stainless Steel"
],
"default": "Zinc-Plated Steel"
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-rod-coupling",
"pf-nut",
"pf-washer",
"pf-beam-clamp",
"pf-rod-anchor"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-rod-coupling",
"cat": "a06",
"sub": "Threaded Rod",
"name": "Rod Coupling",
"desc": "Select the options that apply to request the exact rod coupling you need.",
"aliases": [
"rod coupling",
"coupling nut"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/4\"",
"3/8\"",
"1/2\"",
"5/8\"",
"3/4\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-rod"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-nut",
"cat": "a06",
"sub": "Threaded Rod",
"name": "Nut",
"desc": "Select the options that apply to request the exact nut you need.",
"aliases": [
"nut",
"hex nut",
"lock nut",
"nylon lock nut",
"nylock"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Hex Nut",
"Nylon Lock Nut",
"Flange Nut"
]
},
{
"key": "size",
"label": "Size",
"options": [
"1/4\"",
"5/16\"",
"3/8\"",
"1/2\"",
"5/8\"",
"3/4\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-rod",
"pf-washer"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-washer",
"cat": "a06",
"sub": "Threaded Rod",
"name": "Washer",
"desc": "Select the options that apply to request the exact washer you need.",
"aliases": [
"washer",
"flat washer",
"fender washer",
"lock washer",
"split washer"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Flat Washer",
"Fender Washer",
"Split Lock Washer"
]
},
{
"key": "size",
"label": "Size",
"options": [
"1/4\"",
"5/16\"",
"3/8\"",
"1/2\"",
"5/8\"",
"3/4\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-nut"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-rod-anchor",
"cat": "a06",
"sub": "Threaded Rod",
"name": "Rod Hanger / Anchor",
"desc": "Select the options that apply to request the exact rod hanger / anchor you need.",
"aliases": [
"sammy",
"sammys",
"rod hanger",
"eye rod",
"eye bolt",
"rod anchor"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Concrete Rod Hanger (Drop-In)",
"Beam Rod Hanger",
"Rod Anchor (Wedge-Type)",
"Sammy-Type Screw",
"Eye Rod"
]
},
{
"key": "rod",
"label": "Rod Size",
"options": [
"1/4\"",
"3/8\"",
"1/2\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-rod"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-concrete-screw",
"cat": "a06",
"sub": "Anchors & Fasteners",
"name": "Concrete Screw (Tapcon-Type)",
"desc": "Select the options that apply to request the exact concrete screw (tapcon-type) you need.",
"aliases": [
"tapcon",
"concrete screw",
"blue screw",
"masonry screw"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "dia",
"label": "Diameter",
"options": [
"3/16\"",
"1/4\""
]
},
{
"key": "length",
"label": "Length",
"options": [
"1-1/4\"",
"1-3/4\"",
"2-1/4\"",
"2-3/4\"",
"3-1/4\"",
"3-3/4\""
]
},
{
"key": "head",
"label": "Head",
"options": [
"Hex Washer",
"Flat Phillips"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-strap-1h"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-concrete-anchor",
"cat": "a06",
"sub": "Anchors & Fasteners",
"name": "Concrete Anchor",
"desc": "Select the options that apply to request the exact concrete anchor you need.",
"aliases": [
"wedge anchor",
"sleeve anchor",
"drop in anchor",
"drop-in",
"lead anchor",
"concrete anchor"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Wedge Anchor",
"Sleeve Anchor",
"Drop-In Anchor",
"Lead Anchor"
]
},
{
"key": "dia",
"label": "Diameter",
"options": [
"1/4\"",
"3/8\"",
"1/2\"",
"5/8\""
]
},
{
"key": "length",
"label": "Length",
"options": [
"Standard",
"1-3/4\"",
"2-1/4\"",
"3\"",
"3-3/4\"",
"5\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Drop-In Anchor",
"Lead Anchor"
]
},
"limit": {
"length": [
"Standard"
]
}
},
{
"when": {
"type": [
"Wedge Anchor",
"Sleeve Anchor"
]
},
"limit": {
"length": [
"1-3/4\"",
"2-1/4\"",
"3\"",
"3-3/4\"",
"5\""
]
}
}
]
},
{
"id": "pf-hollow-anchor",
"cat": "a06",
"sub": "Anchors & Fasteners",
"name": "Hollow-Wall Anchor",
"desc": "Select the options that apply to request the exact hollow-wall anchor you need.",
"aliases": [
"toggle",
"toggle bolt",
"molly",
"molly bolt",
"drywall anchor",
"plastic anchor"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Toggle Bolt",
"Molly Anchor",
"Plastic Anchor"
]
},
{
"key": "size",
"label": "Size",
"options": [
"1/8\"",
"3/16\"",
"1/4\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-wood-screw",
"cat": "a06",
"sub": "Anchors & Fasteners",
"name": "Wood / Lag Screw",
"desc": "Select the options that apply to request the exact wood / lag screw you need.",
"aliases": [
"wood screw",
"lag screw",
"lag bolt"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Wood Screw",
"Lag Screw"
]
},
{
"key": "size",
"label": "Size",
"options": [
"#8",
"#10",
"#12",
"1/4\"",
"5/16\"",
"3/8\""
]
},
{
"key": "length",
"label": "Length",
"options": [
"1\"",
"1-1/2\"",
"2\"",
"3\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Wood Screw"
]
},
"limit": {
"size": [
"#8",
"#10",
"#12"
]
}
},
{
"when": {
"type": [
"Lag Screw"
]
},
"limit": {
"size": [
"1/4\"",
"5/16\"",
"3/8\""
]
}
}
]
},
{
"id": "pf-metal-screw",
"cat": "a06",
"sub": "Anchors & Fasteners",
"name": "Sheet-Metal / Self-Drilling Screw",
"desc": "Select the options that apply to request the exact sheet-metal / self-drilling screw you need.",
"aliases": [
"tek screw",
"tek",
"tek screws",
"self tapper",
"self drilling",
"self tapping",
"sheet metal screw",
"zip screw"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Sheet-Metal Screw",
"Self-Drilling (Tek) Screw",
"Self-Tapping Screw"
]
},
{
"key": "size",
"label": "Size",
"options": [
"#8",
"#10",
"#12",
"1/4\""
]
},
{
"key": "length",
"label": "Length",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/2\""
]
},
{
"key": "head",
"label": "Head",
"options": [
"Hex Washer",
"Pan"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-machine-screw",
"cat": "a06",
"sub": "Anchors & Fasteners",
"name": "Machine Screw",
"desc": "Select the options that apply to request the exact machine screw you need.",
"aliases": [
"machine screw",
"10-32 screw",
"1/4-20"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "thread",
"label": "Thread",
"options": [
"6-32",
"8-32",
"10-24",
"10-32",
"1/4-20"
]
},
{
"key": "length",
"label": "Length",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/2\"",
"2\""
]
},
{
"key": "head",
"label": "Head",
"options": [
"Pan",
"Flat",
"Round"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-bolt",
"cat": "a06",
"sub": "Anchors & Fasteners",
"name": "Bolt",
"desc": "Select the options that apply to request the exact bolt you need.",
"aliases": [
"hex bolt",
"carriage bolt",
"bolt"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Hex Bolt",
"Carriage Bolt"
]
},
{
"key": "size",
"label": "Size",
"options": [
"1/4\"",
"5/16\"",
"3/8\"",
"1/2\""
]
},
{
"key": "length",
"label": "Length",
"options": [
"1\"",
"1-1/2\"",
"2\"",
"3\"",
"4\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-nut",
"pf-washer"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-rivet",
"cat": "a06",
"sub": "Anchors & Fasteners",
"name": "Rivet (Blind / Pop)",
"desc": "Select the options that apply to request the exact rivet (blind / pop) you need.",
"aliases": [
"pop rivet",
"rivet",
"blind rivet"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "dia",
"label": "Diameter",
"options": [
"1/8\"",
"3/16\""
]
},
{
"key": "grip",
"label": "Grip",
"options": [
"Short",
"Medium",
"Long"
]
},
{
"key": "material",
"label": "Material",
"options": [
"Aluminum",
"Steel"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-winenut",
"cat": "a07",
"sub": "Small Conductors",
"name": "Wire Nut",
"desc": "Select the options that apply to request the exact wire nut you need.",
"aliases": [
"wire nut",
"wirenut",
"wire nuts",
"twist on connector",
"marrette",
"winged wire nut",
"red wire nut",
"yellow wire nut"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"Small (2-3 #18-#12)",
"Medium (3-4 #14-#10)",
"Large (4-6 #12-#8)"
]
},
{
"key": "color",
"label": "Color",
"options": [
"Orange",
"Yellow",
"Red",
"Blue",
"Gray",
"Tan"
]
},
{
"key": "style",
"label": "Style",
"options": [
"Standard",
"Winged"
],
"default": "Standard"
}
],
"brandOptions": [
"Ideal",
"3M",
"King Innovation"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-thhn",
"pf-ground-pigtail"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-pushin",
"cat": "a07",
"sub": "Small Conductors",
"name": "Push-In Wire Connector",
"desc": "Select the options that apply to request the exact push-in wire connector you need.",
"aliases": [
"push in connector",
"push-in",
"push wire connector"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "ports",
"label": "Ports",
"options": [
"2-Port",
"3-Port",
"4-Port",
"5-Port",
"8-Port"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-thhn"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-lever",
"cat": "a07",
"sub": "Small Conductors",
"name": "Lever (WAGO-Type) Connector",
"desc": "Select the options that apply to request the exact lever (wago-type) connector you need.",
"aliases": [
"wago",
"wago connector",
"lever nut",
"lever nuts",
"lever connector"
],
"unit": "EA",
"altUnits": [
"PACK",
"BOX"
],
"variants": [
{
"key": "ports",
"label": "Ports",
"options": [
"2-Port",
"3-Port",
"5-Port"
]
}
],
"brandOptions": [
"WAGO",
"Ideal"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-thhn"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-crimp",
"cat": "a07",
"sub": "Crimp Terminals",
"name": "Crimp Terminal / Splice",
"desc": "Select the options that apply to request the exact crimp terminal / splice you need.",
"aliases": [
"butt connector",
"butt splice",
"ring terminal",
"spade",
"spade terminal",
"fork terminal",
"quick disconnect",
"crimp",
"crimp connector"
],
"unit": "EA",
"altUnits": [
"BOX",
"PACK"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Butt Splice",
"Ring Terminal",
"Fork (Spade) Terminal",
"Male Quick Disconnect",
"Female Quick Disconnect",
"Parallel Splice"
]
},
{
"key": "gauge",
"label": "Wire Gauge",
"options": [
"22-18 AWG (Red)",
"16-14 AWG (Blue)",
"12-10 AWG (Yellow)"
]
},
{
"key": "insulation",
"label": "Insulation",
"options": [
"Vinyl Insulated",
"Nylon Insulated",
"Heat-Shrink",
"Non-Insulated"
]
},
{
"key": "stud",
"label": "Stud Size",
"options": [
"N/A",
"#6",
"#8",
"#10",
"1/4\"",
"5/16\"",
"3/8\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Ring Terminal",
"Fork (Spade) Terminal"
]
},
"limit": {
"stud": [
"#6",
"#8",
"#10",
"1/4\"",
"5/16\"",
"3/8\""
]
}
},
{
"when": {
"type": [
"Butt Splice",
"Male Quick Disconnect",
"Female Quick Disconnect",
"Parallel Splice"
]
},
"limit": {
"stud": [
"N/A"
]
}
}
]
},
{
"id": "pf-split-bolt",
"cat": "a07",
"sub": "Large Conductors",
"name": "Split Bolt",
"desc": "Select the options that apply to request the exact split bolt you need.",
"aliases": [
"split bolt",
"splitbolt"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "size",
"label": "Max Conductor",
"options": [
"#10",
"#8",
"#6",
"#4",
"#2",
"1/0",
"2/0",
"4/0",
"250 kcmil",
"350 kcmil",
"500 kcmil"
]
},
{
"key": "material",
"label": "Rating",
"options": [
"Copper",
"Copper / Aluminum"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-tape"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-polaris",
"cat": "a07",
"sub": "Large Conductors",
"name": "Insulated Multi-Tap Connector",
"desc": "Select the options that apply to request the exact insulated multi-tap connector you need.",
"aliases": [
"polaris",
"polaris connector",
"multi tap",
"multitap",
"multi-tap",
"insulated tap",
"tap connector"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "ports",
"label": "Ports",
"options": [
"2-Port",
"3-Port",
"4-Port",
"5-Port",
"6-Port"
]
},
{
"key": "range",
"label": "Conductor Range",
"options": [
"#14-#4",
"#6-1/0",
"2-4/0",
"4/0-350 kcmil",
"250-500 kcmil"
]
}
],
"brandOptions": [
"NSi Industries"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-ser",
"pf-lug"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-lug",
"cat": "a07",
"sub": "Large Conductors",
"name": "Lug",
"desc": "Select the options that apply to request the exact lug you need.",
"aliases": [
"lug",
"mechanical lug",
"compression lug",
"crimp lug",
"al/cu lug",
"copper lug",
"aluminum lug",
"bimetal lug"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Mechanical Lug",
"Compression Lug"
]
},
{
"key": "material",
"label": "Material",
"options": [
"Copper",
"Aluminum (AL9CU)",
"Bi-Metal"
]
},
{
"key": "range",
"label": "Conductor Range",
"options": [
"#14-#6",
"#6-1/0",
"#4-2/0",
"#2-4/0",
"1/0-250 kcmil",
"250-350 kcmil",
"250-500 kcmil",
"500-750 kcmil"
]
},
{
"key": "holes",
"label": "Mounting",
"options": [
"1 Hole",
"2 Hole",
"Dual Conductor"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-sealant",
"pf-heat-shrink"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Compression Lug"
]
},
"limit": {
"holes": [
"1 Hole",
"2 Hole"
]
}
}
]
},
{
"id": "pf-ground-lug",
"cat": "a07",
"sub": "Large Conductors",
"name": "Ground Lug (Lay-In)",
"desc": "Select the options that apply to request the exact ground lug (lay-in) you need.",
"aliases": [
"lay in lug",
"ground lug",
"lay-in lug"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "range",
"label": "Conductor Range",
"options": [
"#14-#4",
"#10-#2",
"#4-4/0"
]
},
{
"key": "material",
"label": "Material",
"options": [
"Tin-Plated Aluminum",
"Copper"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-ground-wire"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a08"
]
},
{
"id": "pf-groundrod",
"cat": "a08",
"sub": "Ground Rods",
"name": "Ground Rod",
"desc": "Driven grounding electrode for the service grounding system.",
"aliases": [
"ground rod",
"grounding rod",
"copper rod",
"ground stake",
"driven rod"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "diameter",
"label": "Diameter",
"options": [
"1/2\"",
"5/8\"",
"3/4\""
]
},
{
"key": "length",
"label": "Length",
"options": [
"8 ft",
"10 ft"
]
},
{
"key": "material",
"label": "Material",
"options": [
"Copper-Clad Steel",
"Galvanized Steel"
],
"default": "Copper-Clad Steel"
}
],
"brandOptions": [
"nVent ERICO"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-groundclamp",
"pf-ground-wire",
"pf-rod-hardware"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-groundclamp",
"cat": "a08",
"sub": "Grounding Hardware",
"name": "Ground Clamp",
"desc": "Select the options that apply to request the exact ground clamp you need.",
"aliases": [
"ground clamp",
"acorn",
"acorn clamp",
"ground rod clamp",
"water pipe clamp",
"bronze clamp",
"beam ground clamp"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Rod / Pipe Size",
"options": [
"5/8\"",
"3/4\"",
"1\"",
"1/2\" Pipe",
"3/4\" Pipe",
"1\" Pipe",
"1-1/4\" Pipe",
"2\" Pipe",
"Beam Flange"
]
},
{
"key": "type",
"label": "Type",
"options": [
"Acorn Clamp",
"Ground Rod Clamp (U-Bolt)",
"Water-Pipe Clamp",
"Bronze Ground Clamp",
"Beam Ground Clamp"
]
}
],
"brandOptions": [
"nVent ERICO",
"Burndy"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-groundrod",
"pf-ground-wire"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"size": [
"5/8\"",
"3/4\"",
"1\""
]
},
"limit": {
"type": [
"Acorn Clamp",
"Ground Rod Clamp (U-Bolt)",
"Bronze Ground Clamp"
]
}
},
{
"when": {
"size": [
"1/2\" Pipe",
"3/4\" Pipe",
"1\" Pipe",
"1-1/4\" Pipe",
"2\" Pipe"
]
},
"limit": {
"type": [
"Water-Pipe Clamp",
"Bronze Ground Clamp"
]
}
},
{
"when": {
"size": [
"Beam Flange"
]
},
"limit": {
"type": [
"Beam Ground Clamp"
]
}
}
]
},
{
"id": "pf-rod-hardware",
"cat": "a08",
"sub": "Ground Rods",
"name": "Ground Rod Hardware",
"desc": "Select the options that apply to request the exact ground rod hardware you need.",
"aliases": [
"ground rod coupling",
"driving stud",
"rod point"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Ground Rod Coupling",
"Driving Stud",
"Ground Rod Point"
]
},
{
"key": "diameter",
"label": "Rod Diameter",
"options": [
"1/2\"",
"5/8\"",
"3/4\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-groundrod"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-ground-wire",
"cat": "a08",
"sub": "Grounding Conductors",
"name": "Grounding Conductor",
"desc": "Select the options that apply to request the exact grounding conductor you need.",
"aliases": [
"bare copper",
"ground wire",
"bare ground",
"green wire",
"grounding wire",
"tinned copper",
"#6 bare"
],
"unit": "FT",
"altUnits": [
"ROLL",
"REEL"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Bare Solid Copper",
"Bare Stranded Copper",
"Tinned Copper",
"Green Insulated Copper"
]
},
{
"key": "gauge",
"label": "Gauge",
"options": [
"#14",
"#12",
"#10",
"#8",
"#6",
"#4",
"#2",
"1/0",
"2/0",
"4/0"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-groundrod",
"pf-groundclamp"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Bare Solid Copper"
]
},
"limit": {
"gauge": [
"#14",
"#12",
"#10",
"#8",
"#6",
"#4"
]
}
}
]
},
{
"id": "pf-groundbushing",
"cat": "a08",
"sub": "Grounding Hardware",
"name": "Grounding Bushing",
"desc": "Select the options that apply to request the exact grounding bushing you need.",
"aliases": [
"ground bushing",
"grounding bushing",
"bonding bushing",
"bushing with lug"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
},
{
"key": "type",
"label": "Type",
"options": [
"Grounding (Lay-In Lug)",
"Bonding (No Lug)"
],
"default": "Grounding (Lay-In Lug)"
},
{
"key": "material",
"label": "Material",
"options": [
"Any",
"Malleable Iron",
"Zinc Die-Cast"
],
"default": "Any"
}
],
"brandOptions": [
"Bridgeport Fittings",
"Thomas & Betts"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-rmc",
"pf-ground-wire",
"pf-locknut"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a03"
]
},
{
"id": "pf-bonding-jumper",
"cat": "a08",
"sub": "Grounding Hardware",
"name": "Bonding Jumper",
"desc": "Select the options that apply to request the exact bonding jumper you need.",
"aliases": [
"bonding jumper",
"bonding strap",
"jumper"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Braided Strap",
"Flexible Copper Jumper"
]
},
{
"key": "length",
"label": "Length",
"options": [
"6\"",
"12\"",
"18\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-ground-lug"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-gec-connector",
"cat": "a08",
"sub": "Grounding Hardware",
"name": "Grounding Electrode Connector",
"desc": "Select the options that apply to request the exact grounding electrode connector you need.",
"aliases": [
"ufer clamp",
"rebar clamp",
"gec connector",
"grounding electrode"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "application",
"label": "Application",
"options": [
"Rebar (Ufer)",
"Ground Rod",
"Structural Steel"
]
},
{
"key": "conductor",
"label": "Conductor",
"options": [
"#8-#4",
"#4-2/0"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-ground-wire"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-ibt",
"cat": "a08",
"sub": "Grounding Hardware",
"name": "Intersystem Bonding Termination (IBT)",
"desc": "Select the options that apply to request the exact intersystem bonding termination (ibt) you need.",
"aliases": [
"ibt",
"intersystem bonding",
"bonding bridge"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "terminals",
"label": "Terminals",
"options": [
"3 Terminals",
"4 Terminals"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-ground-wire"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-ground-bar",
"cat": "a08",
"sub": "Grounding Hardware",
"name": "Ground Bar / Ground Bar Kit",
"desc": "Select the options that apply to request the exact ground bar / ground bar kit you need.",
"aliases": [
"ground bar",
"grounding bar",
"ground bar kit",
"tgb",
"tmgb",
"busbar"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Ground Bar (Bare)",
"Panel Ground Bar Kit",
"Telecom Ground Bar (TGB/TMGB)"
]
},
{
"key": "terminals",
"label": "Terminals",
"options": [
"5 Terminal",
"10 Terminal",
"15 Terminal",
"21 Terminal"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-ground-wire"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a10"
]
},
{
"id": "pf-exo-mold",
"cat": "a08",
"sub": "Exothermic",
"name": "Exothermic Weld Mold",
"desc": "Select the options that apply to request the exact exothermic weld mold you need.",
"aliases": [
"cadweld",
"exothermic",
"thermoweld",
"exothermic mold"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "connection",
"label": "Connection",
"options": [
"Cable-to-Cable Tee",
"Cable-to-Rod",
"Cable-to-Steel",
"Cable-to-Lug"
]
},
{
"key": "conductor",
"label": "Conductor",
"options": [
"#6",
"#4",
"#2",
"1/0",
"2/0",
"4/0"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-exo-metal",
"pf-exo-acc"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-exo-metal",
"cat": "a08",
"sub": "Exothermic",
"name": "Exothermic Weld Metal",
"desc": "Select the options that apply to request the exact exothermic weld metal you need.",
"aliases": [
"weld metal",
"cadweld shot",
"exothermic cartridge"
],
"unit": "BOX",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Cartridge Size",
"options": [
"#25",
"#32",
"#45",
"#65",
"#90",
"#115",
"#150",
"#200"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-exo-mold"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-exo-acc",
"cat": "a08",
"sub": "Exothermic",
"name": "Exothermic Accessories",
"desc": "Select the options that apply to request the exact exothermic accessories you need.",
"aliases": [
"cadweld handle",
"flint igniter",
"mold sealer"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Mold Handle Clamp",
"Flint Igniter",
"Mold Sealer",
"Cleaning Brush",
"Slag Scraper"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-exo-mold"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-rcpt-duplex",
"cat": "a09",
"sub": "Receptacles",
"name": "Duplex Receptacle",
"desc": "Select the options that apply to request the exact duplex receptacle you need.",
"aliases": [
"outlet",
"plug",
"receptacle",
"duplex",
"duplex outlet",
"20 amp outlet",
"tr receptacle",
"wr receptacle",
"tamper resistant",
"weather resistant",
"hospital grade",
"spec grade",
"commercial grade"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "amperage",
"label": "Amperage",
"options": [
"15A",
"20A"
]
},
{
"key": "nema",
"label": "NEMA",
"options": [
"5-15R",
"5-20R"
],
"dependsOn": "amperage",
"optionsMap": {
"15A": [
"5-15R"
],
"20A": [
"5-20R"
]
}
},
{
"key": "grade",
"label": "Grade",
"options": [
"Residential",
"Commercial / Specification",
"Industrial / Extra Heavy-Duty",
"Hospital Grade"
]
},
{
"key": "protection",
"label": "Protection",
"options": [
"Standard",
"Tamper-Resistant (TR)",
"Weather-Resistant (WR)",
"TR / WR"
]
},
{
"key": "style",
"label": "Style",
"options": [
"Straight Blade",
"Decora"
]
},
{
"key": "color",
"label": "Color",
"options": [
"White",
"Ivory",
"Light Almond",
"Gray",
"Black",
"Brown",
"Red (Emergency)"
]
}
],
"brandOptions": [
"Leviton",
"Hubbell",
"Pass & Seymour"
],
"imageFamilyKey": "wd-receptacles",
"frequentlyUsedWith": [
"pf-wall-plate",
"pf-box-screw",
"pf-winenut",
"pf-mudring"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a27"
]
},
{
"id": "pf-rcpt-gfci",
"cat": "a09",
"sub": "Receptacles",
"name": "GFCI Receptacle",
"desc": "Select the options that apply to request the exact gfci receptacle you need.",
"aliases": [
"gfci",
"gfi",
"ground fault",
"gfci outlet",
"20 amp gfci",
"gfci receptacle",
"service receptacle",
"hvac service receptacle"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "amperage",
"label": "Amperage",
"options": [
"15A",
"20A"
]
},
{
"key": "protection",
"label": "Protection",
"options": [
"Standard",
"Tamper-Resistant (TR)",
"Weather-Resistant (WR)",
"TR / WR"
]
},
{
"key": "color",
"label": "Color",
"options": [
"White",
"Ivory",
"Light Almond",
"Gray",
"Black",
"Brown"
]
}
],
"brandOptions": [
"Leviton",
"Hubbell",
"Pass & Seymour"
],
"imageFamilyKey": "wd-gfci",
"frequentlyUsedWith": [
"pf-wall-plate",
"pf-wp-cover",
"pf-wp-box"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a18",
"a27"
]
},
{
"id": "pf-rcpt-afci",
"cat": "a09",
"sub": "Receptacles",
"name": "AFCI Receptacle",
"desc": "Select the options that apply to request the exact afci receptacle you need.",
"aliases": [
"afci outlet",
"obc afci",
"arc fault receptacle"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "amperage",
"label": "Amperage",
"options": [
"15A",
"20A"
]
},
{
"key": "protection",
"label": "Protection",
"options": [
"Standard",
"Tamper-Resistant (TR)"
]
},
{
"key": "color",
"label": "Color",
"options": [
"White",
"Ivory",
"Light Almond",
"Gray",
"Black",
"Brown"
]
}
],
"brandOptions": [
"Leviton",
"Hubbell",
"Pass & Seymour"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-wall-plate"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-rcpt-usb",
"cat": "a09",
"sub": "Receptacles",
"name": "USB Charging Receptacle",
"desc": "Select the options that apply to request the exact usb charging receptacle you need.",
"aliases": [
"usb outlet",
"usb-c outlet",
"usb receptacle",
"usb charger outlet"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "ports",
"label": "USB Ports",
"options": [
"USB-A",
"USB-C",
"USB-A/C"
]
},
{
"key": "amperage",
"label": "Amperage",
"options": [
"15A",
"20A"
]
},
{
"key": "color",
"label": "Color",
"options": [
"White",
"Ivory",
"Light Almond",
"Gray",
"Black",
"Brown"
]
}
],
"brandOptions": [
"Leviton",
"Hubbell",
"Pass & Seymour"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-wall-plate"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-rcpt-ig",
"cat": "a09",
"sub": "Receptacles",
"name": "Isolated Ground Receptacle",
"desc": "Select the options that apply to request the exact isolated ground receptacle you need.",
"aliases": [
"ig receptacle",
"orange receptacle",
"isolated ground",
"ig outlet"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "amperage",
"label": "Amperage",
"options": [
"15A",
"20A"
]
},
{
"key": "grade",
"label": "Grade",
"options": [
"Commercial / Specification",
"Hospital Grade"
]
},
{
"key": "color",
"label": "Color",
"options": [
"Orange",
"White (IG Triangle)",
"Gray (IG Triangle)"
]
}
],
"brandOptions": [
"Leviton",
"Hubbell",
"Pass & Seymour"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-mc-ig",
"pf-wall-plate"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-rcpt-surge",
"cat": "a09",
"sub": "Receptacles",
"name": "Surge Protection Receptacle",
"desc": "Select the options that apply to request the exact surge protection receptacle you need.",
"aliases": [
"surge outlet",
"surge receptacle"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "amperage",
"label": "Amperage",
"options": [
"15A",
"20A"
]
},
{
"key": "color",
"label": "Color",
"options": [
"White",
"Ivory",
"Light Almond",
"Gray",
"Black",
"Brown"
]
}
],
"brandOptions": [
"Leviton",
"Hubbell",
"Pass & Seymour"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-wall-plate"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a21"
]
},
{
"id": "pf-rcpt-single",
"cat": "a09",
"sub": "Receptacles",
"name": "Single Receptacle",
"desc": "Select the options that apply to request the exact single receptacle you need.",
"aliases": [
"single outlet",
"single receptacle"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "nema",
"label": "NEMA",
"options": [
"5-15R",
"5-20R",
"6-15R",
"6-20R",
"6-30R",
"6-50R"
]
},
{
"key": "color",
"label": "Color",
"options": [
"White",
"Ivory",
"Gray",
"Black",
"Brown"
]
}
],
"brandOptions": [
"Leviton",
"Hubbell",
"Pass & Seymour"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-wall-plate"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-rcpt-clock",
"cat": "a09",
"sub": "Receptacles",
"name": "Clock Receptacle",
"desc": "Select the options that apply to request the exact clock receptacle you need.",
"aliases": [
"clock outlet",
"clock hanger"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Clock Hanger",
"Recessed Single"
]
}
],
"brandOptions": [
"Leviton",
"Hubbell",
"Pass & Seymour"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-rcpt-floor",
"cat": "a09",
"sub": "Receptacles",
"name": "Floor Receptacle",
"desc": "Select the options that apply to request the exact floor receptacle you need.",
"aliases": [
"floor outlet",
"floor receptacle"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Duplex",
"Single"
]
},
{
"key": "amperage",
"label": "Amperage",
"options": [
"15A",
"20A"
]
},
{
"key": "finish",
"label": "Plate Finish",
"options": [
"Brass",
"Aluminum",
"Nickel"
]
}
],
"brandOptions": [
"Leviton",
"Hubbell",
"Pass & Seymour"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-floor-box"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-rcpt-power",
"cat": "a09",
"sub": "Receptacles",
"name": "Power Receptacle (Range / Dryer / Welder / RV)",
"desc": "Select the options that apply to request the exact power receptacle (range / dryer / welder / rv) you need.",
"aliases": [
"range outlet",
"dryer outlet",
"welder outlet",
"rv outlet",
"14-50",
"14-30",
"50 amp outlet",
"30 amp outlet",
"nema 14-50"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "application",
"label": "Application",
"options": [
"Range",
"Dryer",
"Welder",
"RV",
"EV Charger (14-50)",
"General 240V"
]
},
{
"key": "nema",
"label": "NEMA",
"options": [
"10-30R",
"10-50R",
"14-30R",
"14-50R",
"6-30R",
"6-50R",
"TT-30R"
]
},
{
"key": "mount",
"label": "Mounting",
"options": [
"Flush",
"Surface"
]
}
],
"brandOptions": [
"Leviton",
"Hubbell",
"Pass & Seymour"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-breaker"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"application": [
"Range"
]
},
"limit": {
"nema": [
"10-50R",
"14-50R"
]
}
},
{
"when": {
"application": [
"Dryer"
]
},
"limit": {
"nema": [
"10-30R",
"14-30R"
]
}
},
{
"when": {
"application": [
"Welder"
]
},
"limit": {
"nema": [
"6-30R",
"6-50R"
]
}
},
{
"when": {
"application": [
"RV"
]
},
"limit": {
"nema": [
"TT-30R",
"14-50R"
]
}
},
{
"when": {
"application": [
"EV Charger (14-50)"
]
},
"limit": {
"nema": [
"14-50R"
]
}
},
{
"when": {
"application": [
"General 240V"
]
},
"limit": {
"nema": [
"6-30R",
"6-50R",
"14-30R",
"14-50R"
]
}
}
],
"alsoIn": [
"a20"
]
},
{
"id": "pf-rcpt-twistlock",
"cat": "a09",
"sub": "Receptacles",
"name": "Locking (Twist-Lock) Receptacle",
"desc": "Select the options that apply to request the exact locking (twist-lock) receptacle you need.",
"aliases": [
"twist lock",
"twistlock",
"locking receptacle",
"generator receptacle",
"l14-30"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "nema",
"label": "NEMA",
"options": [
"L5-15R",
"L5-20R",
"L5-30R",
"L6-20R",
"L6-30R",
"L14-20R",
"L14-30R",
"L21-30R"
]
},
{
"key": "grade",
"label": "Grade",
"options": [
"Commercial",
"Industrial"
],
"default": "Industrial"
}
],
"brandOptions": [
"Leviton",
"Hubbell",
"Pass & Seymour"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-cord-connector",
"pf-wall-plate"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a19",
"a28"
]
},
{
"id": "pf-gen-inlet",
"cat": "a19",
"sub": "Generator",
"name": "Generator Inlet / Power Inlet Box",
"desc": "Select the options that apply to request the exact generator inlet / power inlet box you need.",
"aliases": [
"generator inlet",
"power inlet box",
"inlet box",
"gen inlet",
"generator plug"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Inlet (Flanged)",
"Power Inlet Box (Weatherproof)"
]
},
{
"key": "config",
"label": "Configuration",
"options": [
"L14-20 (20A)",
"L14-30 (30A)",
"50A (CS-Style)"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-transfer-switch",
"pf-interlock",
"pf-gen-cord"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a09"
]
},
{
"id": "pf-switch",
"cat": "a09",
"sub": "Switches",
"name": "Wall Switch",
"desc": "Select the options that apply to request the exact wall switch you need.",
"aliases": [
"switch",
"light switch",
"3 way",
"3-way switch",
"4 way",
"single pole",
"double pole",
"decora switch",
"rocker switch",
"pilot light switch",
"toggle"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Single-Pole",
"Double-Pole",
"3-Way",
"4-Way"
]
},
{
"key": "amperage",
"label": "Amperage",
"options": [
"15A",
"20A",
"30A"
]
},
{
"key": "grade",
"label": "Grade",
"options": [
"Residential",
"Commercial / Specification",
"Industrial"
]
},
{
"key": "style",
"label": "Style",
"options": [
"Toggle",
"Decora (Rocker)"
]
},
{
"key": "illumination",
"label": "Illumination",
"options": [
"Standard",
"Pilot Light",
"Illuminated Handle"
],
"default": "Standard"
},
{
"key": "color",
"label": "Color",
"options": [
"White",
"Ivory",
"Light Almond",
"Gray",
"Black",
"Brown"
]
}
],
"brandOptions": [
"Leviton",
"Hubbell",
"Pass & Seymour"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-wall-plate",
"pf-box-screw"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"amperage": [
"30A"
]
},
"limit": {
"type": [
"Single-Pole",
"Double-Pole"
],
"grade": [
"Industrial"
],
"style": [
"Toggle"
]
}
}
]
},
{
"id": "pf-switch-combo",
"cat": "a09",
"sub": "Switches",
"name": "Combination Device",
"desc": "Select the options that apply to request the exact combination device you need.",
"aliases": [
"combo switch",
"switch outlet combo",
"combination switch"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "config",
"label": "Configuration",
"options": [
"Switch / Receptacle",
"Double Switch",
"Switch / Pilot Light"
]
},
{
"key": "amperage",
"label": "Amperage",
"options": [
"15A",
"20A"
]
},
{
"key": "color",
"label": "Color",
"options": [
"White",
"Ivory",
"Light Almond",
"Gray",
"Black",
"Brown"
]
}
],
"brandOptions": [
"Leviton",
"Hubbell",
"Pass & Seymour"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-wall-plate"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-switch-special",
"cat": "a09",
"sub": "Switches",
"name": "Specialty Switch",
"desc": "Select the options that apply to request the exact specialty switch you need.",
"aliases": [
"key switch",
"momentary switch",
"maintained switch"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Key Switch",
"Momentary Contact",
"Maintained Contact"
]
},
{
"key": "poles",
"label": "Poles",
"options": [
"Single-Pole",
"Double-Pole"
]
},
{
"key": "amperage",
"label": "Amperage",
"options": [
"15A",
"20A"
]
}
],
"brandOptions": [
"Leviton",
"Hubbell",
"Pass & Seymour"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-wall-plate"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-switch-timer",
"cat": "a09",
"sub": "Switches",
"name": "Timer Switch",
"desc": "Select the options that apply to request the exact timer switch you need.",
"aliases": [
"countdown timer",
"bath fan timer",
"timer switch",
"in wall timer"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Countdown Timer",
"In-Wall Digital Timer",
"Astronomical In-Wall Timer"
]
},
{
"key": "color",
"label": "Color",
"options": [
"White",
"Ivory",
"Light Almond"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-wall-plate"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-fan-control",
"cat": "a09",
"sub": "Switches",
"name": "Fan Speed Control",
"desc": "Select the options that apply to request the exact fan speed control you need.",
"aliases": [
"fan control",
"fan speed switch",
"fan switch"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "speeds",
"label": "Speeds",
"options": [
"3-Speed",
"4-Speed",
"Variable"
]
},
{
"key": "color",
"label": "Color",
"options": [
"White",
"Ivory",
"Light Almond"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-wall-plate"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-motor-switch",
"cat": "a09",
"sub": "Switches",
"name": "Manual Motor Switch (Motor-Rated)",
"desc": "Select the options that apply to request the exact manual motor switch (motor-rated) you need.",
"aliases": [
"motor switch",
"motor rated switch",
"toggle starter"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "poles",
"label": "Poles",
"options": [
"1-Pole",
"2-Pole",
"3-Pole"
]
},
{
"key": "enclosure",
"label": "Enclosure",
"options": [
"Device Only",
"With Enclosure"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-starter"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-dimmer",
"cat": "a09",
"sub": "Dimmers",
"name": "Dimmer",
"desc": "Select the options that apply to request the exact dimmer you need.",
"aliases": [
"dimmer",
"dimmer switch",
"0-10v dimmer",
"led dimmer",
"elv dimmer",
"mlv dimmer",
"smart dimmer"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Single-Pole",
"3-Way",
"Single-Pole / 3-Way"
]
},
{
"key": "load",
"label": "Load Type",
"options": [
"LED / CFL",
"Incandescent / Halogen",
"ELV",
"MLV",
"0–10V",
"Universal (LED / ELV / MLV)"
]
},
{
"key": "style",
"label": "Style",
"options": [
"Rotary",
"Slide",
"Toggle",
"Paddle / Rocker",
"Smart (Wi-Fi / Hub)"
]
},
{
"key": "color",
"label": "Color",
"options": [
"White",
"Ivory",
"Light Almond",
"Gray",
"Black",
"Brown"
]
}
],
"brandOptions": [
"Leviton",
"Hubbell",
"Pass & Seymour"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-wall-plate"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-wall-plate",
"cat": "a09",
"sub": "Wall Plates",
"name": "Wall Plate",
"desc": "Select the options that apply to request the exact wall plate you need.",
"aliases": [
"cover plate",
"face plate",
"switch plate",
"outlet cover",
"decora plate",
"plate",
"wallplate",
"keystone plate"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "gang",
"label": "Gang",
"options": [
"1-Gang",
"2-Gang",
"3-Gang",
"4-Gang",
"5-Gang",
"6-Gang"
]
},
{
"key": "config",
"label": "Openings",
"options": [
"Toggle",
"Decora / GFCI",
"Duplex",
"Blank",
"Single Receptacle",
"Toggle + Duplex",
"Decora + Duplex",
"Toggle + Decora",
"Coax (F)",
"Data / Keystone",
"Telephone"
]
},
{
"key": "material",
"label": "Material",
"options": [
"Nylon",
"Thermoset",
"Stainless Steel",
"Painted Metal"
]
},
{
"key": "size",
"label": "Size",
"options": [
"Standard",
"Midway (Oversize)",
"Jumbo"
],
"default": "Standard"
},
{
"key": "color",
"label": "Color",
"options": [
"White",
"Ivory",
"Light Almond",
"Gray",
"Black",
"Brown",
"Stainless"
]
}
],
"brandOptions": [
"Leviton",
"Hubbell",
"Pass & Seymour"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-rcpt-duplex",
"pf-switch",
"pf-box-screw"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"gang": [
"1-Gang"
]
},
"limit": {
"config": [
"Toggle",
"Decora / GFCI",
"Duplex",
"Blank",
"Single Receptacle",
"Coax (F)",
"Data / Keystone",
"Telephone"
]
}
},
{
"when": {
"gang": [
"3-Gang",
"4-Gang",
"5-Gang",
"6-Gang"
]
},
"limit": {
"config": [
"Toggle",
"Decora / GFCI",
"Duplex",
"Blank"
]
}
},
{
"when": {
"material": [
"Stainless Steel"
]
},
"limit": {
"color": [
"Stainless"
]
}
},
{
"when": {
"material": [
"Nylon",
"Thermoset",
"Painted Metal"
]
},
"limit": {
"color": [
"White",
"Ivory",
"Light Almond",
"Gray",
"Black",
"Brown"
]
}
}
],
"alsoIn": [
"a22"
]
},
{
"id": "pf-load-center",
"cat": "a10",
"sub": "Panels",
"name": "Load Center",
"desc": "Residential / light-commercial load center. Manufacturer and series determine which breakers fit.",
"aliases": [
"panel",
"breaker panel",
"load center",
"loadcenter",
"200 amp panel",
"main panel",
"subpanel",
"sub panel",
"breaker box"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Main Breaker",
"Main Lug (Subpanel)"
]
},
{
"key": "manufacturer",
"label": "Manufacturer",
"options": [
"Square D",
"Eaton",
"Siemens",
"GE / ABB"
]
},
{
"key": "series",
"label": "Panel Series",
"options": [
"QO",
"Homeline",
"BR",
"CH",
"QP",
"THQL"
],
"dependsOn": "manufacturer",
"optionsMap": {
"Square D": [
"QO",
"Homeline"
],
"Eaton": [
"BR",
"CH"
],
"Siemens": [
"QP"
],
"GE / ABB": [
"THQL"
]
}
},
{
"key": "amperage",
"label": "Amperage",
"options": [
"100A",
"125A",
"150A",
"200A",
"225A"
]
},
{
"key": "spaces",
"label": "Spaces",
"options": [
"12",
"16",
"20",
"24",
"30",
"32",
"40",
"42"
]
},
{
"key": "phase",
"label": "Phase",
"options": [
"1-Phase 120/240V",
"3-Phase 208Y/120V"
]
},
{
"key": "enclosure",
"label": "Enclosure",
"options": [
"Indoor (NEMA 1)",
"Outdoor (NEMA 3R)"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-breaker",
"pf-ground-bar",
"pf-panel-kit",
"pf-ko-seal",
"pf-ser"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"series": [
"Homeline"
]
},
"limit": {
"phase": [
"1-Phase 120/240V"
]
}
}
]
},
{
"id": "pf-panelboard",
"cat": "a10",
"sub": "Panels",
"name": "Panelboard (Commercial)",
"desc": "Select the options that apply to request the exact panelboard (commercial) you need.",
"aliases": [
"panelboard",
"lighting panel",
"power panel",
"distribution panel",
"lp",
"pp",
"dp",
"mdp"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "application",
"label": "Application",
"options": [
"Lighting Panel",
"Power Panel",
"Distribution Panel"
]
},
{
"key": "manufacturer",
"label": "Manufacturer",
"options": [
"Square D",
"Eaton",
"Siemens",
"GE / ABB"
]
},
{
"key": "voltage",
"label": "Voltage",
"options": [
"120/240V 1-Phase",
"208Y/120V 3-Phase",
"480Y/277V 3-Phase"
]
},
{
"key": "amperage",
"label": "Amperage",
"options": [
"100A",
"225A",
"400A",
"600A",
"800A"
]
},
{
"key": "main",
"label": "Main",
"options": [
"Main Breaker",
"Main Lug"
]
},
{
"key": "circuits",
"label": "Circuits",
"options": [
"18",
"30",
"42"
]
},
{
"key": "enclosure",
"label": "Enclosure",
"options": [
"NEMA 1",
"NEMA 3R"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-mccb",
"pf-breaker",
"pf-ground-bar",
"pf-label-panel"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-switchboard",
"cat": "a10",
"sub": "Panels",
"name": "Switchboard",
"desc": "Select the options that apply to request the exact switchboard you need.",
"aliases": [
"switchboard",
"swbd",
"main switchboard"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "manufacturer",
"label": "Manufacturer",
"options": [
"Square D",
"Eaton",
"Siemens",
"GE / ABB"
]
},
{
"key": "amperage",
"label": "Amperage",
"options": [
"400A",
"600A",
"800A",
"1000A",
"1200A",
"1600A",
"2000A",
"2500A",
"3000A",
"4000A"
]
},
{
"key": "voltage",
"label": "Voltage",
"options": [
"208Y/120V 3-Phase",
"480Y/277V 3-Phase"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-mccb",
"pf-label-safety"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-breaker-enclosure",
"cat": "a10",
"sub": "Panels",
"name": "Breaker Enclosure",
"desc": "Select the options that apply to request the exact breaker enclosure you need.",
"aliases": [
"breaker enclosure",
"breaker box small",
"enclosed breaker"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "manufacturer",
"label": "Manufacturer",
"options": [
"Square D",
"Eaton",
"Siemens",
"GE / ABB"
]
},
{
"key": "series",
"label": "Panel Series",
"options": [
"QO",
"Homeline",
"BR",
"CH",
"QP",
"THQL"
],
"dependsOn": "manufacturer",
"optionsMap": {
"Square D": [
"QO",
"Homeline"
],
"Eaton": [
"BR",
"CH"
],
"Siemens": [
"QP"
],
"GE / ABB": [
"THQL"
]
}
},
{
"key": "type",
"label": "Type",
"options": [
"2-Space Plug-On",
"Single Molded-Case Breaker"
]
},
{
"key": "enclosure",
"label": "Enclosure",
"options": [
"NEMA 1",
"NEMA 3R"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-breaker"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-panel-parts",
"cat": "a10",
"sub": "Panel Accessories",
"name": "Panel Replacement Part",
"desc": "Select the options that apply to request the exact panel replacement part you need.",
"aliases": [
"trim",
"dead front",
"filler plate",
"blank filler",
"knockout filler",
"panel cover",
"panel door",
"panel can"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "part",
"label": "Part",
"options": [
"Panel Enclosure (Can)",
"Panel Interior",
"Panel Trim / Cover",
"Dead Front",
"Filler Plate"
]
},
{
"key": "manufacturer",
"label": "Manufacturer",
"options": [
"Square D",
"Eaton",
"Siemens",
"GE / ABB"
]
},
{
"key": "series",
"label": "Panel Series",
"options": [
"QO",
"Homeline",
"BR",
"CH",
"QP",
"THQL"
],
"dependsOn": "manufacturer",
"optionsMap": {
"Square D": [
"QO",
"Homeline"
],
"Eaton": [
"BR",
"CH"
],
"Siemens": [
"QP"
],
"GE / ABB": [
"THQL"
]
}
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-load-center"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-panel-kit",
"cat": "a10",
"sub": "Panel Accessories",
"name": "Panel Accessory Kit",
"desc": "Select the options that apply to request the exact panel accessory kit you need.",
"aliases": [
"feed through lugs",
"lug kit",
"neutral bar",
"main breaker kit",
"subfeed",
"subfeed lugs"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "kit",
"label": "Kit",
"options": [
"Neutral Bar Kit",
"Lug Kit",
"Main Breaker Kit",
"Feed-Through Lug Kit",
"Subfeed Lug / Breaker Kit"
]
},
{
"key": "manufacturer",
"label": "Manufacturer",
"options": [
"Square D",
"Eaton",
"Siemens",
"GE / ABB"
]
},
{
"key": "series",
"label": "Panel Series",
"options": [
"QO",
"Homeline",
"BR",
"CH",
"QP",
"THQL"
],
"dependsOn": "manufacturer",
"optionsMap": {
"Square D": [
"QO",
"Homeline"
],
"Eaton": [
"BR",
"CH"
],
"Siemens": [
"QP"
],
"GE / ABB": [
"THQL"
]
}
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-load-center"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-breaker",
"cat": "a11",
"sub": "Branch Breakers",
"name": "Circuit Breaker (Branch)",
"desc": "Branch-circuit breaker. Manufacturer and series must match the panel — breakers are not interchangeable across series.",
"aliases": [
"breaker",
"circuit breaker",
"20 amp breaker",
"30 amp breaker",
"2 pole breaker",
"qo",
"homeline",
"br breaker",
"ch breaker",
"gfci breaker",
"afci breaker",
"dual function",
"df breaker",
"arc fault breaker",
"plug on",
"bolt on",
"generator breaker"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "manufacturer",
"label": "Manufacturer",
"options": [
"Square D",
"Eaton",
"Siemens",
"GE / ABB"
]
},
{
"key": "series",
"label": "Series",
"options": [
"QO (Plug-On)",
"QOB (Bolt-On)",
"Homeline (Plug-On)",
"BR (Plug-On)",
"CH (Plug-On)",
"BAB (Bolt-On)",
"QP (Plug-On)",
"BL (Bolt-On)",
"THQL (Plug-On)",
"THQB (Bolt-On)"
],
"dependsOn": "manufacturer",
"optionsMap": {
"Square D": [
"QO (Plug-On)",
"QOB (Bolt-On)",
"Homeline (Plug-On)"
],
"Eaton": [
"BR (Plug-On)",
"CH (Plug-On)",
"BAB (Bolt-On)"
],
"Siemens": [
"QP (Plug-On)",
"BL (Bolt-On)"
],
"GE / ABB": [
"THQL (Plug-On)",
"THQB (Bolt-On)"
]
}
},
{
"key": "poles",
"label": "Poles",
"options": [
"1-Pole",
"2-Pole",
"3-Pole"
]
},
{
"key": "amperage",
"label": "Amperage",
"options": [
"15A",
"20A",
"25A",
"30A",
"40A",
"50A",
"60A",
"70A",
"80A",
"90A",
"100A",
"125A"
]
},
{
"key": "protection",
"label": "Protection",
"options": [
"Standard (Thermal-Magnetic)",
"GFCI",
"AFCI (Combination)",
"Dual Function (AFCI / GFCI)"
]
},
{
"key": "interrupt",
"label": "Interrupt Rating",
"options": [
"10 kA (Standard)",
"22 kA (High Interrupt)"
],
"default": "10 kA (Standard)"
}
],
"brandOptions": [],
"imageFamilyKey": "pd-breakers",
"frequentlyUsedWith": [
"pf-load-center",
"pf-thhn",
"pf-label-panel"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"poles": [
"1-Pole"
]
},
"limit": {
"amperage": [
"15A",
"20A",
"25A",
"30A"
]
}
},
{
"when": {
"protection": [
"AFCI (Combination)",
"Dual Function (AFCI / GFCI)"
]
},
"limit": {
"poles": [
"1-Pole",
"2-Pole"
],
"amperage": [
"15A",
"20A"
]
}
},
{
"when": {
"protection": [
"GFCI"
]
},
"limit": {
"poles": [
"1-Pole",
"2-Pole"
],
"amperage": [
"15A",
"20A",
"25A",
"30A",
"40A",
"50A",
"60A"
]
}
},
{
"when": {
"series": [
"Homeline (Plug-On)"
]
},
"limit": {
"poles": [
"1-Pole",
"2-Pole"
]
}
}
]
},
{
"id": "pf-shunt-breaker",
"cat": "a11",
"sub": "Branch Breakers",
"name": "Shunt-Trip Breaker",
"desc": "Select the options that apply to request the exact shunt-trip breaker you need.",
"aliases": [
"shunt trip",
"st breaker",
"elevator breaker",
"shunt breaker"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "manufacturer",
"label": "Manufacturer",
"options": [
"Square D",
"Eaton",
"Siemens",
"GE / ABB"
]
},
{
"key": "series",
"label": "Series",
"options": [
"QO (Plug-On)",
"QOB (Bolt-On)",
"BR (Plug-On)",
"CH (Plug-On)",
"BAB (Bolt-On)",
"QP (Plug-On)",
"BL (Bolt-On)",
"THQL (Plug-On)",
"THQB (Bolt-On)"
],
"dependsOn": "manufacturer",
"optionsMap": {
"Square D": [
"QO (Plug-On)",
"QOB (Bolt-On)"
],
"Eaton": [
"BR (Plug-On)",
"CH (Plug-On)",
"BAB (Bolt-On)"
],
"Siemens": [
"QP (Plug-On)",
"BL (Bolt-On)"
],
"GE / ABB": [
"THQL (Plug-On)",
"THQB (Bolt-On)"
]
}
},
{
"key": "poles",
"label": "Poles",
"options": [
"1-Pole",
"2-Pole",
"3-Pole"
]
},
{
"key": "amperage",
"label": "Amperage",
"options": [
"15A",
"20A",
"30A",
"40A",
"50A",
"60A",
"70A",
"100A"
]
},
{
"key": "coil",
"label": "Shunt Coil",
"options": [
"120V",
"24V"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-load-center",
"pf-panelboard"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"poles": [
"1-Pole"
]
},
"limit": {
"amperage": [
"15A",
"20A",
"30A"
]
}
}
]
},
{
"id": "pf-main-breaker",
"cat": "a11",
"sub": "Main Breakers",
"name": "Main Breaker",
"desc": "Select the options that apply to request the exact main breaker you need.",
"aliases": [
"main breaker",
"main",
"panel main",
"back fed main"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "manufacturer",
"label": "Manufacturer",
"options": [
"Square D",
"Eaton",
"Siemens",
"GE / ABB"
]
},
{
"key": "series",
"label": "Panel Series",
"options": [
"QO",
"Homeline",
"BR",
"CH",
"QP",
"THQL"
],
"dependsOn": "manufacturer",
"optionsMap": {
"Square D": [
"QO",
"Homeline"
],
"Eaton": [
"BR",
"CH"
],
"Siemens": [
"QP"
],
"GE / ABB": [
"THQL"
]
}
},
{
"key": "amperage",
"label": "Amperage",
"options": [
"100A",
"125A",
"150A",
"200A",
"225A"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-load-center",
"pf-panel-kit"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-mccb",
"cat": "a11",
"sub": "Molded-Case Breakers",
"name": "Molded-Case Breaker (Panelboard / Distribution)",
"desc": "Select the options that apply to request the exact molded-case breaker (panelboard / distribution) you need.",
"aliases": [
"mccb",
"molded case",
"molded case breaker",
"feeder breaker",
"bolt on breaker"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "manufacturer",
"label": "Manufacturer",
"options": [
"Square D",
"Eaton",
"Siemens",
"GE / ABB"
]
},
{
"key": "frame",
"label": "Frame",
"options": [
"125A Frame",
"250A Frame",
"400A Frame",
"600A Frame",
"800A Frame"
]
},
{
"key": "poles",
"label": "Poles",
"options": [
"2-Pole",
"3-Pole"
]
},
{
"key": "amperage",
"label": "Trip Amperage",
"options": [
"15A",
"20A",
"30A",
"40A",
"50A",
"60A",
"70A",
"80A",
"90A",
"100A",
"125A",
"150A",
"175A",
"200A",
"225A",
"250A",
"300A",
"350A",
"400A",
"450A",
"500A",
"600A",
"700A",
"800A"
],
"dependsOn": "frame",
"optionsMap": {
"125A Frame": [
"15A",
"20A",
"30A",
"40A",
"50A",
"60A",
"70A",
"80A",
"90A",
"100A",
"125A"
],
"250A Frame": [
"150A",
"175A",
"200A",
"225A",
"250A"
],
"400A Frame": [
"300A",
"350A",
"400A"
],
"600A Frame": [
"450A",
"500A",
"600A"
],
"800A Frame": [
"700A",
"800A"
]
}
},
{
"key": "voltage",
"label": "Voltage",
"options": [
"240V",
"480V",
"600V"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-panelboard",
"pf-lug"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-meter-socket",
"cat": "a12",
"sub": "Metering",
"name": "Meter Socket / Meter Base",
"desc": "Select the options that apply to request the exact meter socket / meter base you need.",
"aliases": [
"meter base",
"meter can",
"meter socket",
"meter pan",
"meter stack",
"meter center"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Single Meter Socket",
"Meter Base (Ringless)",
"Meter Base (Ring-Type)",
"Multi-Meter Stack",
"Meter Center"
]
},
{
"key": "amperage",
"label": "Amperage",
"options": [
"100A",
"125A",
"200A",
"320A (Class 320)",
"400A"
]
},
{
"key": "phase",
"label": "Phase",
"options": [
"1-Phase",
"3-Phase"
]
},
{
"key": "feed",
"label": "Feed",
"options": [
"Overhead",
"Underground",
"Overhead / Underground"
]
},
{
"key": "positions",
"label": "Meter Positions",
"options": [
"1",
"2",
"3",
"4",
"6"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-ser",
"pf-weatherhead",
"pf-hub",
"pf-groundrod"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Single Meter Socket",
"Meter Base (Ringless)",
"Meter Base (Ring-Type)"
]
},
"limit": {
"positions": [
"1"
]
}
},
{
"when": {
"type": [
"Multi-Meter Stack",
"Meter Center"
]
},
"limit": {
"positions": [
"2",
"3",
"4",
"6"
]
}
}
]
},
{
"id": "pf-meter-main",
"cat": "a12",
"sub": "Metering",
"name": "Meter-Main Combination",
"desc": "Select the options that apply to request the exact meter-main combination you need.",
"aliases": [
"meter main",
"meter/main",
"all in one",
"combo panel",
"meter combo"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "amperage",
"label": "Amperage",
"options": [
"100A",
"125A",
"150A",
"200A",
"320A",
"400A"
]
},
{
"key": "spaces",
"label": "Spaces",
"options": [
"Disconnect Only",
"4 Spaces",
"8 Spaces",
"20 Spaces",
"40 Spaces"
]
},
{
"key": "feed",
"label": "Feed",
"options": [
"Overhead",
"Underground",
"Overhead / Underground"
]
},
{
"key": "manufacturer",
"label": "Manufacturer",
"options": [
"Square D",
"Eaton",
"Siemens",
"GE / ABB",
"Milbank"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-breaker",
"pf-ser",
"pf-groundrod"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a10"
]
},
{
"id": "pf-ct-cabinet",
"cat": "a12",
"sub": "Metering",
"name": "CT Cabinet / CT-Rated Meter Socket",
"desc": "Select the options that apply to request the exact ct cabinet / ct-rated meter socket you need.",
"aliases": [
"ct can",
"ct cabinet",
"ct meter",
"ct rated socket"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"CT Cabinet",
"CT-Rated Meter Socket"
]
},
{
"key": "amperage",
"label": "Amperage",
"options": [
"200A",
"400A",
"600A",
"800A"
]
},
{
"key": "phase",
"label": "Phase",
"options": [
"1-Phase",
"3-Phase"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-ct"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-ct",
"cat": "a12",
"sub": "Metering",
"name": "Current Transformer (CT)",
"desc": "Select the options that apply to request the exact current transformer (ct) you need.",
"aliases": [
"ct",
"donut ct",
"current transformer"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "ratio",
"label": "Ratio",
"options": [
"200:5",
"400:5",
"600:5",
"800:5",
"1200:5"
]
},
{
"key": "type",
"label": "Type",
"options": [
"Bar-Type",
"Window (Donut)",
"Split-Core"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-ct-cabinet"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-service-disconnect",
"cat": "a12",
"sub": "Service Equipment",
"name": "Service Disconnect (Service-Rated)",
"desc": "Select the options that apply to request the exact service disconnect (service-rated) you need.",
"aliases": [
"service disconnect",
"main disconnect",
"service rated disconnect"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "amperage",
"label": "Amperage",
"options": [
"100A",
"200A",
"400A",
"600A"
]
},
{
"key": "type",
"label": "Type",
"options": [
"Fused",
"Non-Fused",
"Breaker"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-fuse",
"pf-groundrod"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a13"
]
},
{
"id": "pf-weatherhead",
"cat": "a12",
"sub": "Service Equipment",
"name": "Weatherhead / Service Entrance Cap",
"desc": "Select the options that apply to request the exact weatherhead / service entrance cap you need.",
"aliases": [
"weatherhead",
"weather head",
"service head",
"se cap",
"gooseneck",
"service cap"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Conduit Weatherhead",
"SE Cable Cap"
]
},
{
"key": "size",
"label": "Size",
"options": [
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"4\"",
"SE Cable"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-service-mast",
"pf-mast-hardware"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"SE Cable Cap"
]
},
"limit": {
"size": [
"SE Cable"
]
}
},
{
"when": {
"type": [
"Conduit Weatherhead"
]
},
"limit": {
"size": [
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"4\""
]
}
}
]
},
{
"id": "pf-service-mast",
"cat": "a12",
"sub": "Service Equipment",
"name": "Service Mast",
"desc": "Select the options that apply to request the exact service mast you need.",
"aliases": [
"mast",
"service mast",
"riser mast"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"2\"",
"2-1/2\""
]
},
{
"key": "length",
"label": "Length",
"options": [
"10'"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-weatherhead",
"pf-mast-hardware",
"pf-meter-socket"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-mast-hardware",
"cat": "a12",
"sub": "Service Equipment",
"name": "Mast / Service Attachment Hardware",
"desc": "Select the options that apply to request the exact mast / service attachment hardware you need.",
"aliases": [
"mast clamp",
"roof jack",
"mast flashing",
"roof flashing",
"wedge clamp",
"house knob",
"insulator",
"point of attachment",
"poa"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Mast Clamp",
"Mast Flashing (Roof Jack)",
"Roof Flashing",
"Service Wedge Clamp",
"Service Attachment (Insulator)",
"Point-of-Attachment Bracket",
"House Knob / Screw Insulator"
]
},
{
"key": "size",
"label": "Size",
"options": [
"2\"",
"2-1/2\"",
"N/A (Cable)"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-service-mast"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Mast Clamp",
"Mast Flashing (Roof Jack)",
"Roof Flashing"
]
},
"limit": {
"size": [
"2\"",
"2-1/2\""
]
}
},
{
"when": {
"type": [
"Service Wedge Clamp",
"Service Attachment (Insulator)",
"Point-of-Attachment Bracket",
"House Knob / Screw Insulator"
]
},
"limit": {
"size": [
"N/A (Cable)"
]
}
}
]
},
{
"id": "pf-safety-switch",
"cat": "a13",
"sub": "Disconnects",
"name": "Safety Switch / Disconnect",
"desc": "Select the options that apply to request the exact safety switch / disconnect you need.",
"aliases": [
"disconnect",
"safety switch",
"nf disconnect",
"non fused disconnect",
"fused disconnect",
"heavy duty disconnect",
"knife switch",
"ev disconnect"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "fusing",
"label": "Fusing",
"options": [
"Non-Fused",
"Fused"
]
},
{
"key": "duty",
"label": "Duty",
"options": [
"General Duty",
"Heavy Duty"
]
},
{
"key": "amperage",
"label": "Amperage",
"options": [
"30A",
"60A",
"100A",
"200A",
"400A",
"600A"
]
},
{
"key": "voltage",
"label": "Voltage",
"options": [
"240V",
"600V"
]
},
{
"key": "poles",
"label": "Poles",
"options": [
"2-Pole",
"3-Pole"
]
},
{
"key": "enclosure",
"label": "Enclosure",
"options": [
"NEMA 1 (Indoor)",
"NEMA 3R (Outdoor)",
"NEMA 4X (Stainless)",
"NEMA 12"
]
}
],
"brandOptions": [
"Square D",
"Eaton",
"Siemens",
"GE / ABB"
],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-fuse",
"pf-hub",
"pf-label-safety"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"duty": [
"General Duty"
]
},
"limit": {
"voltage": [
"240V"
],
"enclosure": [
"NEMA 1 (Indoor)",
"NEMA 3R (Outdoor)"
]
}
},
{
"when": {
"voltage": [
"600V"
]
},
"limit": {
"duty": [
"Heavy Duty"
]
}
}
],
"alsoIn": [
"a20"
]
},
{
"id": "pf-ac-disconnect",
"cat": "a13",
"sub": "Disconnects",
"name": "AC Disconnect",
"desc": "Select the options that apply to request the exact ac disconnect you need.",
"aliases": [
"ac disconnect",
"pull out",
"pullout",
"pull-out disconnect",
"hvac disconnect",
"condenser disconnect"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Non-Fused Pull-Out",
"Fused Pull-Out",
"Non-Fused Molded Switch",
"Enclosed Breaker"
]
},
{
"key": "amperage",
"label": "Amperage",
"options": [
"30A",
"60A"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-hvac-whip",
"pf-fuse"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a18"
]
},
{
"id": "pf-motor-disconnect",
"cat": "a13",
"sub": "Disconnects",
"name": "Motor Disconnect (Rotary)",
"desc": "Select the options that apply to request the exact motor disconnect (rotary) you need.",
"aliases": [
"motor disconnect",
"rotary disconnect",
"local disconnect"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "amperage",
"label": "Amperage",
"options": [
"30A",
"60A",
"100A"
]
},
{
"key": "enclosure",
"label": "Enclosure",
"options": [
"NEMA 1",
"NEMA 4X",
"NEMA 12"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-starter"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a16"
]
},
{
"id": "pf-fuse",
"cat": "a13",
"sub": "Fuses",
"name": "Cartridge Fuse",
"desc": "Select the options that apply to request the exact cartridge fuse you need.",
"aliases": [
"fuse",
"fuses",
"cartridge fuse",
"time delay fuse",
"dual element fuse",
"class j",
"class cc",
"rk5",
"rk1",
"frn",
"frs"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "class",
"label": "Class",
"options": [
"Class CC",
"Class J",
"Class RK1",
"Class RK5",
"Class T",
"Class L",
"Midget (10x38)"
]
},
{
"key": "response",
"label": "Response",
"options": [
"Time-Delay (Dual-Element)",
"Fast-Acting"
]
},
{
"key": "amperage",
"label": "Amperage",
"options": [
"1A",
"2A",
"3A",
"5A",
"10A",
"15A",
"20A",
"25A",
"30A",
"40A",
"50A",
"60A",
"70A",
"80A",
"90A",
"100A",
"125A",
"150A",
"175A",
"200A",
"225A",
"250A",
"300A",
"400A",
"450A",
"600A",
"800A",
"1200A",
"1600A",
"2000A"
]
},
{
"key": "voltage",
"label": "Voltage",
"options": [
"250V",
"600V"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-fuse-acc",
"pf-safety-switch"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"class": [
"Class CC",
"Midget (10x38)"
]
},
"limit": {
"amperage": [
"1A",
"2A",
"3A",
"5A",
"10A",
"15A",
"20A",
"25A",
"30A"
]
}
},
{
"when": {
"class": [
"Class CC",
"Class J",
"Class T",
"Class L"
]
},
"limit": {
"voltage": [
"600V"
]
}
},
{
"when": {
"class": [
"Class J",
"Class RK1",
"Class RK5"
]
},
"limit": {
"amperage": [
"1A",
"2A",
"3A",
"5A",
"10A",
"15A",
"20A",
"25A",
"30A",
"40A",
"50A",
"60A",
"70A",
"80A",
"90A",
"100A",
"125A",
"150A",
"175A",
"200A",
"225A",
"250A",
"300A",
"400A",
"450A",
"600A"
]
}
},
{
"when": {
"class": [
"Class T"
]
},
"limit": {
"amperage": [
"1A",
"2A",
"3A",
"5A",
"10A",
"15A",
"20A",
"25A",
"30A",
"40A",
"50A",
"60A",
"70A",
"80A",
"90A",
"100A",
"125A",
"150A",
"175A",
"200A",
"225A",
"250A",
"300A",
"400A",
"450A",
"600A",
"800A",
"1200A"
]
}
},
{
"when": {
"class": [
"Class L"
]
},
"limit": {
"amperage": [
"800A",
"1200A",
"1600A",
"2000A"
]
}
}
],
"alsoIn": [
"a18"
],
"variantImage": {
"key": "class",
"map": {
"Class RK5": "pd-fuses"
}
}
},
{
"id": "pf-plug-fuse",
"cat": "a13",
"sub": "Fuses",
"name": "Plug Fuse",
"desc": "Select the options that apply to request the exact plug fuse you need.",
"aliases": [
"plug fuse",
"screw in fuse",
"edison fuse",
"type s fuse"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Edison Base (Type W)",
"Type S (Tamper-Resistant)"
]
},
{
"key": "amperage",
"label": "Amperage",
"options": [
"15A",
"20A",
"25A",
"30A"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-fuse-acc",
"cat": "a13",
"sub": "Fuses",
"name": "Fuse Holder / Block / Reducer",
"desc": "Select the options that apply to request the exact fuse holder / block / reducer you need.",
"aliases": [
"fuse block",
"fuse holder",
"fuse reducer"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"In-Line Fuse Holder",
"Fuse Block",
"Fuse Reducer"
]
},
{
"key": "class",
"label": "Fuse Class",
"options": [
"Class CC",
"Class J",
"Class R",
"Midget"
]
},
{
"key": "poles",
"label": "Poles",
"options": [
"1-Pole",
"2-Pole",
"3-Pole"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-fuse"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-recessed",
"cat": "a14",
"sub": "Fixtures",
"name": "LED Recessed Downlight",
"desc": "Select the options that apply to request the exact led recessed downlight you need.",
"aliases": [
"can light",
"can lights",
"recessed light",
"recessed",
"pot light",
"high hat",
"downlight",
"wafer light",
"canless",
"6 inch can"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Can (Housing + Trim)",
"Canless Wafer",
"Retrofit Trim"
]
},
{
"key": "size",
"label": "Size",
"options": [
"2\"",
"3\"",
"4\"",
"5/6\"",
"6\"",
"8\""
]
},
{
"key": "housing",
"label": "Housing",
"options": [
"New Construction",
"Remodel",
"N/A"
]
},
{
"key": "rating",
"label": "Rating",
"options": [
"IC-Rated",
"Non-IC",
"Airtight IC"
]
},
{
"key": "cct",
"label": "Color Temp",
"options": [
"2700K",
"3000K",
"3500K",
"4000K",
"5000K",
"Selectable CCT"
]
},
{
"key": "dimming",
"label": "Dimming",
"options": [
"Triac / ELV",
"0–10V"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-dimmer",
"pf-nmb"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Canless Wafer",
"Retrofit Trim"
]
},
"limit": {
"housing": [
"N/A"
]
}
},
{
"when": {
"type": [
"Can (Housing + Trim)"
]
},
"limit": {
"housing": [
"New Construction",
"Remodel"
]
}
}
]
},
{
"id": "pf-surface-mount",
"cat": "a14",
"sub": "Fixtures",
"name": "Surface / Flush-Mount Fixture",
"desc": "Select the options that apply to request the exact surface / flush-mount fixture you need.",
"aliases": [
"flush mount",
"disk light",
"dome light",
"ceiling light",
"surface mount"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Flush Mount",
"Semi-Flush",
"Disk Light",
"Surface Cylinder"
]
},
{
"key": "size",
"label": "Size",
"options": [
"7\"",
"11\"",
"13\"",
"15\""
]
},
{
"key": "cct",
"label": "Color Temp",
"options": [
"2700K",
"3000K",
"3500K",
"4000K",
"5000K",
"Selectable CCT"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-fixture-box"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-decorative",
"cat": "a14",
"sub": "Fixtures",
"name": "Decorative Fixture",
"desc": "Select the options that apply to request the exact decorative fixture you need.",
"aliases": [
"pendant",
"chandelier",
"sconce",
"wall sconce",
"vanity light",
"bath bar"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Pendant",
"Chandelier",
"Wall Sconce",
"Vanity Light"
]
},
{
"key": "finish",
"label": "Finish",
"options": [
"Brushed Nickel",
"Matte Black",
"Bronze",
"Chrome",
"White",
"Owner Supplied / TBD"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-fixture-box"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-undercabinet",
"cat": "a14",
"sub": "Fixtures",
"name": "Under-Cabinet Light",
"desc": "Select the options that apply to request the exact under-cabinet light you need.",
"aliases": [
"under cabinet",
"undercabinet",
"ucl",
"cabinet light"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "length",
"label": "Length",
"options": [
"9\"",
"12\"",
"18\"",
"24\"",
"36\""
]
},
{
"key": "type",
"label": "Type",
"options": [
"Hardwired",
"Plug-In",
"Low-Voltage Tape"
]
},
{
"key": "cct",
"label": "Color Temp",
"options": [
"2700K",
"3000K",
"3500K",
"4000K",
"5000K",
"Selectable CCT"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-linear",
"cat": "a14",
"sub": "Fixtures",
"name": "Strip / Wrap / Vapor-Tight Fixture",
"desc": "Select the options that apply to request the exact strip / wrap / vapor-tight fixture you need.",
"aliases": [
"strip light",
"strip",
"wrap",
"wraparound",
"vapor tight",
"vaportight",
"shop light",
"4 foot led",
"4ft strip"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Strip Light",
"Wraparound",
"Vapor-Tight",
"Shop Light"
]
},
{
"key": "length",
"label": "Length",
"options": [
"2'",
"4'",
"8'"
]
},
{
"key": "output",
"label": "Output",
"options": [
"Low (about 2,000 lm)",
"Standard (about 4,000 lm)",
"High (about 6,000+ lm)"
]
},
{
"key": "cct",
"label": "Color Temp",
"options": [
"3500K",
"4000K",
"5000K"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-fixture-whip"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-troffer",
"cat": "a14",
"sub": "Fixtures",
"name": "LED Troffer / Flat Panel",
"desc": "Select the options that apply to request the exact led troffer / flat panel you need.",
"aliases": [
"troffer",
"2x4",
"2x2",
"lay in",
"lay-in",
"flat panel",
"panel light",
"drop ceiling light"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Troffer",
"Flat Panel",
"Retrofit Kit"
]
},
{
"key": "size",
"label": "Size",
"options": [
"1'x4'",
"2'x2'",
"2'x4'"
]
},
{
"key": "output",
"label": "Output",
"options": [
"Low (about 3,000 lm)",
"Standard (about 4,000 lm)",
"High (about 5,000+ lm)"
]
},
{
"key": "cct",
"label": "Color Temp",
"options": [
"3500K",
"4000K",
"5000K",
"Selectable CCT"
]
},
{
"key": "dimming",
"label": "Dimming",
"options": [
"0–10V",
"Non-Dim"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-fixture-whip",
"pf-occ-sensor"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-highbay",
"cat": "a14",
"sub": "Fixtures",
"name": "High Bay / Low Bay",
"desc": "Select the options that apply to request the exact high bay / low bay you need.",
"aliases": [
"high bay",
"highbay",
"ufo",
"low bay",
"warehouse light"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"High Bay (Round / UFO)",
"High Bay (Linear)",
"Low Bay"
]
},
{
"key": "wattage",
"label": "Wattage",
"options": [
"100W",
"150W",
"200W",
"240W",
"300W"
]
},
{
"key": "cct",
"label": "Color Temp",
"options": [
"4000K",
"5000K"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-fixture-whip"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-wallpack",
"cat": "a14",
"sub": "Fixtures",
"name": "Wall Pack",
"desc": "Select the options that apply to request the exact wall pack you need.",
"aliases": [
"wall pack",
"wallpack",
"exterior wall light"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "wattage",
"label": "Wattage",
"options": [
"20W",
"40W",
"60W",
"80W",
"120W"
]
},
{
"key": "cutoff",
"label": "Distribution",
"options": [
"Full Cutoff",
"Semi-Cutoff",
"Non-Cutoff"
]
},
{
"key": "photocell",
"label": "Photocell",
"options": [
"With Photocell",
"No Photocell"
]
},
{
"key": "cct",
"label": "Color Temp",
"options": [
"3000K",
"4000K",
"5000K"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-photocell"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-flood",
"cat": "a14",
"sub": "Fixtures",
"name": "Flood Light",
"desc": "Select the options that apply to request the exact flood light you need.",
"aliases": [
"flood",
"floodlight",
"flood light"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "wattage",
"label": "Wattage",
"options": [
"30W",
"50W",
"100W",
"150W",
"200W",
"300W"
]
},
{
"key": "mount",
"label": "Mount",
"options": [
"Knuckle",
"Yoke / Trunnion",
"Slipfitter"
]
},
{
"key": "cct",
"label": "Color Temp",
"options": [
"3000K",
"4000K",
"5000K"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-photocell"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-area-light",
"cat": "a14",
"sub": "Fixtures",
"name": "Area Light (Shoebox)",
"desc": "Select the options that apply to request the exact area light (shoebox) you need.",
"aliases": [
"shoebox",
"parking lot light",
"site light",
"area light"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "wattage",
"label": "Wattage",
"options": [
"75W",
"100W",
"150W",
"200W",
"300W"
]
},
{
"key": "distribution",
"label": "Distribution",
"options": [
"Type II",
"Type III",
"Type IV",
"Type V"
]
},
{
"key": "mount",
"label": "Mount",
"options": [
"Direct Arm",
"Slipfitter"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-light-pole",
"pf-photocell"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-light-pole",
"cat": "a14",
"sub": "Fixtures",
"name": "Light Pole",
"desc": "Select the options that apply to request the exact light pole you need.",
"aliases": [
"light pole",
"pole",
"parking lot pole"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "height",
"label": "Height",
"options": [
"10'",
"12'",
"15'",
"20'",
"25'",
"30'"
]
},
{
"key": "material",
"label": "Material",
"options": [
"Steel",
"Aluminum"
]
},
{
"key": "shape",
"label": "Shape",
"options": [
"Square",
"Round"
]
},
{
"key": "base",
"label": "Base",
"options": [
"Anchor Base",
"Direct Burial"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-area-light"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-canopy",
"cat": "a14",
"sub": "Fixtures",
"name": "Canopy / Garage Light",
"desc": "Select the options that apply to request the exact canopy / garage light you need.",
"aliases": [
"canopy light",
"garage light",
"parking garage light"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "wattage",
"label": "Wattage",
"options": [
"40W",
"60W",
"80W",
"100W"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-bollard",
"cat": "a14",
"sub": "Fixtures",
"name": "Bollard / Step Light",
"desc": "Select the options that apply to request the exact bollard / step light you need.",
"aliases": [
"bollard",
"step light",
"path light"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Bollard",
"Step Light"
]
},
{
"key": "finish",
"label": "Finish",
"options": [
"Bronze",
"Black",
"Gray"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-emergency",
"cat": "a14",
"sub": "Fixtures",
"name": "Emergency Light / Exit Sign",
"desc": "Select the options that apply to request the exact emergency light / exit sign you need.",
"aliases": [
"exit sign",
"exit",
"emergency light",
"bug eye",
"bugeye",
"frog eye",
"combo exit",
"emergency"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Emergency Light (Twin Head)",
"Exit Sign",
"Exit / Emergency Combo",
"Remote Head"
]
},
{
"key": "letters",
"label": "Letter Color",
"options": [
"Red",
"Green",
"N/A"
]
},
{
"key": "faces",
"label": "Faces",
"options": [
"Single Face",
"Double Face",
"N/A"
]
},
{
"key": "battery",
"label": "Power",
"options": [
"Battery Backup",
"AC Only"
]
},
{
"key": "housing",
"label": "Housing",
"options": [
"Thermoplastic",
"Die-Cast Aluminum"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Emergency Light (Twin Head)",
"Remote Head"
]
},
"limit": {
"letters": [
"N/A"
],
"faces": [
"N/A"
]
}
},
{
"when": {
"type": [
"Exit Sign",
"Exit / Emergency Combo"
]
},
"limit": {
"letters": [
"Red",
"Green"
],
"faces": [
"Single Face",
"Double Face"
]
}
}
]
},
{
"id": "pf-lamp",
"cat": "a14",
"sub": "Lamps",
"name": "Lamp / Bulb",
"desc": "Select the options that apply to request the exact lamp / bulb you need.",
"aliases": [
"bulb",
"lamp",
"light bulb",
"a19",
"br30",
"br40",
"t8",
"led tube",
"mr16",
"gu10",
"par30",
"par38",
"t5",
"metal halide",
"hps",
"cfl"
],
"unit": "EA",
"altUnits": [
"CASE"
],
"variants": [
{
"key": "shape",
"label": "Shape",
"options": [
"A19",
"A21",
"BR30",
"BR40",
"PAR20",
"PAR30",
"PAR38",
"MR16",
"GU10",
"T5",
"T8",
"T12",
"Corn Cob (HID Replacement)",
"Metal Halide",
"High-Pressure Sodium",
"CFL"
]
},
{
"key": "technology",
"label": "Technology",
"options": [
"LED",
"Fluorescent",
"HID",
"Incandescent / Halogen"
]
},
{
"key": "base",
"label": "Base",
"options": [
"E26 (Medium)",
"E39 (Mogul)",
"GU10",
"GU5.3 (Bi-Pin)",
"G13 (Medium Bi-Pin)",
"G5 (Mini Bi-Pin)"
]
},
{
"key": "cct",
"label": "Color Temp",
"options": [
"2700K",
"3000K",
"3500K",
"4000K",
"5000K"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"shape": [
"A19",
"A21",
"BR30",
"BR40",
"PAR20",
"PAR30",
"PAR38"
]
},
"limit": {
"base": [
"E26 (Medium)"
],
"technology": [
"LED",
"Incandescent / Halogen"
]
}
},
{
"when": {
"shape": [
"MR16"
]
},
"limit": {
"base": [
"GU5.3 (Bi-Pin)"
],
"technology": [
"LED",
"Incandescent / Halogen"
]
}
},
{
"when": {
"shape": [
"GU10"
]
},
"limit": {
"base": [
"GU10"
],
"technology": [
"LED",
"Incandescent / Halogen"
]
}
},
{
"when": {
"shape": [
"T5"
]
},
"limit": {
"base": [
"G5 (Mini Bi-Pin)"
],
"technology": [
"LED",
"Fluorescent"
]
}
},
{
"when": {
"shape": [
"T8",
"T12"
]
},
"limit": {
"base": [
"G13 (Medium Bi-Pin)"
],
"technology": [
"LED",
"Fluorescent"
]
}
},
{
"when": {
"shape": [
"Corn Cob (HID Replacement)"
]
},
"limit": {
"base": [
"E26 (Medium)",
"E39 (Mogul)"
],
"technology": [
"LED"
]
}
},
{
"when": {
"shape": [
"Metal Halide",
"High-Pressure Sodium"
]
},
"limit": {
"base": [
"E26 (Medium)",
"E39 (Mogul)"
],
"technology": [
"HID"
]
}
},
{
"when": {
"shape": [
"CFL"
]
},
"limit": {
"base": [
"E26 (Medium)"
],
"technology": [
"Fluorescent"
]
}
}
]
},
{
"id": "pf-driver-ballast",
"cat": "a14",
"sub": "Lighting Components",
"name": "LED Driver / Ballast",
"desc": "Select the options that apply to request the exact led driver / ballast you need.",
"aliases": [
"driver",
"ballast",
"led driver",
"t8 ballast",
"hid ballast"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"LED Driver (Constant Current)",
"LED Driver (Constant Voltage)",
"Fluorescent Ballast (T8)",
"Fluorescent Ballast (T5)",
"HID Ballast"
]
},
{
"key": "voltage",
"label": "Voltage",
"options": [
"120V",
"277V",
"120–277V"
]
},
{
"key": "dimming",
"label": "Dimming",
"options": [
"Non-Dim",
"0–10V",
"Triac"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-lampholder"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-lampholder",
"cat": "a14",
"sub": "Lighting Components",
"name": "Lamp Holder / Socket",
"desc": "Select the options that apply to request the exact lamp holder / socket you need.",
"aliases": [
"tombstone",
"tombstones",
"lampholder",
"lamp holder",
"socket",
"keyless",
"pull chain"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Tombstone (Non-Shunted)",
"Tombstone (Shunted)",
"Porcelain Socket (Keyless)",
"Porcelain Socket (Pull Chain)",
"Pigtail Socket"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-driver-ballast"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-fixture-whip",
"cat": "a14",
"sub": "Lighting Components",
"name": "Fixture Whip",
"desc": "Select the options that apply to request the exact fixture whip you need.",
"aliases": [
"whip",
"fixture whip",
"lighting whip",
"pre-wire",
"prewire whip"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "cable",
"label": "Cable",
"options": [
"MC Lum (12/2 + 16/2)",
"MC 12/2",
"MC 12/3",
"Flex (3/8\") with THHN"
]
},
{
"key": "length",
"label": "Length",
"options": [
"4'",
"6'"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-troffer",
"pf-mc-connector"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-fixture-disconnect",
"cat": "a14",
"sub": "Lighting Components",
"name": "Fixture / Ballast Disconnect",
"desc": "Select the options that apply to request the exact fixture / ballast disconnect you need.",
"aliases": [
"fixture disconnect",
"ballast disconnect",
"inline disconnect"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "wires",
"label": "Conductors",
"options": [
"2-Wire",
"3-Wire"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-driver-ballast"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-battery-backup",
"cat": "a14",
"sub": "Lighting Components",
"name": "Emergency Driver / Battery Pack",
"desc": "Select the options that apply to request the exact emergency driver / battery pack you need.",
"aliases": [
"emergency driver",
"emergency ballast",
"battery backup",
"bodine",
"battery pack"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"LED Emergency Driver",
"Fluorescent Emergency Ballast",
"Mini Inverter"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-troffer"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-occ-sensor",
"cat": "a15",
"sub": "Sensors",
"name": "Occupancy / Vacancy Sensor",
"desc": "Select the options that apply to request the exact occupancy / vacancy sensor you need.",
"aliases": [
"occ sensor",
"occupancy sensor",
"motion sensor",
"vacancy sensor",
"pir sensor",
"dual tech",
"ceiling sensor",
"wall sensor"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "mode",
"label": "Mode",
"options": [
"Occupancy (Auto-On)",
"Vacancy (Manual-On)"
]
},
{
"key": "mount",
"label": "Mount",
"options": [
"Wall Switch",
"Ceiling",
"Wall / Corner",
"Fixture-Mount"
]
},
{
"key": "technology",
"label": "Technology",
"options": [
"PIR",
"Ultrasonic",
"Dual Technology"
]
},
{
"key": "voltage",
"label": "Voltage",
"options": [
"Line Voltage (120/277V)",
"Low Voltage (Power Pack)"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-power-pack",
"pf-wall-plate"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"mount": [
"Wall Switch"
]
},
"limit": {
"voltage": [
"Line Voltage (120/277V)"
]
}
}
]
},
{
"id": "pf-daylight-sensor",
"cat": "a15",
"sub": "Sensors",
"name": "Daylight Sensor",
"desc": "Select the options that apply to request the exact daylight sensor you need.",
"aliases": [
"daylight sensor",
"daylight harvesting",
"photosensor"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "mount",
"label": "Mount",
"options": [
"Ceiling",
"Fixture-Mount"
]
},
{
"key": "output",
"label": "Output",
"options": [
"0–10V",
"Relay"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-power-pack"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-photocell",
"cat": "a15",
"sub": "Sensors",
"name": "Photocell",
"desc": "Select the options that apply to request the exact photocell you need.",
"aliases": [
"photocell",
"photo eye",
"photo control",
"dusk to dawn",
"pc"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Twist-Lock (3-Pin)",
"Twist-Lock (7-Pin)",
"Button (Stem Mount)",
"Swivel"
]
},
{
"key": "voltage",
"label": "Voltage",
"options": [
"120V",
"120–277V",
"208–277V",
"480V"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-wallpack",
"pf-area-light"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a14"
]
},
{
"id": "pf-power-pack",
"cat": "a15",
"sub": "Controls",
"name": "Power Pack",
"desc": "Select the options that apply to request the exact power pack you need.",
"aliases": [
"power pack",
"sensor power pack"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "voltage",
"label": "Voltage",
"options": [
"120/277V",
"347V"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-occ-sensor"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-lv-switch",
"cat": "a15",
"sub": "Controls",
"name": "Low-Voltage Switch / 0–10V Controller",
"desc": "Select the options that apply to request the exact low-voltage switch / 0–10v controller you need.",
"aliases": [
"0-10v controller",
"low voltage switch",
"scene controller"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Low-Voltage Momentary Switch",
"0–10V Dimmer / Controller",
"Scene Controller"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-power-pack"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-lighting-relay",
"cat": "a15",
"sub": "Controls",
"name": "Lighting Contactor / Relay Panel",
"desc": "Select the options that apply to request the exact lighting contactor / relay panel you need.",
"aliases": [
"lighting contactor",
"relay panel",
"mechanically held",
"lighting relay"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Lighting Contactor (Mechanically Held)",
"Lighting Contactor (Electrically Held)",
"Lighting Relay Panel"
]
},
{
"key": "size",
"label": "Poles / Relays",
"options": [
"2-Pole",
"4-Pole",
"6-Pole",
"8-Pole",
"12-Pole",
"8 Relays",
"16 Relays",
"24 Relays",
"48 Relays"
]
},
{
"key": "coil",
"label": "Coil Voltage",
"options": [
"24V",
"120V",
"277V"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-time-clock"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Lighting Relay Panel"
]
},
"limit": {
"size": [
"8 Relays",
"16 Relays",
"24 Relays",
"48 Relays"
]
}
},
{
"when": {
"type": [
"Lighting Contactor (Mechanically Held)",
"Lighting Contactor (Electrically Held)"
]
},
"limit": {
"size": [
"2-Pole",
"4-Pole",
"6-Pole",
"8-Pole",
"12-Pole"
]
}
}
]
},
{
"id": "pf-time-clock",
"cat": "a15",
"sub": "Controls",
"name": "Time Clock",
"desc": "Select the options that apply to request the exact time clock you need.",
"aliases": [
"time clock",
"timer",
"time switch",
"astro clock",
"astronomical timer"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Mechanical (24-Hour)",
"Digital (7-Day)",
"Astronomical"
]
},
{
"key": "rating",
"label": "Rating",
"options": [
"20A",
"30A",
"40A"
]
},
{
"key": "contacts",
"label": "Contacts",
"options": [
"SPST",
"DPST",
"SPDT"
]
},
{
"key": "enclosure",
"label": "Enclosure",
"options": [
"Indoor (NEMA 1)",
"Outdoor (NEMA 3R)"
]
},
{
"key": "voltage",
"label": "Voltage",
"options": [
"120V",
"208–277V",
"Multi-Voltage"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-lighting-relay",
"pf-photocell"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-starter",
"cat": "a16",
"sub": "Motor Starters",
"name": "Motor Starter",
"desc": "Select the options that apply to request the exact motor starter you need.",
"aliases": [
"motor starter",
"starter",
"mag starter",
"magnetic starter",
"manual starter",
"combination starter"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Manual Motor Starter",
"Magnetic Starter (Across-the-Line)",
"Combination Starter"
]
},
{
"key": "size",
"label": "NEMA Size",
"options": [
"Size 00",
"Size 0",
"Size 1",
"Size 2",
"Size 3",
"Size 4"
]
},
{
"key": "phase",
"label": "Phase",
"options": [
"1-Phase",
"3-Phase"
]
},
{
"key": "coil",
"label": "Coil Voltage",
"options": [
"24V",
"120V",
"208V",
"240V",
"480V",
"N/A (Manual)"
]
},
{
"key": "enclosure",
"label": "Enclosure",
"options": [
"NEMA 1",
"NEMA 3R",
"NEMA 4X",
"Open"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-overload",
"pf-pilot-device",
"pf-motor-disconnect"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Manual Motor Starter"
]
},
"limit": {
"coil": [
"N/A (Manual)"
]
}
},
{
"when": {
"type": [
"Magnetic Starter (Across-the-Line)",
"Combination Starter"
]
},
"limit": {
"coil": [
"24V",
"120V",
"208V",
"240V",
"480V"
]
}
}
]
},
{
"id": "pf-contactor",
"cat": "a16",
"sub": "Motor Starters",
"name": "Contactor",
"desc": "Select the options that apply to request the exact contactor you need.",
"aliases": [
"contactor",
"dp contactor",
"definite purpose",
"hvac contactor",
"iec contactor",
"ac contactor"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"IEC Contactor",
"NEMA Contactor",
"Definite-Purpose Contactor"
]
},
{
"key": "poles",
"label": "Poles",
"options": [
"1-Pole",
"2-Pole",
"3-Pole",
"4-Pole"
]
},
{
"key": "amperage",
"label": "Amperage",
"options": [
"9A",
"12A",
"18A",
"20A",
"25A",
"30A",
"32A",
"40A",
"50A",
"60A",
"65A",
"75A",
"90A"
]
},
{
"key": "coil",
"label": "Coil Voltage",
"options": [
"24V",
"120V",
"208/240V",
"277V",
"480V"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-overload",
"pf-lv-transformer"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Definite-Purpose Contactor"
]
},
"limit": {
"poles": [
"1-Pole",
"2-Pole",
"3-Pole"
],
"amperage": [
"20A",
"25A",
"30A",
"40A",
"50A",
"60A",
"75A",
"90A"
]
}
}
],
"alsoIn": [
"a18"
]
},
{
"id": "pf-overload",
"cat": "a16",
"sub": "Motor Starters",
"name": "Overload Relay",
"desc": "Select the options that apply to request the exact overload relay you need.",
"aliases": [
"overload",
"overloads",
"ol relay",
"heater"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Thermal (Bimetal)",
"Electronic"
]
},
{
"key": "range",
"label": "Current Range",
"options": [
"0.4–0.63A",
"1–1.6A",
"2.5–4A",
"4–6.3A",
"7–10A",
"9–13A",
"12–18A",
"17–23A",
"23–32A"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-contactor",
"pf-starter"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-mpcb",
"cat": "a16",
"sub": "Motor Starters",
"name": "Motor Protection Circuit Breaker (MPCB)",
"desc": "Select the options that apply to request the exact motor protection circuit breaker (mpcb) you need.",
"aliases": [
"mpcb",
"motor circuit protector",
"manual motor protector"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "range",
"label": "Current Range",
"options": [
"0.4–0.63A",
"1–1.6A",
"2.5–4A",
"4–6.3A",
"7–10A",
"9–13A",
"12–18A",
"17–23A",
"23–32A",
"30–40A"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-contactor"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-vfd",
"cat": "a16",
"sub": "Drives",
"name": "Variable Frequency Drive (VFD)",
"desc": "Select the options that apply to request the exact variable frequency drive (vfd) you need.",
"aliases": [
"vfd",
"drive",
"ac drive",
"inverter drive",
"variable speed drive",
"vsd"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "hp",
"label": "Horsepower",
"options": [
"1/2 HP",
"1 HP",
"2 HP",
"3 HP",
"5 HP",
"7.5 HP",
"10 HP",
"15 HP",
"20 HP",
"25 HP",
"30 HP",
"40 HP",
"50 HP"
]
},
{
"key": "input",
"label": "Input",
"options": [
"120V 1-Phase",
"240V 1-Phase",
"208/240V 3-Phase",
"480V 3-Phase"
]
},
{
"key": "enclosure",
"label": "Enclosure",
"options": [
"NEMA 1",
"NEMA 12",
"NEMA 4X"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-vfd-cable",
"pf-line-reactor"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-soft-starter",
"cat": "a16",
"sub": "Drives",
"name": "Soft Starter",
"desc": "Select the options that apply to request the exact soft starter you need.",
"aliases": [
"soft start",
"soft starter"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "hp",
"label": "Horsepower",
"options": [
"3 HP",
"5 HP",
"7.5 HP",
"10 HP",
"15 HP",
"20 HP",
"25 HP",
"30 HP",
"40 HP",
"50 HP"
]
},
{
"key": "voltage",
"label": "Voltage",
"options": [
"208–240V",
"480V"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-mccb"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-relay",
"cat": "a16",
"sub": "Control Relays",
"name": "Control Relay",
"desc": "Select the options that apply to request the exact control relay you need.",
"aliases": [
"ice cube relay",
"relay",
"timer relay",
"timing relay",
"control relay",
"relay base",
"octal socket"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Ice-Cube (Plug-In) Relay",
"General-Purpose Control Relay",
"Timing Relay",
"Relay Socket / Base"
]
},
{
"key": "coil",
"label": "Coil Voltage",
"options": [
"12V DC",
"24V AC",
"24V DC",
"120V AC",
"240V AC",
"N/A"
]
},
{
"key": "contacts",
"label": "Contacts",
"options": [
"SPDT",
"DPDT",
"3PDT",
"4PDT"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-control-transformer"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Relay Socket / Base"
]
},
"limit": {
"coil": [
"N/A"
]
}
},
{
"when": {
"type": [
"Ice-Cube (Plug-In) Relay",
"General-Purpose Control Relay",
"Timing Relay"
]
},
"limit": {
"coil": [
"12V DC",
"24V AC",
"24V DC",
"120V AC",
"240V AC"
]
}
}
]
},
{
"id": "pf-pilot-device",
"cat": "a16",
"sub": "Pilot Devices",
"name": "Pilot Device (Push Button / Selector / Light)",
"desc": "Select the options that apply to request the exact pilot device (push button / selector / light) you need.",
"aliases": [
"push button",
"pushbutton",
"e-stop",
"estop",
"emergency stop",
"hoa",
"hand off auto",
"selector switch",
"pilot light",
"start stop button"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Push Button",
"Start Button",
"Stop Button",
"Selector Switch",
"Pilot Light",
"Emergency Stop",
"Hand-Off-Auto (HOA) Selector"
]
},
{
"key": "size",
"label": "Size",
"options": [
"22mm",
"30mm"
]
},
{
"key": "color",
"label": "Color",
"options": [
"Red",
"Green",
"Black",
"Yellow",
"Blue",
"White",
"Amber"
]
},
{
"key": "contacts",
"label": "Contacts",
"options": [
"1 NO",
"1 NC",
"1 NO + 1 NC",
"N/A (Light)"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-control-station",
"pf-enclosure"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Pilot Light"
]
},
"limit": {
"contacts": [
"N/A (Light)"
]
}
},
{
"when": {
"type": [
"Push Button",
"Start Button",
"Stop Button",
"Selector Switch",
"Emergency Stop",
"Hand-Off-Auto (HOA) Selector"
]
},
"limit": {
"contacts": [
"1 NO",
"1 NC",
"1 NO + 1 NC"
]
}
},
{
"when": {
"type": [
"Stop Button",
"Emergency Stop"
]
},
"limit": {
"color": [
"Red"
]
}
},
{
"when": {
"type": [
"Start Button"
]
},
"limit": {
"color": [
"Green"
]
}
}
]
},
{
"id": "pf-control-station",
"cat": "a16",
"sub": "Pilot Devices",
"name": "Control Station (Enclosed)",
"desc": "Select the options that apply to request the exact control station (enclosed) you need.",
"aliases": [
"control station",
"pushbutton station",
"start stop station"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "config",
"label": "Configuration",
"options": [
"Start / Stop",
"Start / Stop with Pilot Light",
"HOA Selector",
"E-Stop",
"Custom (1–3 Holes)"
]
},
{
"key": "enclosure",
"label": "Enclosure",
"options": [
"NEMA 1",
"NEMA 4X",
"NEMA 12"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-pilot-device"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-dry-transformer",
"cat": "a17",
"sub": "Dry-Type",
"name": "Dry-Type Transformer",
"desc": "Select the options that apply to request the exact dry-type transformer you need.",
"aliases": [
"transformer",
"xfmr",
"dry type",
"step down",
"step up",
"480 to 208",
"general purpose transformer",
"75 kva",
"45 kva",
"30 kva"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "phase",
"label": "Phase",
"options": [
"1-Phase",
"3-Phase"
]
},
{
"key": "kva",
"label": "kVA",
"options": [
"3 kVA",
"5 kVA",
"7.5 kVA",
"10 kVA",
"15 kVA",
"25 kVA",
"37.5 kVA",
"50 kVA",
"75 kVA",
"9 kVA",
"30 kVA",
"45 kVA",
"112.5 kVA",
"150 kVA",
"225 kVA",
"300 kVA",
"500 kVA"
],
"dependsOn": "phase",
"optionsMap": {
"1-Phase": [
"3 kVA",
"5 kVA",
"7.5 kVA",
"10 kVA",
"15 kVA",
"25 kVA",
"37.5 kVA",
"50 kVA",
"75 kVA"
],
"3-Phase": [
"9 kVA",
"15 kVA",
"30 kVA",
"45 kVA",
"75 kVA",
"112.5 kVA",
"150 kVA",
"225 kVA",
"300 kVA",
"500 kVA"
]
}
},
{
"key": "primary",
"label": "Primary",
"options": [
"480V",
"240V",
"208V"
]
},
{
"key": "secondary",
"label": "Secondary",
"options": [
"208Y/120V",
"240/120V",
"120/240V",
"480Y/277V"
]
},
{
"key": "enclosure",
"label": "Enclosure",
"options": [
"NEMA 1 (Ventilated)",
"NEMA 3R"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-panelboard",
"pf-mccb",
"pf-groundrod",
"pf-label-safety"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"phase": [
"1-Phase"
]
},
"limit": {
"secondary": [
"120/240V"
]
}
},
{
"when": {
"phase": [
"3-Phase"
]
},
"limit": {
"secondary": [
"208Y/120V",
"240/120V",
"480Y/277V"
]
}
},
{
"when": {
"primary": [
"480V"
]
},
"limit": {
"secondary": [
"208Y/120V",
"240/120V",
"120/240V"
]
}
},
{
"when": {
"primary": [
"208V"
]
},
"limit": {
"secondary": [
"480Y/277V"
]
}
}
]
},
{
"id": "pf-isolation-transformer",
"cat": "a17",
"sub": "Dry-Type",
"name": "Isolation Transformer",
"desc": "Select the options that apply to request the exact isolation transformer you need.",
"aliases": [
"isolation transformer"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "kva",
"label": "kVA",
"options": [
"0.5 kVA",
"1 kVA",
"2 kVA",
"3 kVA",
"5 kVA",
"7.5 kVA",
"10 kVA",
"15 kVA"
]
},
{
"key": "voltage",
"label": "Voltage",
"options": [
"120V : 120V",
"240V : 120/240V",
"480V : 480V"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-buck-boost",
"cat": "a17",
"sub": "Dry-Type",
"name": "Buck-Boost Transformer",
"desc": "Select the options that apply to request the exact buck-boost transformer you need.",
"aliases": [
"buck boost",
"buck-boost"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "kva",
"label": "kVA",
"options": [
"0.05 kVA",
"0.1 kVA",
"0.15 kVA",
"0.25 kVA",
"0.5 kVA",
"0.75 kVA",
"1 kVA",
"1.5 kVA",
"2 kVA",
"3 kVA",
"5 kVA"
]
},
{
"key": "primary",
"label": "Primary",
"options": [
"120/240V",
"240/480V"
]
},
{
"key": "secondary",
"label": "Secondary",
"options": [
"12/24V",
"16/32V",
"24/48V"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-control-transformer",
"cat": "a17",
"sub": "Control",
"name": "Control Transformer",
"desc": "Select the options that apply to request the exact control transformer you need.",
"aliases": [
"control transformer",
"cpt",
"machine tool transformer"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "va",
"label": "VA",
"options": [
"50VA",
"75VA",
"100VA",
"150VA",
"250VA",
"500VA",
"750VA",
"1000VA"
]
},
{
"key": "primary",
"label": "Primary",
"options": [
"120/240V",
"240/480V",
"208/230/460V"
]
},
{
"key": "secondary",
"label": "Secondary",
"options": [
"120V",
"24V"
]
},
{
"key": "fusing",
"label": "Fusing",
"options": [
"Unfused",
"Primary Fused",
"Secondary Fused"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-relay",
"pf-starter"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a16"
]
},
{
"id": "pf-lv-transformer",
"cat": "a17",
"sub": "Low Voltage",
"name": "Low-Voltage / Doorbell Transformer",
"desc": "Select the options that apply to request the exact low-voltage / doorbell transformer you need.",
"aliases": [
"doorbell transformer",
"24v transformer",
"landscape transformer",
"class 2 transformer",
"hvac transformer",
"thermostat transformer"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Doorbell Transformer",
"Class 2 Low-Voltage Transformer",
"Landscape Lighting Transformer"
]
},
{
"key": "output",
"label": "Output",
"options": [
"10V",
"16V",
"24V",
"12V",
"12/15V Multi-Tap"
]
},
{
"key": "va",
"label": "VA",
"options": [
"10VA",
"16VA",
"20VA",
"40VA",
"50VA",
"75VA",
"100VA",
"150VA",
"300VA",
"600VA"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-bell-wire",
"pf-thermostat"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Doorbell Transformer"
]
},
"limit": {
"output": [
"10V",
"16V",
"24V"
],
"va": [
"10VA",
"16VA",
"20VA",
"40VA"
]
}
},
{
"when": {
"type": [
"Class 2 Low-Voltage Transformer"
]
},
"limit": {
"output": [
"24V",
"12V"
],
"va": [
"20VA",
"40VA",
"50VA",
"75VA",
"100VA"
]
}
},
{
"when": {
"type": [
"Landscape Lighting Transformer"
]
},
"limit": {
"output": [
"12/15V Multi-Tap"
],
"va": [
"150VA",
"300VA",
"600VA"
]
}
}
],
"alsoIn": [
"a18"
]
},
{
"id": "pf-hvac-whip",
"cat": "a18",
"sub": "HVAC",
"name": "Condenser / Liquidtight Whip",
"desc": "Select the options that apply to request the exact condenser / liquidtight whip you need.",
"aliases": [
"ac whip",
"condenser whip",
"whip",
"liquidtight whip",
"hvac whip"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\""
]
},
{
"key": "length",
"label": "Length",
"options": [
"4'",
"6'",
"10'"
]
},
{
"key": "conductors",
"label": "Conductors",
"options": [
"#12 THHN",
"#10 THHN",
"#8 THHN"
]
},
{
"key": "type",
"label": "Type",
"options": [
"Metallic (LFMC)",
"Nonmetallic (LFNC)"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-ac-disconnect"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-condensate-switch",
"cat": "a18",
"sub": "HVAC",
"name": "Condensate / Float Switch",
"desc": "Select the options that apply to request the exact condensate / float switch you need.",
"aliases": [
"float switch",
"condensate switch",
"condensate safety switch",
"drain pan switch"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Float Switch (Pan)",
"Inline Condensate Switch",
"Secondary Drain Pan Switch"
]
},
{
"key": "voltage",
"label": "Voltage",
"options": [
"24V",
"120V"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-thermostat"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-hvac-spd",
"cat": "a18",
"sub": "HVAC",
"name": "HVAC Surge Protector",
"desc": "Select the options that apply to request the exact hvac surge protector you need.",
"aliases": [
"hvac surge",
"ac surge protector",
"condenser surge protector"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "voltage",
"label": "Voltage",
"options": [
"120/240V",
"208–240V"
]
},
{
"key": "mount",
"label": "Mount",
"options": [
"Surface",
"Inside Disconnect"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-ac-disconnect"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a21"
]
},
{
"id": "pf-transfer-switch",
"cat": "a19",
"sub": "Generator",
"name": "Transfer Switch",
"desc": "Select the options that apply to request the exact transfer switch you need.",
"aliases": [
"transfer switch",
"ats",
"mts",
"generator panel",
"manual transfer switch"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Manual Transfer Switch",
"Automatic Transfer Switch (ATS)",
"Manual Transfer Panel (Circuits)"
]
},
{
"key": "amperage",
"label": "Amperage",
"options": [
"30A",
"50A",
"100A",
"150A",
"200A",
"400A"
]
},
{
"key": "phase",
"label": "Phase",
"options": [
"1-Phase",
"3-Phase"
]
},
{
"key": "service",
"label": "Service Rating",
"options": [
"Service-Rated",
"Non-Service-Rated"
]
},
{
"key": "enclosure",
"label": "Enclosure",
"options": [
"NEMA 1",
"NEMA 3R"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-gen-inlet",
"pf-gen-cord"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Manual Transfer Panel (Circuits)"
]
},
"limit": {
"amperage": [
"30A",
"50A"
],
"service": [
"Non-Service-Rated"
],
"phase": [
"1-Phase"
]
}
}
]
},
{
"id": "pf-interlock",
"cat": "a19",
"sub": "Generator",
"name": "Generator Interlock Kit",
"desc": "Mechanical interlock for a specific panel. Must match the panel manufacturer and series.",
"aliases": [
"interlock",
"interlock kit",
"gen interlock",
"generator interlock"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "manufacturer",
"label": "Panel Manufacturer",
"options": [
"Square D",
"Eaton",
"Siemens",
"GE / ABB"
]
},
{
"key": "series",
"label": "Panel Series",
"options": [
"QO",
"Homeline",
"BR",
"CH",
"QP",
"THQL"
],
"dependsOn": "manufacturer",
"optionsMap": {
"Square D": [
"QO",
"Homeline"
],
"Eaton": [
"BR",
"CH"
],
"Siemens": [
"QP"
],
"GE / ABB": [
"THQL"
]
}
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-breaker",
"pf-gen-inlet"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-gen-cord",
"cat": "a19",
"sub": "Generator",
"name": "Generator Cord",
"desc": "Select the options that apply to request the exact generator cord you need.",
"aliases": [
"generator cord",
"gen cord",
"genny cord",
"generator cable"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "config",
"label": "Configuration",
"options": [
"L5-30P to L5-30R",
"L14-30P to L14-30R",
"50A to 50A (CS-Style)",
"L14-30P to (4) 5-20R"
]
},
{
"key": "length",
"label": "Length",
"options": [
"10'",
"20'",
"25'",
"30'",
"50'"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-gen-inlet"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-camlock",
"cat": "a19",
"sub": "Generator",
"name": "Cam-Lock Connector / Cable",
"desc": "Select the options that apply to request the exact cam-lock connector / cable you need.",
"aliases": [
"camlock",
"cam lock",
"cam-lock",
"cams",
"cam tails"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Male Connector",
"Female Connector",
"Panel Receptacle",
"Cable Assembly"
]
},
{
"key": "series",
"label": "Series",
"options": [
"15 Series",
"16 Series"
]
},
{
"key": "color",
"label": "Color",
"options": [
"Black",
"White",
"Green",
"Red",
"Blue",
"Orange",
"Brown",
"Yellow",
"Gray"
]
},
{
"key": "cable",
"label": "Cable Size",
"options": [
"#2",
"1/0",
"2/0",
"4/0"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-gen-cabinet"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a28"
]
},
{
"id": "pf-gen-cabinet",
"cat": "a19",
"sub": "Generator",
"name": "Generator Connection Cabinet",
"desc": "Select the options that apply to request the exact generator connection cabinet you need.",
"aliases": [
"docking station",
"tap box",
"generator connection box",
"quick connect cabinet"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "amperage",
"label": "Amperage",
"options": [
"200A",
"400A",
"800A",
"1200A"
]
},
{
"key": "connection",
"label": "Connection",
"options": [
"Cam-Lock",
"Mechanical Lugs",
"Cam-Lock + Lugs"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-camlock"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-evse",
"cat": "a20",
"sub": "EV Charging",
"name": "EV Charger (EVSE)",
"desc": "Select the options that apply to request the exact ev charger (evse) you need.",
"aliases": [
"ev charger",
"evse",
"car charger",
"level 2 charger",
"ev",
"electric vehicle charger"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "current",
"label": "Output Current",
"options": [
"16A",
"32A",
"40A",
"48A",
"80A"
]
},
{
"key": "install",
"label": "Installation",
"options": [
"Plug-In (NEMA 14-50P)",
"Plug-In (NEMA 6-50P)",
"Hardwired"
]
},
{
"key": "mount",
"label": "Mount",
"options": [
"Wall",
"Pedestal"
]
},
{
"key": "connector",
"label": "Connector",
"options": [
"J1772",
"NACS (J3400)"
]
},
{
"key": "network",
"label": "Network",
"options": [
"Non-Networked",
"Networked (Wi-Fi / Cellular)"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-rcpt-power",
"pf-breaker",
"pf-safety-switch",
"pf-ev-pedestal"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"install": [
"Plug-In (NEMA 14-50P)",
"Plug-In (NEMA 6-50P)"
]
},
"limit": {
"current": [
"16A",
"32A",
"40A"
]
}
},
{
"when": {
"current": [
"48A",
"80A"
]
},
"limit": {
"install": [
"Hardwired"
]
}
}
]
},
{
"id": "pf-ev-load-mgmt",
"cat": "a20",
"sub": "EV Charging",
"name": "EV Load / Energy Management Device",
"desc": "Select the options that apply to request the exact ev load / energy management device you need.",
"aliases": [
"load management",
"energy management",
"circuit sharing",
"dcc",
"ev load manager"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Circuit-Sharing Load Manager",
"Panel Energy-Management System",
"Automatic Load Control Switch"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-evse"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-ev-pedestal",
"cat": "a20",
"sub": "EV Charging",
"name": "EV Pedestal / Mounting / Cable Management",
"desc": "Select the options that apply to request the exact ev pedestal / mounting / cable management you need.",
"aliases": [
"ev pedestal",
"cable management",
"holster",
"charger pedestal",
"ev mount",
"ev mounting hardware",
"charger mounting hardware"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Pedestal (Single)",
"Pedestal (Dual)",
"Wall Mounting Bracket",
"Cable Retractor",
"Cable Hook / Holster"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-evse"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-spd",
"cat": "a21",
"sub": "Surge Protection",
"name": "Surge Protective Device (SPD)",
"desc": "Surge protective device. Breaker-style SPDs must match the panel manufacturer and series.",
"aliases": [
"spd",
"surge protector",
"surge suppressor",
"tvss",
"whole house surge",
"panel surge",
"type 2 spd"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Type 1 SPD",
"Type 2 SPD",
"Type 3 SPD (Point-of-Use)"
]
},
{
"key": "mount",
"label": "Mount",
"options": [
"Breaker-Style (Panel)",
"Enclosure (Nipple Mount)",
"Whole-House (Meter / Panel)"
]
},
{
"key": "voltage",
"label": "System",
"options": [
"120/240V 1-Phase",
"208Y/120V 3-Phase",
"480Y/277V 3-Phase",
"240V Delta",
"480V Delta"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-load-center",
"pf-breaker"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-line-reactor",
"cat": "a21",
"sub": "Power Quality",
"name": "Line Reactor / Harmonic Filter",
"desc": "Select the options that apply to request the exact line reactor / harmonic filter you need.",
"aliases": [
"line reactor",
"reactor",
"harmonic filter",
"dv/dt filter",
"load reactor"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Line Reactor",
"Load Reactor",
"Passive Harmonic Filter",
"dV/dt Filter"
]
},
{
"key": "hp",
"label": "Horsepower",
"options": [
"1 HP",
"2 HP",
"3 HP",
"5 HP",
"10 HP",
"15 HP",
"20 HP",
"25 HP",
"30 HP",
"40 HP",
"50 HP"
]
},
{
"key": "impedance",
"label": "Impedance",
"options": [
"3%",
"5%",
"N/A"
]
},
{
"key": "voltage",
"label": "Voltage",
"options": [
"208–240V",
"480V"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-vfd"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Passive Harmonic Filter",
"dV/dt Filter"
]
},
"limit": {
"impedance": [
"N/A"
]
}
},
{
"when": {
"type": [
"Line Reactor",
"Load Reactor"
]
},
"limit": {
"impedance": [
"3%",
"5%"
]
}
}
]
},
{
"id": "pf-power-conditioner",
"cat": "a21",
"sub": "Power Quality",
"name": "Power Conditioner",
"desc": "Select the options that apply to request the exact power conditioner you need.",
"aliases": [
"power conditioner",
"line conditioner"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1 kVA",
"2 kVA",
"3 kVA",
"5 kVA"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-data-jack",
"cat": "a22",
"sub": "Data Connectivity",
"name": "Data Jack (Keystone)",
"desc": "Select the options that apply to request the exact data jack (keystone) you need.",
"aliases": [
"keystone",
"keystone jack",
"jack",
"rj45 jack",
"cat6 jack",
"cat6a jack",
"data jack",
"network jack"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "category",
"label": "Category",
"options": [
"Cat5e",
"Cat6",
"Cat6A"
]
},
{
"key": "shield",
"label": "Shielding",
"options": [
"Unshielded (UTP)",
"Shielded (STP)"
]
},
{
"key": "termination",
"label": "Termination",
"options": [
"Punch-Down (110)",
"Toolless"
]
},
{
"key": "color",
"label": "Color",
"options": [
"White",
"Ivory",
"Almond",
"Black",
"Gray",
"Blue",
"Red",
"Yellow",
"Green",
"Orange"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-wall-plate",
"pf-cat",
"pf-lv-bracket"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-patch-panel",
"cat": "a22",
"sub": "Data Connectivity",
"name": "Patch Panel",
"desc": "Select the options that apply to request the exact patch panel you need.",
"aliases": [
"patch panel",
"data patch panel"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "category",
"label": "Category",
"options": [
"Cat5e",
"Cat6",
"Cat6A"
]
},
{
"key": "ports",
"label": "Ports",
"options": [
"12",
"24",
"48"
]
},
{
"key": "type",
"label": "Type",
"options": [
"Punch-Down",
"Blank (Keystone)",
"Angled"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-rack",
"pf-patch-cord",
"pf-cable-mgmt-panel"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-rack",
"cat": "a22",
"sub": "Racks & Cabinets",
"name": "Network Rack / Cabinet",
"desc": "Select the options that apply to request the exact network rack / cabinet you need.",
"aliases": [
"rack",
"relay rack",
"wall rack",
"network rack",
"network cabinet",
"data rack"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"2-Post Floor Rack",
"4-Post Floor Rack",
"Wall-Mount Rack (Open)",
"Wall-Mount Cabinet (Enclosed)",
"Floor Cabinet"
]
},
{
"key": "size",
"label": "Rack Units",
"options": [
"6U",
"9U",
"12U",
"18U",
"24U",
"42U",
"45U"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-patch-panel",
"pf-cable-mgmt-panel"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Wall-Mount Rack (Open)",
"Wall-Mount Cabinet (Enclosed)"
]
},
"limit": {
"size": [
"6U",
"9U",
"12U",
"18U",
"24U"
]
}
},
{
"when": {
"type": [
"2-Post Floor Rack",
"4-Post Floor Rack",
"Floor Cabinet"
]
},
"limit": {
"size": [
"24U",
"42U",
"45U"
]
}
}
]
},
{
"id": "pf-cable-mgmt-panel",
"cat": "a22",
"sub": "Racks & Cabinets",
"name": "Cable Management Panel",
"desc": "Select the options that apply to request the exact cable management panel you need.",
"aliases": [
"wire manager",
"cable manager",
"cable management panel"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Horizontal (1U)",
"Horizontal (2U)",
"Vertical"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-rack"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-patch-cord",
"cat": "a22",
"sub": "Data Connectivity",
"name": "Patch Cord",
"desc": "Select the options that apply to request the exact patch cord you need.",
"aliases": [
"patch cable",
"patch cord",
"jumper cable",
"ethernet patch"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "category",
"label": "Category",
"options": [
"Cat5e",
"Cat6",
"Cat6A"
]
},
{
"key": "length",
"label": "Length",
"options": [
"1 ft",
"3 ft",
"5 ft",
"7 ft",
"10 ft",
"14 ft",
"25 ft"
]
},
{
"key": "color",
"label": "Color",
"options": [
"Blue",
"Gray",
"White",
"Yellow",
"Green",
"Red",
"Black"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-patch-panel"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-rj45",
"cat": "a22",
"sub": "Data Connectivity",
"name": "RJ45 Plug / Boot",
"desc": "Select the options that apply to request the exact rj45 plug / boot you need.",
"aliases": [
"rj45",
"rj-45",
"modular plug",
"ethernet connector",
"rj45 boot"
],
"unit": "EA",
"altUnits": [
"BOX",
"BAG"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"RJ45 Plug (Standard)",
"RJ45 Plug (Pass-Through)",
"RJ45 Boot"
]
},
{
"key": "category",
"label": "Category",
"options": [
"Cat5e",
"Cat6",
"Cat6A"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-cat"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-fiber-hardware",
"cat": "a22",
"sub": "Fiber Connectivity",
"name": "Fiber Connectivity Hardware",
"desc": "Select the options that apply to request the exact fiber connectivity hardware you need.",
"aliases": [
"fiber enclosure",
"fiber panel",
"fiber adapter",
"fiber coupler",
"lc coupler",
"fiber patch cord"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Rack-Mount Fiber Enclosure",
"Wall-Mount Fiber Enclosure",
"Fiber Adapter Panel",
"Fiber Patch Panel",
"Fiber Coupler / Adapter",
"Fiber Patch Cord"
]
},
{
"key": "connector",
"label": "Connector",
"options": [
"LC",
"SC",
"ST",
"MPO"
]
},
{
"key": "mode",
"label": "Mode",
"options": [
"Single-Mode",
"Multimode"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-fiber"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-coax-hardware",
"cat": "a22",
"sub": "Coax Connectivity",
"name": "Coax Connectivity Hardware",
"desc": "Select the options that apply to request the exact coax connectivity hardware you need.",
"aliases": [
"f connector",
"coax connector",
"splitter",
"coax splitter",
"ground block",
"barrel connector"
],
"unit": "EA",
"altUnits": [
"BAG"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"F Connector (Compression)",
"F Connector (Twist-On)",
"Coax Splitter",
"Ground Block",
"Coax Barrel (F-81)"
]
},
{
"key": "cable",
"label": "Cable",
"options": [
"RG6",
"RG59",
"RG11"
]
},
{
"key": "ports",
"label": "Splitter Ports",
"options": [
"2-Way",
"3-Way",
"4-Way",
"8-Way",
"N/A"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-coax"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Coax Splitter"
]
},
"limit": {
"ports": [
"2-Way",
"3-Way",
"4-Way",
"8-Way"
]
}
},
{
"when": {
"type": [
"F Connector (Compression)",
"F Connector (Twist-On)",
"Ground Block",
"Coax Barrel (F-81)"
]
},
"limit": {
"ports": [
"N/A"
]
}
}
]
},
{
"id": "pf-ladder-rack",
"cat": "a22",
"sub": "Pathways",
"name": "Ladder Rack (Cable Runway)",
"desc": "Select the options that apply to request the exact ladder rack (cable runway) you need.",
"aliases": [
"ladder rack",
"cable runway",
"telecom ladder"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "width",
"label": "Width",
"options": [
"6\"",
"12\"",
"18\"",
"24\""
]
},
{
"key": "length",
"label": "Length",
"options": [
"10'"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-rack",
"pf-cat"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-lv-bracket",
"cat": "a22",
"sub": "Pathways",
"name": "Low-Voltage Mounting Bracket",
"desc": "Select the options that apply to request the exact low-voltage mounting bracket you need.",
"aliases": [
"lv ring",
"low voltage ring",
"low voltage bracket",
"mud ring low voltage",
"lv bracket"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "gang",
"label": "Gang",
"options": [
"1-Gang",
"2-Gang",
"3-Gang"
]
},
{
"key": "type",
"label": "Type",
"options": [
"New Work (Nail-On)",
"Old Work (Drywall)",
"Screw-On"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-data-jack",
"pf-wall-plate"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-fa-detector",
"cat": "a23",
"sub": "Initiating Devices",
"name": "Fire Alarm Detector",
"desc": "Select the options that apply to request the exact fire alarm detector you need.",
"aliases": [
"smoke detector",
"smoke",
"heat detector",
"duct detector",
"fire detector"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Smoke Detector (Photoelectric)",
"Heat Detector (Fixed Temp)",
"Heat Detector (Rate-of-Rise)",
"Duct Detector",
"Multi-Criteria (Smoke / Heat)"
]
},
{
"key": "system",
"label": "System",
"options": [
"Addressable",
"Conventional"
]
},
{
"key": "base",
"label": "Base",
"options": [
"Standard Base",
"Sounder Base",
"Relay Base",
"Isolator Base",
"N/A (Duct)"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-fa-cable",
"pf-fa-backbox"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Duct Detector"
]
},
"limit": {
"base": [
"N/A (Duct)"
]
}
},
{
"when": {
"type": [
"Smoke Detector (Photoelectric)",
"Heat Detector (Fixed Temp)",
"Heat Detector (Rate-of-Rise)",
"Multi-Criteria (Smoke / Heat)"
]
},
"limit": {
"base": [
"Standard Base",
"Sounder Base",
"Relay Base",
"Isolator Base"
]
}
}
]
},
{
"id": "pf-fa-pull",
"cat": "a23",
"sub": "Initiating Devices",
"name": "Pull Station",
"desc": "Select the options that apply to request the exact pull station you need.",
"aliases": [
"pull station",
"manual station",
"fire pull",
"pull"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "action",
"label": "Action",
"options": [
"Single Action",
"Dual Action"
]
},
{
"key": "system",
"label": "System",
"options": [
"Addressable",
"Conventional"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-fa-backbox"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-fa-notification",
"cat": "a23",
"sub": "Notification Appliances",
"name": "Notification Appliance",
"desc": "Select the options that apply to request the exact notification appliance you need.",
"aliases": [
"horn strobe",
"horn/strobe",
"strobe",
"horn",
"speaker strobe",
"notification device",
"nac device"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Horn",
"Strobe",
"Horn / Strobe",
"Speaker",
"Speaker / Strobe",
"Chime / Strobe"
]
},
{
"key": "mount",
"label": "Mount",
"options": [
"Wall",
"Ceiling"
]
},
{
"key": "color",
"label": "Color",
"options": [
"Red",
"White"
]
},
{
"key": "environment",
"label": "Environment",
"options": [
"Indoor",
"Outdoor (Weatherproof)"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-fa-cable",
"pf-nac-ps",
"pf-fa-backbox"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-facp",
"cat": "a23",
"sub": "Panels",
"name": "Fire Alarm Control Panel (FACP)",
"desc": "Select the options that apply to request the exact fire alarm control panel (facp) you need.",
"aliases": [
"facp",
"fire panel",
"fire alarm panel"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "system",
"label": "System",
"options": [
"Addressable",
"Conventional"
]
},
{
"key": "capacity",
"label": "Capacity",
"options": [
"1 Loop (SLC)",
"2 Loops (SLC)",
"4+ Loops (Networkable)",
"5 Zones",
"10 Zones"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-fa-annunciator",
"pf-lv-power",
"pf-fa-module"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"system": [
"Addressable"
]
},
"limit": {
"capacity": [
"1 Loop (SLC)",
"2 Loops (SLC)",
"4+ Loops (Networkable)"
]
}
},
{
"when": {
"system": [
"Conventional"
]
},
"limit": {
"capacity": [
"5 Zones",
"10 Zones"
]
}
}
]
},
{
"id": "pf-fa-module",
"cat": "a23",
"sub": "Modules",
"name": "Fire Alarm Module",
"desc": "Select the options that apply to request the exact fire alarm module you need.",
"aliases": [
"monitor module",
"control module",
"relay module",
"isolator module",
"fa module"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Monitor Module",
"Mini Monitor Module",
"Control Module",
"Relay Module",
"Isolator Module"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-facp"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-fa-annunciator",
"cat": "a23",
"sub": "Panels",
"name": "Annunciator",
"desc": "Select the options that apply to request the exact annunciator you need.",
"aliases": [
"annunciator",
"remote annunciator"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"LCD Annunciator",
"LED Annunciator"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-facp"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-nac-ps",
"cat": "a23",
"sub": "Panels",
"name": "NAC Power Supply / Booster",
"desc": "Select the options that apply to request the exact nac power supply / booster you need.",
"aliases": [
"booster",
"nac extender",
"nac panel",
"nac power supply"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "amperage",
"label": "Output",
"options": [
"6A",
"8A",
"10A"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-lv-power",
"pf-fa-notification"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-eol",
"cat": "a23",
"sub": "Accessories",
"name": "End-of-Line Resistor",
"desc": "Select the options that apply to request the exact end-of-line resistor you need.",
"aliases": [
"eol",
"end of line resistor",
"eolr"
],
"unit": "EA",
"altUnits": [
"PACK"
],
"variants": [
{
"key": "value",
"label": "Value",
"options": [
"2.2k",
"3.9k",
"4.7k",
"10k",
"47k",
"Plate-Mounted EOL"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-fa-backbox",
"cat": "a23",
"sub": "Accessories",
"name": "Fire Alarm Backbox / Trim",
"desc": "Select the options that apply to request the exact fire alarm backbox / trim you need.",
"aliases": [
"backbox",
"skirt",
"trim ring",
"fire alarm box"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Surface Backbox (Red)",
"Surface Backbox (White)",
"Flush Trim Ring",
"Weatherproof Backbox"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-fa-notification",
"pf-fa-pull"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-sec-sensor",
"cat": "a24",
"sub": "Intrusion",
"name": "Intrusion Sensor",
"desc": "Select the options that apply to request the exact intrusion sensor you need.",
"aliases": [
"door contact",
"magnetic contact",
"motion detector",
"glass break",
"door position switch",
"dps"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Door Contact (Recessed)",
"Door Contact (Surface)",
"Overhead Door Contact",
"Motion Detector (PIR)",
"Glass-Break Detector",
"Door Position Switch"
]
},
{
"key": "connection",
"label": "Connection",
"options": [
"Wired",
"Wireless"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-security-cable",
"pf-acs-panel"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-keypad",
"cat": "a24",
"sub": "Access Control",
"name": "Keypad / Card Reader",
"desc": "Select the options that apply to request the exact keypad / card reader you need.",
"aliases": [
"keypad",
"card reader",
"prox reader",
"reader",
"badge reader"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Alarm Keypad",
"Proximity Card Reader",
"Multi-Technology Reader (Card / Mobile)",
"Keypad / Reader Combo"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-access-cable",
"pf-acs-panel"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-lock-hardware",
"cat": "a24",
"sub": "Access Control",
"name": "Electrified Door Hardware",
"desc": "Select the options that apply to request the exact electrified door hardware you need.",
"aliases": [
"mag lock",
"maglock",
"electric strike",
"rex",
"request to exit",
"exit button",
"rex sensor"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Electric Strike",
"Maglock (Electromagnetic Lock)",
"Request-to-Exit (REX) Sensor",
"REX / Exit Push Button"
]
},
{
"key": "voltage",
"label": "Voltage",
"options": [
"12V DC",
"24V DC",
"12/24V DC"
]
},
{
"key": "fail",
"label": "Fail Mode",
"options": [
"Fail-Safe",
"Fail-Secure",
"N/A"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-lv-power",
"pf-access-cable"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Maglock (Electromagnetic Lock)"
]
},
"limit": {
"fail": [
"Fail-Safe"
]
}
},
{
"when": {
"type": [
"Request-to-Exit (REX) Sensor",
"REX / Exit Push Button"
]
},
"limit": {
"fail": [
"N/A"
]
}
},
{
"when": {
"type": [
"Electric Strike"
]
},
"limit": {
"fail": [
"Fail-Safe",
"Fail-Secure"
]
}
}
]
},
{
"id": "pf-acs-panel",
"cat": "a24",
"sub": "Access Control",
"name": "Access-Control / Alarm Panel",
"desc": "Select the options that apply to request the exact access-control / alarm panel you need.",
"aliases": [
"access control panel",
"alarm panel",
"acp",
"security panel"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Access-Control Panel (2-Door)",
"Access-Control Panel (4-Door)",
"Intrusion Alarm Panel"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-lv-power",
"pf-keypad"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-lv-power",
"cat": "a24",
"sub": "Power",
"name": "Low-Voltage Power Supply / Backup Battery",
"desc": "Select the options that apply to request the exact low-voltage power supply / backup battery you need.",
"aliases": [
"power supply",
"battery",
"sla battery",
"12v 7ah",
"backup battery",
"lv power supply"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Power Supply (12/24V DC)",
"Power Supply with Battery Charger",
"Backup Battery (SLA)"
]
},
{
"key": "output",
"label": "Output",
"options": [
"2.5A",
"4A",
"6A",
"10A",
"N/A"
]
},
{
"key": "battery",
"label": "Battery",
"options": [
"12V 4Ah",
"12V 7Ah",
"12V 12Ah",
"12V 18Ah",
"N/A"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-lock-hardware"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Backup Battery (SLA)"
]
},
"limit": {
"output": [
"N/A"
],
"battery": [
"12V 4Ah",
"12V 7Ah",
"12V 12Ah",
"12V 18Ah"
]
}
},
{
"when": {
"type": [
"Power Supply (12/24V DC)",
"Power Supply with Battery Charger"
]
},
"limit": {
"battery": [
"N/A"
],
"output": [
"2.5A",
"4A",
"6A",
"10A"
]
}
}
],
"alsoIn": [
"a23"
]
},
{
"id": "pf-cable-tray",
"cat": "a25",
"sub": "Cable Tray",
"name": "Cable Tray",
"desc": "Select the options that apply to request the exact cable tray you need.",
"aliases": [
"cable tray",
"basket tray",
"wire basket",
"ladder tray",
"tray",
"wire mesh tray"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Ladder Tray",
"Wire-Mesh (Basket) Tray",
"Solid-Bottom Tray",
"Trough (Ventilated) Tray"
]
},
{
"key": "width",
"label": "Width",
"options": [
"2\"",
"4\"",
"6\"",
"8\"",
"12\"",
"18\"",
"24\"",
"30\"",
"36\""
]
},
{
"key": "depth",
"label": "Depth",
"options": [
"2\"",
"4\"",
"6\""
]
},
{
"key": "material",
"label": "Material",
"options": [
"Pre-Galvanized Steel",
"Hot-Dip Galvanized",
"Aluminum",
"Stainless Steel"
]
},
{
"key": "length",
"label": "Length",
"options": [
"10'",
"12'"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-tray-fitting",
"pf-rod",
"pf-strut"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Wire-Mesh (Basket) Tray"
]
},
"limit": {
"width": [
"2\"",
"4\"",
"6\"",
"8\"",
"12\"",
"18\"",
"24\""
],
"length": [
"10'"
]
}
},
{
"when": {
"type": [
"Ladder Tray"
]
},
"limit": {
"width": [
"6\"",
"12\"",
"18\"",
"24\"",
"30\"",
"36\""
]
}
}
],
"alsoIn": [
"a22"
]
},
{
"id": "pf-tray-fitting",
"cat": "a25",
"sub": "Cable Tray",
"name": "Cable Tray Fitting",
"desc": "Select the options that apply to request the exact cable tray fitting you need.",
"aliases": [
"tray elbow",
"tray splice",
"tray tee",
"tray fitting",
"tray support",
"tray clamp"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Horizontal Elbow 90°",
"Horizontal Elbow 45°",
"Vertical Elbow (Inside)",
"Vertical Elbow (Outside)",
"Tee",
"Cross",
"Reducer",
"Splice Plate",
"Tray Clamp / Hold-Down",
"Tray Support (Trapeze / Center Hanger)",
"Grounding / Bonding Connector"
]
},
{
"key": "trayType",
"label": "Tray Type",
"options": [
"Ladder",
"Basket",
"Solid-Bottom"
]
},
{
"key": "width",
"label": "Width",
"options": [
"2\"",
"4\"",
"6\"",
"8\"",
"12\"",
"18\"",
"24\"",
"30\"",
"36\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-cable-tray"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-wireway",
"cat": "a25",
"sub": "Wireway",
"name": "Wireway",
"desc": "Select the options that apply to request the exact wireway you need.",
"aliases": [
"wireway",
"gutter",
"lay in wireway"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Metal (Hinged Cover)",
"Metal (Screw Cover)",
"Nonmetallic (PVC)"
]
},
{
"key": "size",
"label": "Size",
"options": [
"2-1/2\" x 2-1/2\"",
"4\" x 4\"",
"6\" x 6\"",
"8\" x 8\"",
"10\" x 10\"",
"12\" x 12\""
]
},
{
"key": "length",
"label": "Length",
"options": [
"1'",
"2'",
"3'",
"4'",
"5'",
"10'"
]
},
{
"key": "enclosure",
"label": "Enclosure",
"options": [
"NEMA 1",
"NEMA 3R",
"NEMA 12"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-wireway-fitting"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-wireway-fitting",
"cat": "a25",
"sub": "Wireway",
"name": "Wireway Fitting",
"desc": "Select the options that apply to request the exact wireway fitting you need.",
"aliases": [
"wireway fitting",
"gutter fitting",
"wireway end cap"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"End Cap",
"Elbow 90°",
"Tee",
"Cross",
"Connector / Coupling",
"Reducer",
"Hanger",
"Closure Plate"
]
},
{
"key": "size",
"label": "Size",
"options": [
"2-1/2\" x 2-1/2\"",
"4\" x 4\"",
"6\" x 6\"",
"8\" x 8\"",
"10\" x 10\"",
"12\" x 12\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-wireway"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-surface-raceway",
"cat": "a25",
"sub": "Surface Raceway",
"name": "Surface Raceway",
"desc": "Select the options that apply to request the exact surface raceway you need.",
"aliases": [
"wiremold",
"wire mold",
"surface raceway",
"raceway",
"surface mount raceway",
"floor raceway"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Metal Surface Raceway",
"Nonmetallic Surface Raceway",
"Dual-Channel (Power / Data)",
"Floor Raceway"
]
},
{
"key": "size",
"label": "Size",
"options": [
"Small (Single Circuit)",
"Medium",
"Large (Multi-Channel)"
]
},
{
"key": "color",
"label": "Color",
"options": [
"Ivory",
"White",
"Gray",
"Metal / Stainless"
]
},
{
"key": "length",
"label": "Length",
"options": [
"5'",
"10'"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-raceway-fitting"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-raceway-fitting",
"cat": "a25",
"sub": "Surface Raceway",
"name": "Surface Raceway Fitting",
"desc": "Select the options that apply to request the exact surface raceway fitting you need.",
"aliases": [
"wiremold fitting",
"raceway box",
"raceway elbow",
"raceway fitting"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Coupling",
"Flat Elbow",
"Internal Elbow",
"External Elbow",
"Tee",
"Transition / Entrance Fitting",
"Device Box",
"Extra-Deep Device Box",
"Blank End / Cover",
"Starter Box"
]
},
{
"key": "size",
"label": "Size",
"options": [
"Small (Single Circuit)",
"Medium",
"Large (Multi-Channel)"
]
},
{
"key": "color",
"label": "Color",
"options": [
"Ivory",
"White",
"Gray",
"Metal / Stainless"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-surface-raceway"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-jbox",
"cat": "a26",
"sub": "Junction / Pull Boxes",
"name": "Junction / Pull Box",
"desc": "Select the options that apply to request the exact junction / pull box you need.",
"aliases": [
"jbox",
"j box",
"j-box",
"junction box",
"pull box",
"jb",
"splice box",
"screw cover box",
"hinged cover box"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "cover",
"label": "Cover",
"options": [
"Screw Cover",
"Hinged Cover"
]
},
{
"key": "size",
"label": "Size",
"options": [
"4\" x 4\" x 4\"",
"6\" x 6\" x 4\"",
"8\" x 8\" x 4\"",
"10\" x 10\" x 4\"",
"12\" x 12\" x 4\"",
"12\" x 12\" x 6\"",
"16\" x 16\" x 6\"",
"18\" x 18\" x 6\"",
"24\" x 24\" x 6\"",
"24\" x 24\" x 8\""
]
},
{
"key": "nema",
"label": "NEMA Rating",
"options": [
"NEMA 1",
"NEMA 3R",
"NEMA 4",
"NEMA 4X",
"NEMA 12"
]
},
{
"key": "material",
"label": "Material",
"options": [
"Painted Steel",
"Galvanized Steel",
"Stainless Steel",
"Fiberglass",
"PVC"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-emt-connector",
"pf-hub",
"pf-ground-lug"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"nema": [
"NEMA 1",
"NEMA 3R"
]
},
"limit": {
"material": [
"Painted Steel",
"Galvanized Steel"
]
}
},
{
"when": {
"nema": [
"NEMA 4X"
]
},
"limit": {
"material": [
"Stainless Steel",
"Fiberglass",
"PVC"
]
}
},
{
"when": {
"nema": [
"NEMA 12"
]
},
"limit": {
"material": [
"Painted Steel",
"Stainless Steel"
]
}
}
]
},
{
"id": "pf-trough",
"cat": "a26",
"sub": "Junction / Pull Boxes",
"name": "Trough / Splice Box",
"desc": "Select the options that apply to request the exact trough / splice box you need.",
"aliases": [
"trough",
"splice trough",
"gutter box"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"4\" x 4\" x 24\"",
"6\" x 6\" x 24\"",
"6\" x 6\" x 36\"",
"8\" x 8\" x 48\""
]
},
{
"key": "nema",
"label": "NEMA Rating",
"options": [
"NEMA 1",
"NEMA 3R"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-polaris",
"pf-lug"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-enclosure",
"cat": "a26",
"sub": "Enclosures",
"name": "Equipment / Control Enclosure",
"desc": "Select the options that apply to request the exact equipment / control enclosure you need.",
"aliases": [
"enclosure",
"nema enclosure",
"control panel box",
"hoffman box",
"nema box"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Wall-Mount (Single Door)",
"Floor-Standing",
"Push-Button Enclosure"
]
},
{
"key": "size",
"label": "Size",
"options": [
"8\" x 6\" x 4\"",
"12\" x 10\" x 6\"",
"16\" x 12\" x 6\"",
"20\" x 16\" x 8\"",
"24\" x 20\" x 8\"",
"30\" x 24\" x 8\"",
"36\" x 30\" x 10\""
]
},
{
"key": "nema",
"label": "NEMA Rating",
"options": [
"NEMA 1",
"NEMA 3R",
"NEMA 4",
"NEMA 4X",
"NEMA 12"
]
},
{
"key": "material",
"label": "Material",
"options": [
"Painted Steel",
"Galvanized Steel",
"Stainless Steel",
"Fiberglass",
"PVC"
]
},
{
"key": "panel",
"label": "Back Panel",
"options": [
"With Back Panel",
"No Back Panel"
],
"default": "With Back Panel"
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-pilot-device",
"pf-hub"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"nema": [
"NEMA 1",
"NEMA 3R"
]
},
"limit": {
"material": [
"Painted Steel",
"Galvanized Steel"
]
}
},
{
"when": {
"nema": [
"NEMA 4X"
]
},
"limit": {
"material": [
"Stainless Steel",
"Fiberglass",
"PVC"
]
}
},
{
"when": {
"nema": [
"NEMA 12"
]
},
"limit": {
"material": [
"Painted Steel",
"Stainless Steel"
]
}
}
],
"alsoIn": [
"a16"
]
},
{
"id": "pf-cord-grip",
"cat": "a27",
"sub": "Cord & Cable Fittings",
"name": "Cord Grip / Cable Gland",
"desc": "Select the options that apply to request the exact cord grip / cable gland you need.",
"aliases": [
"cord grip",
"strain relief",
"cable gland",
"kellems",
"cord connector fitting"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Cord Grip (Strain Relief)",
"Cable Gland (Liquidtight)",
"Cord Grip with Mesh",
"Sealing Cord Connector"
]
},
{
"key": "hub",
"label": "Hub Size",
"options": [
"3/8\"",
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\""
]
},
{
"key": "range",
"label": "Cord Range",
"options": [
"0.125–0.25\"",
"0.25–0.375\"",
"0.375–0.5\"",
"0.5–0.625\"",
"0.625–0.75\"",
"0.75–0.875\"",
"0.875–1.0\""
]
},
{
"key": "material",
"label": "Material",
"options": [
"Nylon",
"Nickel-Plated Brass",
"Aluminum",
"Stainless Steel"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-cord",
"pf-locknut"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-seal-fitting",
"cat": "a27",
"sub": "Hazardous / Sealing",
"name": "Sealing Fitting (Seal-Off)",
"desc": "Select the options that apply to request the exact sealing fitting (seal-off) you need.",
"aliases": [
"seal off",
"sealoff",
"seal-off",
"eys",
"sealing fitting",
"explosion proof seal"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "size",
"label": "Size",
"options": [
"1/2\"",
"3/4\"",
"1\"",
"1-1/4\"",
"1-1/2\"",
"2\"",
"2-1/2\"",
"3\"",
"3-1/2\"",
"4\""
]
},
{
"key": "orientation",
"label": "Orientation",
"options": [
"Vertical",
"Vertical / Horizontal"
]
},
{
"key": "material",
"label": "Material",
"options": [
"Malleable Iron",
"Aluminum"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-sealant",
"pf-rmc"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-wp-connector",
"cat": "a27",
"sub": "Waterproof Connectors",
"name": "Waterproof Wire Connector",
"desc": "Select the options that apply to request the exact waterproof wire connector you need.",
"aliases": [
"waterproof wire nut",
"direct bury splice",
"gel connector",
"silicone wire nut",
"underground splice"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Silicone-Filled Twist-On",
"Gel-Filled Butt Splice",
"Direct-Burial Splice Kit"
]
},
{
"key": "size",
"label": "Size",
"options": [
"Small",
"Medium",
"Large"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-ufb",
"pf-landscape"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-temp-panel",
"cat": "a28",
"sub": "Temporary Distribution",
"name": "Temporary Power Panel / Spider Box",
"desc": "Select the options that apply to request the exact temporary power panel / spider box you need.",
"aliases": [
"temp power",
"spider box",
"spider",
"temp panel",
"t-pole",
"temporary pole",
"distro box",
"temporary power"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Temporary Power Panel (Pole-Mount)",
"Spider Box (Portable)",
"Temporary Distribution Box",
"Temporary GFCI Receptacle Box"
]
},
{
"key": "input",
"label": "Input",
"options": [
"50A",
"100A",
"200A"
]
},
{
"key": "outlets",
"label": "Outlets",
"options": [
"4–6 Outlets",
"6–10 Outlets",
"10+ Outlets"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-extension-cord",
"pf-string-lights",
"pf-portable-gfci"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-extension-cord",
"cat": "a28",
"sub": "Cords",
"name": "Extension / Temporary Cord",
"desc": "Select the options that apply to request the exact extension / temporary cord you need.",
"aliases": [
"extension cord",
"drop cord",
"stinger",
"gfci cord",
"12 gauge cord",
"cord set",
"temporary cord"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Extension Cord (Single Outlet)",
"Extension Cord (Triple Tap)",
"GFCI Cord Set",
"Twist-Lock Temporary Cord"
]
},
{
"key": "gauge",
"label": "Gauge",
"options": [
"16/3",
"14/3",
"12/3",
"10/3",
"10/4",
"8/4",
"6/4"
]
},
{
"key": "length",
"label": "Length",
"options": [
"25'",
"50'",
"100'"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-temp-panel"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Twist-Lock Temporary Cord"
]
},
"limit": {
"gauge": [
"10/4",
"8/4",
"6/4"
]
}
},
{
"when": {
"type": [
"Extension Cord (Single Outlet)",
"Extension Cord (Triple Tap)",
"GFCI Cord Set"
]
},
"limit": {
"gauge": [
"16/3",
"14/3",
"12/3",
"10/3"
]
}
}
]
},
{
"id": "pf-string-lights",
"cat": "a28",
"sub": "Temporary Lighting",
"name": "Temporary / String Lights",
"desc": "Select the options that apply to request the exact temporary / string lights you need.",
"aliases": [
"string lights",
"temp lights",
"stringers",
"work light",
"temporary lighting"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"LED String Lights",
"Temporary Work Light",
"Tower / Stand Light"
]
},
{
"key": "length",
"label": "Length",
"options": [
"50'",
"100'",
"N/A"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-temp-panel"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"LED String Lights"
]
},
"limit": {
"length": [
"50'",
"100'"
]
}
},
{
"when": {
"type": [
"Temporary Work Light",
"Tower / Stand Light"
]
},
"limit": {
"length": [
"N/A"
]
}
}
]
},
{
"id": "pf-cord-connector",
"cat": "a28",
"sub": "Cords",
"name": "Cord Plug / Connector",
"desc": "Select the options that apply to request the exact cord plug / connector you need.",
"aliases": [
"plug end",
"cord cap",
"twist lock plug",
"connector body",
"replacement plug",
"cord end"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Straight-Blade Plug",
"Straight-Blade Connector",
"Twist-Lock Plug",
"Twist-Lock Connector"
]
},
{
"key": "nema",
"label": "NEMA",
"options": [
"5-15",
"5-20",
"6-20",
"L5-20",
"L5-30",
"L6-20",
"L6-30",
"L14-20",
"L14-30",
"L21-30"
]
},
{
"key": "grade",
"label": "Grade",
"options": [
"Commercial",
"Industrial"
],
"default": "Industrial"
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-cord"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Straight-Blade Plug",
"Straight-Blade Connector"
]
},
"limit": {
"nema": [
"5-15",
"5-20",
"6-20"
]
}
},
{
"when": {
"type": [
"Twist-Lock Plug",
"Twist-Lock Connector"
]
},
"limit": {
"nema": [
"L5-20",
"L5-30",
"L6-20",
"L6-30",
"L14-20",
"L14-30",
"L21-30"
]
}
}
]
},
{
"id": "pf-portable-gfci",
"cat": "a28",
"sub": "Cords",
"name": "Portable GFCI",
"desc": "Select the options that apply to request the exact portable gfci you need.",
"aliases": [
"portable gfci",
"pigtail gfci",
"inline gfci"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"In-Line Portable GFCI",
"Portable GFCI Box (Multi-Outlet)"
]
},
{
"key": "rating",
"label": "Rating",
"options": [
"15A",
"20A",
"30A"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-extension-cord"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-firestop-sealant",
"cat": "a29",
"sub": "Firestop",
"name": "Firestop Sealant / Caulk",
"desc": "Firestop sealant. The required product depends on the tested UL system for each penetration — confirm with the project firestop schedule.",
"aliases": [
"firestop",
"fire caulk",
"fire stop",
"red caulk",
"intumescent",
"fire sealant"
],
"unit": "EA",
"altUnits": [
"CASE"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Intumescent Caulk",
"Elastomeric (Silicone) Sealant",
"Latex Sealant"
]
},
{
"key": "package",
"label": "Package",
"options": [
"10.1 oz Tube",
"20 oz Sausage",
"29 oz Tube",
"5 Gal Pail"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-firestop-device"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-firestop-putty",
"cat": "a29",
"sub": "Firestop",
"name": "Firestop Putty / Putty Pads",
"desc": "Select the options that apply to request the exact firestop putty / putty pads you need.",
"aliases": [
"putty pad",
"putty pads",
"fire putty",
"firestop putty"
],
"unit": "EA",
"altUnits": [
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Putty (Stick)",
"Putty (Bucket)",
"Putty Pads 7\" x 7\"",
"Putty Pads 9\" x 9\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-box-4sq"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-firestop-foam",
"cat": "a29",
"sub": "Firestop",
"name": "Firestop Foam / Mortar",
"desc": "Select the options that apply to request the exact firestop foam / mortar you need.",
"aliases": [
"fire foam",
"firestop mortar",
"fire mortar"
],
"unit": "EA",
"altUnits": [
"CASE"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Firestop Foam (Can)",
"Firestop Mortar (Bag)"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-firestop-device",
"cat": "a29",
"sub": "Firestop",
"name": "Firestop Device",
"desc": "Select the options that apply to request the exact firestop device you need.",
"aliases": [
"firestop sleeve",
"wrap strip",
"fire collar",
"pass through",
"fire pillow",
"firestop block"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Cable Pass-Through Sleeve",
"Intumescent Wrap Strip",
"Firestop Collar (Plastic Pipe)",
"Firestop Pillow / Block"
]
},
{
"key": "size",
"label": "Size",
"options": [
"1\"",
"2\"",
"3\"",
"4\"",
"6\"",
"N/A"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-firestop-sealant"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Firestop Pillow / Block"
]
},
"limit": {
"size": [
"N/A"
]
}
},
{
"when": {
"type": [
"Cable Pass-Through Sleeve",
"Intumescent Wrap Strip",
"Firestop Collar (Plastic Pipe)"
]
},
"limit": {
"size": [
"1\"",
"2\"",
"3\"",
"4\"",
"6\""
]
}
}
]
},
{
"id": "pf-tape",
"cat": "a30",
"sub": "Tape",
"name": "Electrical Tape",
"desc": "Select the options that apply to request the exact electrical tape you need.",
"aliases": [
"tape",
"electrical tape",
"phase tape",
"color tape",
"friction tape",
"rubber tape",
"splicing tape",
"mastic",
"vinyl tape"
],
"unit": "ROLL",
"altUnits": [
"PACK",
"BOX"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Vinyl Electrical Tape",
"Phase / Color-Code Tape",
"Rubber Splicing Tape",
"Friction Tape",
"Mastic Tape"
]
},
{
"key": "width",
"label": "Width",
"options": [
"3/4\"",
"1-1/2\"",
"2\""
]
},
{
"key": "color",
"label": "Color",
"options": [
"Black",
"White",
"Red",
"Blue",
"Green",
"Yellow",
"Brown",
"Orange",
"Gray",
"Violet"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-heat-shrink",
"pf-split-bolt"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Rubber Splicing Tape",
"Friction Tape",
"Mastic Tape"
]
},
"limit": {
"color": [
"Black"
]
}
},
{
"when": {
"type": [
"Vinyl Electrical Tape",
"Phase / Color-Code Tape"
]
},
"limit": {
"width": [
"3/4\""
]
}
}
]
},
{
"id": "pf-heat-shrink",
"cat": "a30",
"sub": "Heat Shrink",
"name": "Heat Shrink",
"desc": "Select the options that apply to request the exact heat shrink you need.",
"aliases": [
"heat shrink",
"shrink tube",
"heatshrink",
"shrink"
],
"unit": "EA",
"altUnits": [
"PACK",
"FT"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Thin-Wall Tubing",
"Heavy-Wall with Adhesive",
"Assorted Kit"
]
},
{
"key": "size",
"label": "Size",
"options": [
"3/16\"",
"1/4\"",
"3/8\"",
"1/2\"",
"3/4\"",
"1\"",
"1-1/2\"",
"2\"",
"3\"",
"Assorted"
]
},
{
"key": "color",
"label": "Color",
"options": [
"Black",
"Red",
"Clear",
"Assorted",
"Phase Colors"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-lug",
"pf-crimp"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"Assorted Kit"
]
},
"limit": {
"size": [
"Assorted"
],
"color": [
"Assorted",
"Phase Colors"
]
}
},
{
"when": {
"type": [
"Thin-Wall Tubing",
"Heavy-Wall with Adhesive"
]
},
"limit": {
"size": [
"3/16\"",
"1/4\"",
"3/8\"",
"1/2\"",
"3/4\"",
"1\"",
"1-1/2\"",
"2\"",
"3\""
],
"color": [
"Black",
"Red",
"Clear"
]
}
}
]
},
{
"id": "pf-pulling-lube",
"cat": "a30",
"sub": "Chemicals",
"name": "Wire-Pulling Lubricant",
"desc": "Select the options that apply to request the exact wire-pulling lubricant you need.",
"aliases": [
"wire lube",
"pulling lube",
"lube",
"pulling compound",
"wire pulling lubricant"
],
"unit": "EA",
"altUnits": [
"CASE"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Gel",
"Wax",
"Low-Temperature"
]
},
{
"key": "package",
"label": "Package",
"options": [
"1 Qt",
"1 Gal",
"5 Gal Pail"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-pull-line",
"pf-thhn"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-pvc-cement",
"cat": "a30",
"sub": "Chemicals",
"name": "PVC Cement / Primer",
"desc": "Select the options that apply to request the exact pvc cement / primer you need.",
"aliases": [
"pvc glue",
"glue",
"pvc cement",
"primer",
"purple primer",
"cement"
],
"unit": "EA",
"altUnits": [
"CASE"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"PVC Cement (Regular Body)",
"PVC Cement (Medium / Heavy Body)",
"PVC Primer",
"All-Weather Cement"
]
},
{
"key": "size",
"label": "Size",
"options": [
"4 oz",
"8 oz",
"Pint",
"Quart",
"1 Gal"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-pvc40",
"pf-pvc-coupling"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-sealant",
"cat": "a30",
"sub": "Chemicals",
"name": "Sealant / Compound",
"desc": "Select the options that apply to request the exact sealant / compound you need.",
"aliases": [
"duct seal",
"silicone",
"rtv",
"noalox",
"no-ox",
"anti oxidant",
"pipe dope",
"thread sealant",
"anti seize",
"cold galv",
"zinc spray",
"sealing compound",
"chico"
],
"unit": "EA",
"altUnits": [
"CASE"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Duct Seal",
"Silicone Sealant",
"Electrical-Grade Silicone (RTV)",
"Thread Sealant (Pipe Dope)",
"Anti-Oxidant Compound",
"Anti-Seize",
"Cold-Galvanizing Compound",
"Sealing Compound & Fiber Dam"
]
},
{
"key": "package",
"label": "Package",
"options": [
"Small (Tube / 1 lb)",
"Large (Can / Gallon)",
"Aerosol",
"Kit"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-xhhw-al",
"pf-lug",
"pf-seal-fitting"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-contact-cleaner",
"cat": "a30",
"sub": "Chemicals",
"name": "Cleaner / Lubricant Spray",
"desc": "Select the options that apply to request the exact cleaner / lubricant spray you need.",
"aliases": [
"contact cleaner",
"electrical cleaner",
"penetrating oil",
"silicone spray"
],
"unit": "EA",
"altUnits": [
"CASE"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Contact Cleaner",
"Electrical Parts Cleaner",
"Silicone Lubricant Spray",
"Penetrating Oil"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-cable-tie",
"cat": "a31",
"sub": "Cable Ties",
"name": "Cable Tie",
"desc": "Select the options that apply to request the exact cable tie you need.",
"aliases": [
"zip tie",
"zip ties",
"tie wrap",
"wire tie",
"cable ties",
"uv zip tie",
"stainless zip tie"
],
"unit": "PACK",
"altUnits": [
"BAG",
"EA"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Standard Nylon",
"UV-Resistant",
"Stainless Steel",
"Releasable",
"Heavy-Duty"
]
},
{
"key": "length",
"label": "Length",
"options": [
"4\"",
"8\"",
"11\"",
"14\"",
"15\"",
"24\""
]
},
{
"key": "color",
"label": "Color",
"options": [
"Natural",
"Black",
"Assorted Colors",
"Stainless"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-tie-mount"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"constraints": [
{
"when": {
"type": [
"UV-Resistant"
]
},
"limit": {
"color": [
"Black"
]
}
},
{
"when": {
"type": [
"Stainless Steel"
]
},
"limit": {
"color": [
"Stainless"
]
}
},
{
"when": {
"type": [
"Standard Nylon",
"Releasable",
"Heavy-Duty"
]
},
"limit": {
"color": [
"Natural",
"Black",
"Assorted Colors"
]
}
}
]
},
{
"id": "pf-tie-mount",
"cat": "a31",
"sub": "Cable Ties",
"name": "Cable Tie Mount / Hook & Loop",
"desc": "Select the options that apply to request the exact cable tie mount / hook & loop you need.",
"aliases": [
"tie mount",
"velcro",
"hook and loop",
"velcro tie",
"cable tie mount"
],
"unit": "EA",
"altUnits": [
"PACK"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Adhesive Tie Mount",
"Screw-Mount Tie Mount",
"Push-Mount (Fir Tree)",
"Hook & Loop Tie",
"Hook & Loop Roll"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-cable-tie"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-wire-loom",
"cat": "a31",
"sub": "Cable Protection",
"name": "Wire Loom / Spiral Wrap",
"desc": "Select the options that apply to request the exact wire loom / spiral wrap you need.",
"aliases": [
"loom",
"wire loom",
"spiral wrap",
"split loom",
"braided sleeve"
],
"unit": "FT",
"altUnits": [
"ROLL"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Split Loom",
"Spiral Wrap",
"Braided Sleeving"
]
},
{
"key": "size",
"label": "Size",
"options": [
"1/4\"",
"3/8\"",
"1/2\"",
"3/4\"",
"1\"",
"1-1/2\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-pull-line",
"cat": "a31",
"sub": "Pulling",
"name": "Pull Line",
"desc": "Select the options that apply to request the exact pull line you need.",
"aliases": [
"pull string",
"jet line",
"jetline",
"mule tape",
"pull rope",
"string",
"pull line",
"fish line"
],
"unit": "ROLL",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Pull String (Poly)",
"Pull Rope",
"Mule Tape (Measuring)",
"Fish Line"
]
},
{
"key": "strength",
"label": "Strength",
"options": [
"210 lb",
"500 lb",
"1250 lb",
"1800 lb",
"2500 lb"
]
},
{
"key": "length",
"label": "Length",
"options": [
"500 ft",
"1000 ft",
"3000 ft",
"6500 ft"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-pulling-lube",
"pf-pulling-grip"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-pulling-grip",
"cat": "a31",
"sub": "Pulling",
"name": "Cable Pulling Grip",
"desc": "Select the options that apply to request the exact cable pulling grip you need.",
"aliases": [
"pulling grip",
"pulling sock",
"kellems grip",
"basket grip",
"sock"
],
"unit": "EA",
"altUnits": [],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Single-Eye",
"Double-Eye",
"Offset Eye",
"Split (Lace-Up)"
]
},
{
"key": "range",
"label": "Cable Diameter",
"options": [
"0.25–0.5\"",
"0.5–0.75\"",
"0.75–1\"",
"1–1.25\"",
"1.25–1.5\"",
"1.5–2\"",
"2–2.5\""
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-pull-line"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-wire-marker",
"cat": "a31",
"sub": "Marking",
"name": "Wire / Cable Marker",
"desc": "Select the options that apply to request the exact wire / cable marker you need.",
"aliases": [
"wire marker",
"marker book",
"cable tag",
"cable label",
"wire label",
"heat shrink label",
"wire numbers"
],
"unit": "EA",
"altUnits": [
"PACK"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Wire Marker Book (0–9)",
"Wire Marker Book (A–Z)",
"Clip-On Marker",
"Printable Heat-Shrink Label",
"Tie-On Cable Tag",
"Self-Laminating Label"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null,
"alsoIn": [
"a32"
]
},
{
"id": "pf-label-safety",
"cat": "a32",
"sub": "Labels",
"name": "Safety / Warning Label",
"desc": "Select the options that apply to request the exact safety / warning label you need.",
"aliases": [
"arc flash label",
"warning label",
"danger label",
"voltage label",
"caution label"
],
"unit": "EA",
"altUnits": [
"PACK"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Arc-Flash Warning",
"Voltage Label",
"Danger / High Voltage",
"Service Disconnect",
"Multiple Power Sources",
"Other Required Warning"
]
},
{
"key": "material",
"label": "Material",
"options": [
"Vinyl Adhesive",
"Rigid Plastic (Screw-On)",
"Engraved Phenolic"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-label-panel"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-label-panel",
"cat": "a32",
"sub": "Labels",
"name": "Panel & Circuit Label",
"desc": "Select the options that apply to request the exact panel & circuit label you need.",
"aliases": [
"panel schedule",
"circuit directory",
"panel label",
"nameplate",
"engraved tag",
"lamacoid",
"phase label",
"circuit label"
],
"unit": "EA",
"altUnits": [
"PACK"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Panel Directory (Card)",
"Circuit Number Labels",
"Panel Name Label",
"Phase Label (L1 / L2 / L3)",
"Engraved Nameplate"
]
},
{
"key": "material",
"label": "Material",
"options": [
"Paper / Card",
"Vinyl Adhesive",
"Engraved Phenolic"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [
"pf-label-safety"
],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-conduit-label",
"cat": "a32",
"sub": "Labels",
"name": "Conduit / Raceway Label",
"desc": "Select the options that apply to request the exact conduit / raceway label you need.",
"aliases": [
"conduit marker",
"pipe marker",
"conduit label",
"raceway label"
],
"unit": "EA",
"altUnits": [
"PACK"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Voltage Marker",
"Emergency System",
"Fire Alarm",
"Custom Text"
]
},
{
"key": "size",
"label": "Fits Conduit",
"options": [
"1/2\"–1-1/4\"",
"1-1/2\"–2-1/2\"",
"3\" and Up"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
},
{
"id": "pf-device-label",
"cat": "a32",
"sub": "Labels",
"name": "Device / Receptacle Label",
"desc": "Select the options that apply to request the exact device / receptacle label you need.",
"aliases": [
"device label",
"receptacle label",
"outlet label"
],
"unit": "EA",
"altUnits": [
"PACK"
],
"variants": [
{
"key": "type",
"label": "Type",
"options": [
"Printed Adhesive",
"Engraved Plate",
"Circuit ID Sticker"
]
}
],
"brandOptions": [],
"imageFamilyKey": null,
"frequentlyUsedWith": [],
"status": "active",
"manufacturerPartNumbers": null,
"upc": null
}
];
