// Static reference data (not user-editable).
export const CATEGORIES = [
 {
  "key": "wc",
  "label": "Wire & Cable",
  "initials": "W&C"
 },
 {
  "key": "cn",
  "label": "Conduit",
  "initials": "CN"
 },
 {
  "key": "cf",
  "label": "Conduit Fittings",
  "initials": "CF"
 },
 {
  "key": "bx",
  "label": "Boxes",
  "initials": "BX"
 },
 {
  "key": "sp",
  "label": "Supports",
  "initials": "SP"
 },
 {
  "key": "gb",
  "label": "Grounding & Bonding",
  "initials": "GB"
 },
 {
  "key": "wt",
  "label": "Wire Connectors",
  "initials": "WT"
 },
 {
  "key": "pd",
  "label": "Panels & Distribution",
  "initials": "PD"
 },
 {
  "key": "wd",
  "label": "Wiring Devices",
  "initials": "WD"
 },
 {
  "key": "lt",
  "label": "Lighting",
  "initials": "LT"
 },
 {
  "key": "lv",
  "label": "Low Voltage",
  "initials": "LV"
 },
 {
  "key": "fa",
  "label": "Fasteners",
  "initials": "FA"
 },
 {
  "key": "ee",
  "label": "Electrical Equipment",
  "initials": "EE"
 }
];
export const IMAGE_FAMILIES = {
 "pd-breakers": {
  "url": "https://commons.wikimedia.org/wiki/Special:FilePath/Square_D_20-Amp_Single-Pole_Breaker.JPG?width=300",
  "urlLarge": "https://commons.wikimedia.org/wiki/Special:FilePath/Square_D_20-Amp_Single-Pole_Breaker.JPG?width=640",
  "alt": "Square D single-pole circuit breaker",
  "imageSource": "Wikimedia Commons — \"Square D 20-Amp Single-Pole Breaker.JPG\" (CC BY-SA 3.0)",
  "imageStatus": "active"
 },
 "wd-gfci": {
  "url": "https://commons.wikimedia.org/wiki/Special:FilePath/Residential_GFCI_receptacle.jpg?width=300",
  "urlLarge": "https://commons.wikimedia.org/wiki/Special:FilePath/Residential_GFCI_receptacle.jpg?width=640",
  "alt": "Residential GFCI receptacle",
  "imageSource": "Wikimedia Commons — \"Residential GFCI receptacle.jpg\" (CC BY-SA 4.0)",
  "imageStatus": "active"
 },
 "wc-romex-nm-b": {
  "url": "https://assets.southwire.com/adaptivemedia/rendition?id=6368e6a53f4c484304f0e768ba3aaa88d59a7546&prid=01200Wx1200H&clid=SAPDAM&prclid=productpictures",
  "urlLarge": "https://assets.southwire.com/adaptivemedia/rendition?id=6368e6a53f4c484304f0e768ba3aaa88d59a7546&prid=01200Wx1200H&clid=SAPDAM&prclid=productpictures",
  "alt": "Southwire Romex NM-B cable coil",
  "imageSource": "Southwire official product page — Romex Brand SIMpull NM-B Cable (12-2 w/ ground)",
  "imageStatus": "active"
 },
 "wc-thhn-thwn": {
  "url": "https://assets.southwire.com/adaptivemedia/rendition?id=3763a1d5f0bc271b61979242a0a5c11a29d16fec&prid=01200Wx1200H&clid=SAPDAM&prclid=productpictures",
  "urlLarge": "https://assets.southwire.com/adaptivemedia/rendition?id=3763a1d5f0bc271b61979242a0a5c11a29d16fec&prid=01200Wx1200H&clid=SAPDAM&prclid=productpictures",
  "alt": "Southwire SIMpull THHN/THWN-2 copper wire",
  "imageSource": "Southwire official product page — SIMpull THHN/THWN-2 Copper (SPEC10000)",
  "imageStatus": "active"
 },
 "cn-liquidtight": {
  "url": "https://assets.southwire.com/adaptivemedia/rendition?id=8f346a52311c60cfee1aaa4b4996e87e830d8f49&prid=01200Wx1200H&clid=SAPDAM&prclid=productpictures",
  "urlLarge": "https://assets.southwire.com/adaptivemedia/rendition?id=8f346a52311c60cfee1aaa4b4996e87e830d8f49&prid=01200Wx1200H&clid=SAPDAM&prclid=productpictures",
  "alt": "Southwire Titan2 Liquidtight flexible metal conduit",
  "imageSource": "Southwire official product page — Titan2 Type UL Liquidtight Flexible Metal Conduit (SPEC60515)",
  "imageStatus": "active"
 },
 "cf-conduit-bodies": {
  "url": "https://www.eaton.com/mdmfiles/PDM19357354/LB29_C/1000x1000_300dpi",
  "urlLarge": "https://www.eaton.com/mdmfiles/PDM19357354/LB29_C/1000x1000_300dpi",
  "alt": "Eaton Crouse-Hinds LB conduit outlet body",
  "imageSource": "Eaton official SKU page — Crouse-Hinds series Condulet Mark 9 LB29, 3/4\" trade size",
  "imageStatus": "active"
 },
 "pd-fuses": {
  "url": "https://www.eaton.com/mdmfiles/PDM733973/FRS-R-30_C/1000x1000_300dpi",
  "urlLarge": "https://www.eaton.com/mdmfiles/PDM733973/FRS-R-30_C/1000x1000_300dpi",
  "alt": "Eaton Bussmann Class RK5 time-delay fuse",
  "imageSource": "Eaton official SKU page — Bussmann series FRS-R-30, Class RK5, 30A",
  "imageStatus": "active"
 },
 "wd-receptacles": {
  "url": "https://s7d9.scene7.com/is/image/leviton/CR20-I?$500x500$&fmt=webp",
  "urlLarge": "https://s7d9.scene7.com/is/image/leviton/CR20-I?$500x500$&fmt=webp",
  "alt": "Leviton commercial-grade duplex receptacle",
  "imageSource": "Leviton official product page — CR20-I, 20A commercial-grade duplex receptacle",
  "imageStatus": "active"
 }
};
