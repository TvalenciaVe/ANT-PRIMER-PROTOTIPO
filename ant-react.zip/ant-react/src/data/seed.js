// Demo seed data extracted from the original single-file ANT prototype.
// Loaded only when nothing is saved in localStorage.
export const PRODUCTS = [
 {
  "id": "wc1",
  "hidden": true,
  "cat": "wc",
  "sub": "THHN/THWN",
  "name": "THHN 12 AWG Black",
  "desc": "Stranded copper building wire for conduit runs.",
  "mfr": "Southwire",
  "part": "THHN-12-BLK",
  "material": "Copper, THHN/THWN-2 insulation",
  "size": "12 AWG",
  "application": "Branch circuit wiring inside conduit",
  "unit": "FT",
  "brands": [
   {
    "mfr": "Southwire",
    "part": "THHN-12-BLK"
   },
   {
    "mfr": "Encore Wire",
    "part": "ENC-12-BLK"
   },
   {
    "mfr": "Cerrowire",
    "part": "CER-12-BLK"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "supersededBy": "pf-thhn"
 },
 {
  "id": "wc2",
  "hidden": true,
  "cat": "wc",
  "sub": "THHN/THWN",
  "name": "THHN 12 AWG White",
  "desc": "Stranded copper building wire, neutral color.",
  "mfr": "Southwire",
  "part": "THHN-12-WHT",
  "material": "Copper, THHN/THWN-2 insulation",
  "size": "12 AWG",
  "application": "Branch circuit neutral conductor",
  "unit": "FT",
  "brands": [
   {
    "mfr": "Southwire",
    "part": "THHN-12-WHT"
   },
   {
    "mfr": "Encore Wire",
    "part": "ENC-12-WHT"
   },
   {
    "mfr": "Cerrowire",
    "part": "CER-12-WHT"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "supersededBy": "pf-thhn"
 },
 {
  "id": "wc3",
  "hidden": true,
  "cat": "wc",
  "sub": "THHN/THWN",
  "name": "THHN 12 AWG Green",
  "desc": "Stranded copper building wire, ground color.",
  "mfr": "Southwire",
  "part": "THHN-12-GRN",
  "material": "Copper, THHN/THWN-2 insulation",
  "size": "12 AWG",
  "application": "Equipment grounding conductor",
  "unit": "FT",
  "brands": [
   {
    "mfr": "Southwire",
    "part": "THHN-12-GRN"
   },
   {
    "mfr": "Encore Wire",
    "part": "ENC-12-GRN"
   },
   {
    "mfr": "Cerrowire",
    "part": "CER-12-GRN"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "supersededBy": "pf-thhn"
 },
 {
  "id": "wc4",
  "hidden": true,
  "cat": "wc",
  "sub": "THHN/THWN",
  "name": "THHN 10 AWG Black",
  "desc": "Heavier gauge stranded copper wire for 30A circuits.",
  "mfr": "Southwire",
  "part": "THHN-10-BLK",
  "material": "Copper, THHN/THWN-2 insulation",
  "size": "10 AWG",
  "application": "30A branch circuits",
  "unit": "FT",
  "brands": [
   {
    "mfr": "Southwire",
    "part": "THHN-10-BLK"
   },
   {
    "mfr": "Encore Wire",
    "part": "ENC-10-BLK"
   },
   {
    "mfr": "Cerrowire",
    "part": "CER-10-BLK"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "supersededBy": "pf-thhn"
 },
 {
  "id": "wc5",
  "cat": "wc",
  "sub": "MC Cable",
  "name": "MC Cable 12/2",
  "desc": "Metal-clad armored cable for branch circuits.",
  "mfr": "AFC Cable Systems",
  "part": "MC-12-2",
  "material": "Copper conductors, steel armor",
  "size": "12/2 w/ ground",
  "application": "Fast branch circuit runs, no conduit required",
  "unit": "FT",
  "brands": [
   {
    "mfr": "AFC Cable Systems",
    "part": "MC-12-2"
   },
   {
    "mfr": "Southwire",
    "part": "SOU-12-2"
   },
   {
    "mfr": "Encore Wire",
    "part": "ENC-12-2"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-mc"
 },
 {
  "id": "wc6",
  "cat": "wc",
  "sub": "Romex/NM-B",
  "name": "Romex NM-B 12/2",
  "desc": "Non-metallic sheathed cable for interior branch wiring.",
  "mfr": "Southwire",
  "part": "NMB-12-2",
  "material": "Copper conductors, PVC jacket",
  "size": "12/2 w/ ground",
  "application": "Interior residential/light commercial wiring",
  "unit": "FT",
  "brands": [
   {
    "mfr": "Southwire",
    "part": "NMB-12-2"
   },
   {
    "mfr": "Encore Wire",
    "part": "ENC-12-2"
   },
   {
    "mfr": "Cerrowire",
    "part": "CER-12-2"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-nmb"
 },
 {
  "id": "wc7",
  "cat": "wc",
  "sub": "SER/SEU",
  "name": "SER Cable 4/0",
  "desc": "Service entrance cable for main feeders.",
  "mfr": "Encore Wire",
  "part": "SER-4-0",
  "material": "Aluminum conductors",
  "size": "4/0-4/0-4/0-2/0",
  "application": "Service entrance / feeder runs",
  "unit": "FT",
  "brands": [
   {
    "mfr": "Encore Wire",
    "part": "SER-4-0"
   },
   {
    "mfr": "Southwire",
    "part": "SOU-4-0"
   },
   {
    "mfr": "Cerrowire",
    "part": "CER-4-0"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-ser"
 },
 {
  "id": "cn1",
  "hidden": true,
  "cat": "cn",
  "sub": "EMT",
  "name": "EMT Conduit 3/4\" x 10'",
  "desc": "Galvanized steel conduit for electrical wiring installations.",
  "mfr": "Allied Tube & Conduit",
  "part": "EMT-075-10",
  "material": "Galvanized steel",
  "size": "3/4\" trade size",
  "application": "Exposed and concealed branch wiring raceway",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Allied Tube & Conduit",
    "part": "EMT-075-10"
   },
   {
    "mfr": "Wheatland Tube",
    "part": "WHE-075-10"
   },
   {
    "mfr": "Republic Conduit",
    "part": "REP-075-10"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "supersededBy": "cn-family-emt"
 },
 {
  "id": "cn2",
  "hidden": true,
  "cat": "cn",
  "sub": "EMT",
  "name": "EMT Conduit 1/2\" x 10'",
  "desc": "Galvanized steel conduit, smaller trade size.",
  "mfr": "Allied Tube & Conduit",
  "part": "EMT-050-10",
  "material": "Galvanized steel",
  "size": "1/2\" trade size",
  "application": "Lighting and small branch circuit runs",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Allied Tube & Conduit",
    "part": "EMT-050-10"
   },
   {
    "mfr": "Wheatland Tube",
    "part": "WHE-050-10"
   },
   {
    "mfr": "Republic Conduit",
    "part": "REP-050-10"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "supersededBy": "cn-family-emt"
 },
 {
  "id": "cn3",
  "hidden": true,
  "cat": "cn",
  "sub": "EMT",
  "name": "EMT Conduit 1\" x 10'",
  "desc": "Galvanized steel conduit, larger trade size.",
  "mfr": "Allied Tube & Conduit",
  "part": "EMT-100-10",
  "material": "Galvanized steel",
  "size": "1\" trade size",
  "application": "Feeder and multi-circuit raceway",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Allied Tube & Conduit",
    "part": "EMT-100-10"
   },
   {
    "mfr": "Wheatland Tube",
    "part": "WHE-100-10"
   },
   {
    "mfr": "Republic Conduit",
    "part": "REP-100-10"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "supersededBy": "cn-family-emt"
 },
 {
  "id": "cn4",
  "cat": "cn",
  "sub": "PVC",
  "name": "PVC Schedule 40 Conduit 3/4\" x 10'",
  "desc": "Rigid non-metallic conduit for wet or underground use.",
  "mfr": "Cantex",
  "part": "PVC40-075-10",
  "material": "PVC",
  "size": "3/4\" trade size",
  "application": "Underground and wet-location raceway",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Cantex",
    "part": "PVC40-075-10"
   },
   {
    "mfr": "Allied Tube & Conduit",
    "part": "ALL-075-10"
   },
   {
    "mfr": "Wheatland Tube",
    "part": "WHE-075-10"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-pvc40"
 },
 {
  "id": "cn5",
  "cat": "cn",
  "sub": "RMC",
  "name": "RMC Rigid Metal Conduit 1\" x 10'",
  "desc": "Heavy-wall threaded conduit for high-impact areas.",
  "mfr": "Allied Tube & Conduit",
  "part": "RMC-100-10",
  "material": "Galvanized steel",
  "size": "1\" trade size",
  "application": "Exposed runs subject to physical damage",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Allied Tube & Conduit",
    "part": "RMC-100-10"
   },
   {
    "mfr": "Wheatland Tube",
    "part": "WHE-100-10"
   },
   {
    "mfr": "Republic Conduit",
    "part": "REP-100-10"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-rmc"
 },
 {
  "id": "cn6",
  "cat": "cn",
  "sub": "Flexible",
  "name": "Flexible Conduit (Greenfield) 1/2\" x 25'",
  "desc": "Flexible metal conduit coil for equipment connections.",
  "mfr": "Southwire",
  "part": "FLEX-050-25",
  "material": "Galvanized steel",
  "size": "1/2\" trade size",
  "application": "Motor and equipment whips",
  "unit": "ROLL",
  "brands": [
   {
    "mfr": "Southwire",
    "part": "FLEX-050-25"
   },
   {
    "mfr": "Allied Tube & Conduit",
    "part": "ALL-050-25"
   },
   {
    "mfr": "Wheatland Tube",
    "part": "WHE-050-25"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-fmc"
 },
 {
  "id": "cn7",
  "cat": "cn",
  "sub": "Liquidtight",
  "name": "Liquidtight Flexible Conduit 3/4\" x 25'",
  "desc": "Liquidtight flexible conduit coil for wet locations.",
  "mfr": "Southwire",
  "part": "LFMC-075-25",
  "material": "Steel core, PVC jacket",
  "size": "3/4\" trade size",
  "application": "Wet-location equipment connections",
  "unit": "ROLL",
  "brands": [
   {
    "mfr": "Southwire",
    "part": "LFMC-075-25"
   },
   {
    "mfr": "Allied Tube & Conduit",
    "part": "ALL-075-25"
   },
   {
    "mfr": "Wheatland Tube",
    "part": "WHE-075-25"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-lfmc"
 },
 {
  "id": "cf1",
  "hidden": true,
  "cat": "cf",
  "sub": "Connectors",
  "name": "3/4\" EMT Connector",
  "desc": "Set-screw connector for terminating EMT.",
  "mfr": "Bridgeport",
  "part": "CON-SS-075",
  "material": "Steel, zinc plated",
  "size": "3/4\"",
  "application": "Connects EMT conduit to boxes/enclosures",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Bridgeport",
    "part": "CON-SS-075"
   },
   {
    "mfr": "Bridgeport Fittings",
    "part": "BRI-SS-075"
   },
   {
    "mfr": "Thomas & Betts",
    "part": "THO-SS-075"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "supersededBy": "pf-emt-connector"
 },
 {
  "id": "cf2",
  "cat": "cf",
  "sub": "Connectors",
  "name": "1/2\" EMT Connector (Compression)",
  "desc": "Compression connector, rain-tight rated.",
  "mfr": "Bridgeport",
  "part": "CON-CM-050",
  "material": "Steel, zinc plated",
  "size": "1/2\"",
  "application": "Rain-tight EMT terminations",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Bridgeport",
    "part": "CON-CM-050"
   },
   {
    "mfr": "Bridgeport Fittings",
    "part": "BRI-CM-050"
   },
   {
    "mfr": "Thomas & Betts",
    "part": "THO-CM-050"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-emt-comp-connector"
 },
 {
  "id": "cf3",
  "hidden": true,
  "cat": "cf",
  "sub": "Couplings",
  "name": "3/4\" EMT Coupling",
  "desc": "Set-screw coupling for joining EMT runs.",
  "mfr": "Bridgeport",
  "part": "CPL-SS-075",
  "material": "Steel, zinc plated",
  "size": "3/4\"",
  "application": "Joins two lengths of EMT conduit",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Bridgeport",
    "part": "CPL-SS-075"
   },
   {
    "mfr": "Bridgeport Fittings",
    "part": "BRI-SS-075"
   },
   {
    "mfr": "Thomas & Betts",
    "part": "THO-SS-075"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "supersededBy": "pf-emt-coupling"
 },
 {
  "id": "cf4",
  "cat": "cf",
  "sub": "Conduit Bodies",
  "name": "3/4\" LB Conduit Body",
  "desc": "Pull elbow fitting for direction changes.",
  "mfr": "Crouse-Hinds",
  "part": "LB-075",
  "material": "Cast aluminum",
  "size": "3/4\"",
  "application": "90-degree pulls and direction changes",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Crouse-Hinds",
    "part": "LB-075"
   },
   {
    "mfr": "Bridgeport Fittings",
    "part": "BRI-075"
   },
   {
    "mfr": "Thomas & Betts",
    "part": "THO-075"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-cb-lb"
 },
 {
  "id": "cf5",
  "cat": "cf",
  "sub": "Bushings",
  "name": "3/4\" Insulated Bushing",
  "desc": "Protects conductor insulation at conduit ends.",
  "mfr": "Bridgeport",
  "part": "BSH-INS-075",
  "material": "Steel with insulated throat",
  "size": "3/4\"",
  "application": "Conduit termination inside boxes",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Bridgeport",
    "part": "BSH-INS-075"
   },
   {
    "mfr": "Bridgeport Fittings",
    "part": "BRI-INS-075"
   },
   {
    "mfr": "Thomas & Betts",
    "part": "THO-INS-075"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-insulating-bushing"
 },
 {
  "id": "cf6",
  "cat": "cf",
  "sub": "Locknuts",
  "name": "3/4\" Locknut",
  "desc": "Secures conduit fittings to enclosures.",
  "mfr": "Bridgeport",
  "part": "LKN-075",
  "material": "Steel, zinc plated",
  "size": "3/4\"",
  "application": "Secures connectors to box knockouts",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Bridgeport",
    "part": "LKN-075"
   },
   {
    "mfr": "Bridgeport Fittings",
    "part": "BRI-075"
   },
   {
    "mfr": "Thomas & Betts",
    "part": "THO-075"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-locknut"
 },
 {
  "id": "cf7",
  "cat": "cf",
  "sub": "Adapters",
  "name": "3/4\" PVC Male Adapter",
  "desc": "Threaded adapter for PVC-to-threaded transitions.",
  "mfr": "Cantex",
  "part": "MA-PVC-075",
  "material": "PVC",
  "size": "3/4\"",
  "application": "PVC conduit to threaded hub transitions",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Cantex",
    "part": "MA-PVC-075"
   },
   {
    "mfr": "Bridgeport Fittings",
    "part": "BRI-PVC-075"
   },
   {
    "mfr": "Thomas & Betts",
    "part": "THO-PVC-075"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-pvc-male"
 },
 {
  "id": "bx1",
  "cat": "bx",
  "sub": "Square Boxes",
  "name": "4\" Square Box, 1-1/2\" Deep",
  "desc": "Standard steel outlet box.",
  "mfr": "Steel City",
  "part": "SB-4SQ-15",
  "material": "Galvanized steel",
  "size": "4\" x 1-1/2\"",
  "application": "Device and junction mounting",
  "unit": "EA",
  "aliases": [
   "1900",
   "1900 box",
   "four square",
   "4x4 box"
  ],
  "brands": [
   {
    "mfr": "Steel City",
    "part": "SB-4SQ-15"
   },
   {
    "mfr": "RACO",
    "part": "RAC-4SQ-15"
   },
   {
    "mfr": "Thepitt",
    "part": "THE-4SQ-15"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-box-4sq"
 },
 {
  "id": "bx2",
  "cat": "bx",
  "sub": "Covers",
  "name": "4\" Square Box Cover (Blank)",
  "desc": "Blank cover plate for 4\" square boxes.",
  "mfr": "Steel City",
  "part": "CVR-4SQ-BLK",
  "material": "Galvanized steel",
  "size": "4\"",
  "application": "Closes unused square box",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Steel City",
    "part": "CVR-4SQ-BLK"
   },
   {
    "mfr": "RACO",
    "part": "RAC-4SQ-BLK"
   },
   {
    "mfr": "Thepitt",
    "part": "THE-4SQ-BLK"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-box-cover"
 },
 {
  "id": "bx3",
  "cat": "bx",
  "sub": "Square Boxes",
  "name": "4-11/16\" Square Box, 2-1/8\" Deep",
  "desc": "Larger capacity steel box for multiple conductors.",
  "mfr": "Steel City",
  "part": "SB-411-21",
  "material": "Galvanized steel",
  "size": "4-11/16\" x 2-1/8\"",
  "application": "High fill / multi-circuit junctions",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Steel City",
    "part": "SB-411-21"
   },
   {
    "mfr": "RACO",
    "part": "RAC-411-21"
   },
   {
    "mfr": "Thepitt",
    "part": "THE-411-21"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-box-411"
 },
 {
  "id": "bx4",
  "cat": "bx",
  "sub": "Handy Boxes",
  "name": "Single Gang Handy Box",
  "desc": "Surface-mount box for switches and receptacles.",
  "mfr": "Steel City",
  "part": "HB-1G",
  "material": "Galvanized steel",
  "size": "Single gang",
  "application": "Surface device mounting",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Steel City",
    "part": "HB-1G"
   },
   {
    "mfr": "RACO",
    "part": "RAC-1G"
   },
   {
    "mfr": "Thepitt",
    "part": "THE-1G"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-handy-box"
 },
 {
  "id": "bx5",
  "cat": "bx",
  "sub": "Junction Boxes",
  "name": "Junction Box 6\"x6\"x4\"",
  "desc": "Screw-cover junction box for wire splicing.",
  "mfr": "Hoffman",
  "part": "JB-664",
  "material": "Galvanized steel",
  "size": "6\" x 6\" x 4\"",
  "application": "Wire splicing and pull points",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Hoffman",
    "part": "JB-664"
   },
   {
    "mfr": "Steel City",
    "part": "STE-664"
   },
   {
    "mfr": "RACO",
    "part": "RAC-664"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-jbox"
 },
 {
  "id": "bx6",
  "cat": "bx",
  "sub": "Weatherproof",
  "name": "Weatherproof Box, Single Gang",
  "desc": "Gasketed box with in-use cover for exterior devices.",
  "mfr": "Bell/Hubbell",
  "part": "WP-1G",
  "material": "Die-cast aluminum",
  "size": "Single gang",
  "application": "Exterior receptacle/switch mounting",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Bell/Hubbell",
    "part": "WP-1G"
   },
   {
    "mfr": "Steel City",
    "part": "STE-1G"
   },
   {
    "mfr": "RACO",
    "part": "RAC-1G"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-wp-box"
 },
 {
  "id": "sp1",
  "cat": "sp",
  "sub": "Channel",
  "name": "Unistrut Channel 10' (1-5/8\")",
  "desc": "Slotted steel channel for equipment support.",
  "mfr": "Unistrut",
  "part": "P1000-10",
  "material": "Galvanized steel",
  "size": "1-5/8\" x 1-5/8\"",
  "application": "Conduit and equipment racking",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Unistrut",
    "part": "P1000-10"
   },
   {
    "mfr": "Cooper B-Line",
    "part": "COO-10"
   },
   {
    "mfr": "Caddy",
    "part": "CAD-10"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-strut"
 },
 {
  "id": "sp2",
  "cat": "sp",
  "sub": "Channel",
  "name": "Kindorf Channel 10'",
  "desc": "Formed steel channel for conduit support.",
  "mfr": "Kindorf",
  "part": "B-905-10",
  "material": "Galvanized steel",
  "size": "1-5/8\" x 13/16\"",
  "application": "Conduit racking and trapeze supports",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Kindorf",
    "part": "B-905-10"
   },
   {
    "mfr": "Unistrut",
    "part": "UNI-905-10"
   },
   {
    "mfr": "Cooper B-Line",
    "part": "COO-905-10"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-strut"
 },
 {
  "id": "sp3",
  "cat": "sp",
  "sub": "Rod & Hardware",
  "name": "Threaded Rod 3/8\" x 10'",
  "desc": "All-thread rod for hanging supports.",
  "mfr": "Generic",
  "part": "ROD-375-10",
  "material": "Zinc-plated steel",
  "size": "3/8\"",
  "application": "Trapeze and hanger assemblies",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Generic",
    "part": "ROD-375-10"
   },
   {
    "mfr": "Unistrut",
    "part": "UNI-375-10"
   },
   {
    "mfr": "Cooper B-Line",
    "part": "COO-375-10"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-rod"
 },
 {
  "id": "sp4",
  "cat": "sp",
  "sub": "Clamps",
  "name": "Beam Clamp 3/8\"",
  "desc": "Clamps threaded rod to structural steel.",
  "mfr": "Caddy",
  "part": "BC-375",
  "material": "Steel",
  "size": "3/8\"",
  "application": "Structural steel rod attachment",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Caddy",
    "part": "BC-375"
   },
   {
    "mfr": "Unistrut",
    "part": "UNI-375"
   },
   {
    "mfr": "Cooper B-Line",
    "part": "COO-375"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-beam-clamp"
 },
 {
  "id": "sp5",
  "cat": "sp",
  "sub": "Straps",
  "name": "3/4\" EMT Strap (One-Hole)",
  "desc": "One-hole strap for securing EMT to structure.",
  "mfr": "Bridgeport",
  "part": "STRP-075",
  "material": "Steel, zinc plated",
  "size": "3/4\"",
  "application": "Conduit support to studs/structure",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Bridgeport",
    "part": "STRP-075"
   },
   {
    "mfr": "Unistrut",
    "part": "UNI-075"
   },
   {
    "mfr": "Cooper B-Line",
    "part": "COO-075"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-strap-1h"
 },
 {
  "id": "sp6",
  "cat": "sp",
  "sub": "Cable Support",
  "name": "J-Hook Cable Support 1-1/2\"",
  "desc": "Support hook for low-voltage and data cable runs.",
  "mfr": "Caddy",
  "part": "JH-150",
  "material": "Steel",
  "size": "1-1/2\"",
  "application": "Overhead cable tray alternative",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Caddy",
    "part": "JH-150"
   },
   {
    "mfr": "Unistrut",
    "part": "UNI-150"
   },
   {
    "mfr": "Cooper B-Line",
    "part": "COO-150"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-jhook"
 },
 {
  "id": "pd1",
  "cat": "pd",
  "sub": "Panelboards",
  "name": "200A Main Breaker Panel, 42-Circuit",
  "desc": "Load center for branch circuit distribution.",
  "mfr": "Square D",
  "part": "QO142M200",
  "material": "Steel enclosure",
  "size": "200A / 42-circuit",
  "voltage": "120/240V",
  "application": "Main electrical distribution panel",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Square D",
    "part": "QO142M200"
   },
   {
    "mfr": "Eaton",
    "part": "EAT-QO142M200"
   },
   {
    "mfr": "Siemens",
    "part": "SIE-QO142M200"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-load-center"
 },
 {
  "id": "pd2",
  "cat": "pd",
  "sub": "Breakers",
  "name": "20A Single-Pole Breaker",
  "desc": "Molded case circuit breaker for branch circuits.",
  "mfr": "Square D",
  "part": "QO120",
  "material": "Thermoplastic",
  "size": "20A / 1-pole",
  "amp": "20A",
  "application": "Standard branch circuit protection",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Square D",
    "part": "QO120"
   },
   {
    "mfr": "Eaton",
    "part": "EAT-QO120"
   },
   {
    "mfr": "Siemens",
    "part": "SIE-QO120"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-breaker"
 },
 {
  "id": "pd3",
  "cat": "pd",
  "sub": "Breakers",
  "name": "30A Two-Pole Breaker",
  "desc": "Two-pole breaker for 240V loads.",
  "mfr": "Square D",
  "part": "QO230",
  "material": "Thermoplastic",
  "size": "30A / 2-pole",
  "amp": "30A",
  "application": "Dryers, water heaters, small equipment",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Square D",
    "part": "QO230"
   },
   {
    "mfr": "Eaton",
    "part": "EAT-QO230"
   },
   {
    "mfr": "Siemens",
    "part": "SIE-QO230"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-breaker"
 },
 {
  "id": "pd4",
  "cat": "pd",
  "sub": "Disconnects",
  "name": "200A Non-Fused Disconnect",
  "desc": "Safety switch for equipment isolation.",
  "mfr": "Square D",
  "part": "H364N",
  "material": "NEMA 3R steel enclosure",
  "size": "200A",
  "amp": "200A",
  "application": "Equipment/service disconnect",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Square D",
    "part": "H364N"
   },
   {
    "mfr": "Eaton",
    "part": "EAT-H364N"
   },
   {
    "mfr": "Siemens",
    "part": "SIE-H364N"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-safety-switch"
 },
 {
  "id": "pd5",
  "cat": "pd",
  "sub": "Metering",
  "name": "CT-Rated Meter Socket, 200A",
  "desc": "Utility meter socket for service entrance.",
  "mfr": "Milbank",
  "part": "MS-200-CT",
  "material": "Aluminum",
  "size": "200A",
  "amp": "200A",
  "application": "Utility revenue metering",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Milbank",
    "part": "MS-200-CT"
   },
   {
    "mfr": "Square D",
    "part": "SQU-200-CT"
   },
   {
    "mfr": "Eaton",
    "part": "EAT-200-CT"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-ct-cabinet"
 },
 {
  "id": "pd6",
  "cat": "pd",
  "sub": "Fuses",
  "name": "Fuse, Class RK5, 30A",
  "desc": "Time-delay fuse for motor and general circuits.",
  "mfr": "Bussmann",
  "part": "FRN-R-30",
  "material": "—",
  "size": "30A",
  "amp": "30A",
  "application": "Overcurrent protection in fusible disconnects",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Bussmann",
    "part": "FRN-R-30"
   },
   {
    "mfr": "Square D",
    "part": "SQU-R-30"
   },
   {
    "mfr": "Eaton",
    "part": "EAT-R-30"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-fuse"
 },
 {
  "id": "wd1",
  "cat": "wd",
  "sub": "Receptacles",
  "name": "Duplex Receptacle, 20A, Commercial Grade",
  "desc": "Heavy-duty duplex outlet for commercial installs.",
  "mfr": "Leviton",
  "part": "5362-GY",
  "material": "Nylon face, steel strap",
  "size": "20A / 125V",
  "amp": "20A",
  "application": "General purpose outlets",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Leviton",
    "part": "5362-GY"
   },
   {
    "mfr": "Hubbell",
    "part": "HUB-GY"
   },
   {
    "mfr": "Pass & Seymour",
    "part": "PAS-GY"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-rcpt-duplex"
 },
 {
  "id": "wd2",
  "cat": "wd",
  "sub": "GFCI",
  "name": "GFCI Receptacle, 20A",
  "desc": "Ground-fault protected receptacle.",
  "mfr": "Leviton",
  "part": "GFNT2-W",
  "material": "Thermoplastic",
  "size": "20A / 125V",
  "amp": "20A",
  "application": "Wet/damp location and code-required GFCI outlets",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Leviton",
    "part": "GFNT2-W"
   },
   {
    "mfr": "Hubbell",
    "part": "HUB-W"
   },
   {
    "mfr": "Pass & Seymour",
    "part": "PAS-W"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-rcpt-gfci"
 },
 {
  "id": "wd3",
  "cat": "wd",
  "sub": "Switches",
  "name": "Single-Pole Switch, 20A, Commercial Grade",
  "desc": "Heavy-duty toggle switch.",
  "mfr": "Leviton",
  "part": "1221-2GY",
  "material": "Nylon, steel strap",
  "size": "20A / 120-277V",
  "amp": "20A",
  "application": "Lighting control, single location",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Leviton",
    "part": "1221-2GY"
   },
   {
    "mfr": "Hubbell",
    "part": "HUB-2GY"
   },
   {
    "mfr": "Pass & Seymour",
    "part": "PAS-2GY"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-switch"
 },
 {
  "id": "wd4",
  "cat": "wd",
  "sub": "Switches",
  "name": "3-Way Switch, 20A",
  "desc": "Toggle switch for multi-location lighting control.",
  "mfr": "Leviton",
  "part": "1203-2GY",
  "material": "Nylon, steel strap",
  "size": "20A / 120-277V",
  "amp": "20A",
  "application": "Lighting control from two locations",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Leviton",
    "part": "1203-2GY"
   },
   {
    "mfr": "Hubbell",
    "part": "HUB-2GY"
   },
   {
    "mfr": "Pass & Seymour",
    "part": "PAS-2GY"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-switch"
 },
 {
  "id": "wd5",
  "cat": "wd",
  "sub": "Receptacles",
  "name": "USB-C Charging Receptacle, 20A",
  "desc": "Combination outlet with integrated USB-C charging.",
  "mfr": "Leviton",
  "part": "T5748-W",
  "material": "Thermoplastic",
  "size": "20A / 125V",
  "amp": "20A",
  "application": "Workstations and conference rooms",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Leviton",
    "part": "T5748-W"
   },
   {
    "mfr": "Hubbell",
    "part": "HUB-W"
   },
   {
    "mfr": "Pass & Seymour",
    "part": "PAS-W"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-rcpt-usb"
 },
 {
  "id": "wd6",
  "cat": "wd",
  "sub": "Plates",
  "name": "Decora Wall Plate, Stainless Steel",
  "desc": "Single-gang device cover plate.",
  "mfr": "Leviton",
  "part": "84401-40",
  "material": "Stainless steel",
  "size": "Single gang",
  "application": "Finished device cover",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Leviton",
    "part": "84401-40"
   },
   {
    "mfr": "Hubbell",
    "part": "HUB-40"
   },
   {
    "mfr": "Pass & Seymour",
    "part": "PAS-40"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-wall-plate"
 },
 {
  "id": "lt1",
  "cat": "lt",
  "sub": "Troffers",
  "name": "2x4 LED Troffer, 4000K",
  "desc": "Recessed ceiling fixture for commercial spaces.",
  "mfr": "Lithonia",
  "part": "2BLT4-40L",
  "material": "Steel housing, acrylic lens",
  "size": "2' x 4'",
  "application": "Office and commercial ceiling lighting",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Lithonia",
    "part": "2BLT4-40L"
   },
   {
    "mfr": "Lithonia Lighting",
    "part": "LIT-40L"
   },
   {
    "mfr": "Cree Lighting",
    "part": "CRE-40L"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-troffer"
 },
 {
  "id": "lt2",
  "cat": "lt",
  "sub": "Strip Lights",
  "name": "4' LED Strip Light",
  "desc": "Surface or suspended utility strip fixture.",
  "mfr": "Lithonia",
  "part": "CSS-L48",
  "material": "Steel housing",
  "size": "4 ft",
  "application": "Warehouse and back-of-house lighting",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Lithonia",
    "part": "CSS-L48"
   },
   {
    "mfr": "Lithonia Lighting",
    "part": "LIT-L48"
   },
   {
    "mfr": "Cree Lighting",
    "part": "CRE-L48"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-linear"
 },
 {
  "id": "lt3",
  "cat": "lt",
  "sub": "Can Lights",
  "name": "6\" LED Can Light, Dimmable",
  "desc": "Recessed downlight, dimmable driver.",
  "mfr": "Halo",
  "part": "RL560",
  "material": "Aluminum trim",
  "size": "6\"",
  "application": "General ambient downlighting",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Halo",
    "part": "RL560"
   },
   {
    "mfr": "Lithonia Lighting",
    "part": "LIT-RL560"
   },
   {
    "mfr": "Cree Lighting",
    "part": "CRE-RL560"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-recessed"
 },
 {
  "id": "lt4",
  "cat": "lt",
  "sub": "Exit Signs",
  "name": "LED Exit Sign, Battery Backup",
  "desc": "Code-required egress signage with battery backup.",
  "mfr": "Lithonia",
  "part": "LQM-S-W",
  "material": "Thermoplastic",
  "size": "Standard",
  "voltage": "120/277V",
  "application": "Egress path identification",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Lithonia",
    "part": "LQM-S-W"
   },
   {
    "mfr": "Lithonia Lighting",
    "part": "LIT-S-W"
   },
   {
    "mfr": "Cree Lighting",
    "part": "CRE-S-W"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-emergency"
 },
 {
  "id": "lt5",
  "cat": "lt",
  "sub": "Wall Packs",
  "name": "LED Wall Pack, 40W, Exterior",
  "desc": "Exterior building-mounted area light.",
  "mfr": "RAB",
  "part": "WP40",
  "material": "Die-cast aluminum",
  "size": "40W",
  "voltage": "120-277V",
  "application": "Building perimeter and entrance lighting",
  "unit": "EA",
  "brands": [
   {
    "mfr": "RAB",
    "part": "WP40"
   },
   {
    "mfr": "Lithonia Lighting",
    "part": "LIT-WP40"
   },
   {
    "mfr": "Cree Lighting",
    "part": "CRE-WP40"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-wallpack"
 },
 {
  "id": "lt6",
  "cat": "lt",
  "sub": "Emergency",
  "name": "Emergency Egress Light Fixture",
  "desc": "Battery-backed dual-head emergency light.",
  "mfr": "Lithonia",
  "part": "ELM2",
  "material": "Thermoplastic",
  "size": "Standard",
  "voltage": "120/277V",
  "application": "Emergency egress illumination",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Lithonia",
    "part": "ELM2"
   },
   {
    "mfr": "Lithonia Lighting",
    "part": "LIT-ELM2"
   },
   {
    "mfr": "Cree Lighting",
    "part": "CRE-ELM2"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-emergency"
 },
 {
  "id": "lv1",
  "cat": "lv",
  "sub": "Data Cable",
  "name": "CAT6 Plenum Cable, 1000' Box",
  "desc": "Plenum-rated data cable for network runs.",
  "mfr": "CommScope",
  "part": "CAT6-PL-1K",
  "material": "Copper, plenum jacket",
  "size": "23 AWG, 4-pair",
  "application": "Structured data cabling, above ceiling",
  "unit": "BOX",
  "brands": [
   {
    "mfr": "CommScope",
    "part": "CAT6-PL-1K"
   },
   {
    "mfr": "Belden",
    "part": "BEL-PL-1K"
   },
   {
    "mfr": "Superior Essex",
    "part": "SUP-PL-1K"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-cat"
 },
 {
  "id": "lv2",
  "cat": "lv",
  "sub": "Coax",
  "name": "RG6 Coax Cable, 500' Spool",
  "desc": "Coaxial cable for video/CATV distribution.",
  "mfr": "Belden",
  "part": "RG6-500",
  "material": "Copper-clad steel core",
  "size": "RG6",
  "application": "Video and satellite distribution",
  "unit": "ROLL",
  "brands": [
   {
    "mfr": "Belden",
    "part": "RG6-500"
   },
   {
    "mfr": "CommScope",
    "part": "COM-500"
   },
   {
    "mfr": "Superior Essex",
    "part": "SUP-500"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-coax"
 },
 {
  "id": "lv3",
  "cat": "lv",
  "sub": "Fire Alarm",
  "name": "18/2 Fire Alarm Cable, Plenum",
  "desc": "Shielded cable for fire alarm circuits.",
  "mfr": "West Penn",
  "part": "FA-182-PL",
  "material": "Copper, plenum jacket",
  "size": "18 AWG, 2-conductor",
  "application": "Fire alarm initiating/notification circuits",
  "unit": "FT",
  "brands": [
   {
    "mfr": "West Penn",
    "part": "FA-182-PL"
   },
   {
    "mfr": "CommScope",
    "part": "COM-182-PL"
   },
   {
    "mfr": "Belden",
    "part": "BEL-182-PL"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-fa-cable"
 },
 {
  "id": "lv4",
  "cat": "lv",
  "sub": "Speaker Wire",
  "name": "Speaker Wire 16/2, 250' Spool",
  "desc": "Speaker wire for audio system runs.",
  "mfr": "Belden",
  "part": "SPK-162-250",
  "material": "Copper",
  "size": "16 AWG, 2-conductor",
  "application": "Overhead paging and A/V systems",
  "unit": "ROLL",
  "brands": [
   {
    "mfr": "Belden",
    "part": "SPK-162-250"
   },
   {
    "mfr": "CommScope",
    "part": "COM-162-250"
   },
   {
    "mfr": "Superior Essex",
    "part": "SUP-162-250"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-speaker"
 },
 {
  "id": "lv5",
  "cat": "lv",
  "sub": "Jacks & Connectors",
  "name": "CAT6 Keystone Jack, White",
  "desc": "Punch-down keystone jack for data outlets.",
  "mfr": "Leviton",
  "part": "61110-RW6",
  "material": "Thermoplastic",
  "size": "Keystone",
  "application": "Wall plate data terminations",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Leviton",
    "part": "61110-RW6"
   },
   {
    "mfr": "CommScope",
    "part": "COM-RW6"
   },
   {
    "mfr": "Belden",
    "part": "BEL-RW6"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-cat"
 },
 {
  "id": "lv6",
  "cat": "lv",
  "sub": "Mounting",
  "name": "Low Voltage Mounting Bracket",
  "desc": "Bracket for mounting low-voltage devices in drywall.",
  "mfr": "Arlington",
  "part": "LVU1",
  "material": "Plastic",
  "size": "Single gang",
  "application": "Drywall device mounting without stud",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Arlington",
    "part": "LVU1"
   },
   {
    "mfr": "CommScope",
    "part": "COM-LVU1"
   },
   {
    "mfr": "Belden",
    "part": "BEL-LVU1"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-lv-bracket"
 },
 {
  "id": "fa1",
  "cat": "fa",
  "sub": "Anchors",
  "name": "Tapcon Concrete Anchor 1/4\" x 2-1/4\"",
  "desc": "Self-tapping concrete screw anchor.",
  "mfr": "Tapcon",
  "part": "TAP-25-225",
  "material": "Steel, blue coating",
  "size": "1/4\" x 2-1/4\"",
  "application": "Fastening to concrete/masonry",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Tapcon",
    "part": "TAP-25-225"
   },
   {
    "mfr": "ITW Tapcon",
    "part": "ITW-25-225"
   },
   {
    "mfr": "Simpson Strong-Tie",
    "part": "SIM-25-225"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-concrete-screw"
 },
 {
  "id": "fa2",
  "cat": "fa",
  "sub": "Anchors",
  "name": "Toggle Bolt 1/4\"",
  "desc": "Spring-wing toggle anchor for hollow walls.",
  "mfr": "Generic",
  "part": "TOG-25",
  "material": "Zinc-plated steel",
  "size": "1/4\"",
  "application": "Hollow wall/ceiling fastening",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Generic",
    "part": "TOG-25"
   },
   {
    "mfr": "ITW Tapcon",
    "part": "ITW-25"
   },
   {
    "mfr": "Simpson Strong-Tie",
    "part": "SIM-25"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-hollow-anchor"
 },
 {
  "id": "fa3",
  "cat": "fa",
  "sub": "Screws",
  "name": "Self-Tapping Screw #10 x 1\"",
  "desc": "Sheet metal screw for enclosure assembly.",
  "mfr": "Generic",
  "part": "STS-10-1",
  "material": "Zinc-plated steel",
  "size": "#10 x 1\"",
  "application": "Metal-to-metal fastening",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Generic",
    "part": "STS-10-1"
   },
   {
    "mfr": "ITW Tapcon",
    "part": "ITW-10-1"
   },
   {
    "mfr": "Simpson Strong-Tie",
    "part": "SIM-10-1"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-metal-screw"
 },
 {
  "id": "fa4",
  "cat": "fa",
  "sub": "Cable Ties",
  "name": "Nylon Cable Tie 11\" (100-Pack)",
  "desc": "Standard nylon zip tie for cable bundling.",
  "mfr": "Panduit",
  "part": "PLT2S-C",
  "material": "Nylon 6.6",
  "size": "11\"",
  "application": "Cable and conduit bundling",
  "unit": "BOX",
  "brands": [
   {
    "mfr": "Panduit",
    "part": "PLT2S-C"
   },
   {
    "mfr": "ITW Tapcon",
    "part": "ITW-C"
   },
   {
    "mfr": "Simpson Strong-Tie",
    "part": "SIM-C"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-cable-tie"
 },
 {
  "id": "fa5",
  "cat": "fa",
  "sub": "Clamps",
  "name": "Cable Clamp, 1/2\"",
  "desc": "Two-hole clamp for securing cable to structure.",
  "mfr": "Generic",
  "part": "CC-050",
  "material": "Steel",
  "size": "1/2\"",
  "application": "Cable support and strain relief",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Generic",
    "part": "CC-050"
   },
   {
    "mfr": "ITW Tapcon",
    "part": "ITW-050"
   },
   {
    "mfr": "Simpson Strong-Tie",
    "part": "SIM-050"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-nm-connector"
 },
 {
  "id": "fa6",
  "cat": "fa",
  "sub": "Screws",
  "name": "Machine Screw 10-32 x 1\"",
  "desc": "Machine screw for panel and device assembly.",
  "mfr": "Generic",
  "part": "MS-1032-1",
  "material": "Zinc-plated steel",
  "size": "10-32 x 1\"",
  "application": "Panelboard and device hardware",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Generic",
    "part": "MS-1032-1"
   },
   {
    "mfr": "ITW Tapcon",
    "part": "ITW-1032-1"
   },
   {
    "mfr": "Simpson Strong-Tie",
    "part": "SIM-1032-1"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-machine-screw"
 },
 {
  "id": "ee1",
  "cat": "ee",
  "sub": "Transformers",
  "name": "Dry-Type Transformer, 15kVA",
  "desc": "Step-down transformer for distribution.",
  "mfr": "Square D",
  "part": "EE15S3H",
  "material": "Steel enclosure",
  "size": "15kVA",
  "voltage": "480V-208Y/120V",
  "application": "Voltage step-down for panel feed",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Square D",
    "part": "EE15S3H"
   },
   {
    "mfr": "Eaton",
    "part": "EAT-EE15S3H"
   },
   {
    "mfr": "ABB",
    "part": "ABB-EE15S3H"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-dry-transformer"
 },
 {
  "id": "ee2",
  "cat": "ee",
  "sub": "Motor Control",
  "name": "Motor Starter, 3-Pole, 30A",
  "desc": "Combination motor starter for equipment control.",
  "mfr": "Square D",
  "part": "MS-3P-30",
  "material": "Steel enclosure",
  "size": "30A, 3-pole",
  "amp": "30A",
  "application": "Motor overload and switching control",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Square D",
    "part": "MS-3P-30"
   },
   {
    "mfr": "Eaton",
    "part": "EAT-3P-30"
   },
   {
    "mfr": "ABB",
    "part": "ABB-3P-30"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-starter"
 },
 {
  "id": "ee3",
  "cat": "ee",
  "sub": "Motor Control",
  "name": "Definite Purpose Contactor, 40A",
  "desc": "Contactor for HVAC and equipment switching.",
  "mfr": "Square D",
  "part": "DPC-40",
  "material": "Thermoplastic",
  "size": "40A",
  "amp": "40A",
  "application": "HVAC and equipment load switching",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Square D",
    "part": "DPC-40"
   },
   {
    "mfr": "Eaton",
    "part": "EAT-40"
   },
   {
    "mfr": "ABB",
    "part": "ABB-40"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-contactor"
 },
 {
  "id": "ee4",
  "cat": "ee",
  "sub": "Protection",
  "name": "Surge Protective Device, Panel-Mounted",
  "desc": "Panel-mounted surge suppressor.",
  "mfr": "Square D",
  "part": "SDSA1175",
  "material": "Thermoplastic",
  "size": "120/240V",
  "voltage": "120/240V",
  "application": "Panelboard surge protection",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Square D",
    "part": "SDSA1175"
   },
   {
    "mfr": "Eaton",
    "part": "EAT-SDSA1175"
   },
   {
    "mfr": "ABB",
    "part": "ABB-SDSA1175"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-spd"
 },
 {
  "id": "ee5",
  "cat": "ee",
  "sub": "Controls",
  "name": "Time Clock / Timer Switch, 40A",
  "desc": "Mechanical time switch for lighting/equipment control.",
  "mfr": "Intermatic",
  "part": "T104M",
  "material": "Steel enclosure",
  "size": "40A",
  "amp": "40A",
  "application": "Scheduled lighting or equipment control",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Intermatic",
    "part": "T104M"
   },
   {
    "mfr": "Square D",
    "part": "SQU-T104M"
   },
   {
    "mfr": "Eaton",
    "part": "EAT-T104M"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-time-clock"
 },
 {
  "id": "ee6",
  "cat": "ee",
  "sub": "Controls",
  "name": "Photocell Sensor, 120-277V",
  "desc": "Dusk-to-dawn photocell for exterior lighting control.",
  "mfr": "Tork",
  "part": "2001",
  "material": "Thermoplastic",
  "size": "Standard",
  "voltage": "120-277V",
  "application": "Automatic exterior lighting control",
  "unit": "EA",
  "brands": [
   {
    "mfr": "Tork",
    "part": "2001"
   },
   {
    "mfr": "Square D",
    "part": "SQU-2001"
   },
   {
    "mfr": "Eaton",
    "part": "EAT-2001"
   },
   {
    "mfr": "Not Applicable",
    "part": null
   }
  ],
  "hidden": true,
  "supersededBy": "pf-photocell"
 }
];
export const BRAND_ALTS = {
 "wc": [
  "Southwire",
  "Encore Wire",
  "Cerrowire"
 ],
 "cn": [
  "Allied Tube & Conduit",
  "Wheatland Tube",
  "Republic Conduit"
 ],
 "cf": [
  "Bridgeport Fittings",
  "Thomas & Betts",
  "Arlington Industries"
 ],
 "bx": [
  "Steel City",
  "RACO",
  "Thepitt"
 ],
 "sp": [
  "Unistrut",
  "Cooper B-Line",
  "Caddy"
 ],
 "pd": [
  "Square D",
  "Eaton",
  "Siemens"
 ],
 "wd": [
  "Leviton",
  "Hubbell",
  "Pass & Seymour"
 ],
 "lt": [
  "Lithonia Lighting",
  "Cree Lighting",
  "Metalux"
 ],
 "lv": [
  "CommScope",
  "Belden",
  "Superior Essex"
 ],
 "fa": [
  "ITW Tapcon",
  "Simpson Strong-Tie",
  "Hillman"
 ],
 "ee": [
  "Square D",
  "Eaton",
  "ABB"
 ]
};
export const PROJECTS = [
 {
  "id": "proj1",
  "name": "7 Fairfield Rd",
  "address": "7 Fairfield Rd, Fairfield, NJ 07004",
  "number": "",
  "description": "",
  "status": "Active",
  "createdAt": 1779846454696,
  "createdBy": "f1",
  "companyId": "company1"
 },
 {
  "id": "proj2",
  "name": "12 Lincoln Ave",
  "address": "12 Lincoln Ave, Newark, NJ 07102",
  "number": "",
  "description": "",
  "status": "Active",
  "createdAt": 1782006454696,
  "createdBy": "f2",
  "companyId": "company1"
 },
 {
  "id": "proj3",
  "name": "25 Main St",
  "address": "25 Main St, Jersey City, NJ 07302",
  "number": "",
  "description": "",
  "status": "Completed",
  "createdAt": 1772070454696,
  "createdBy": "f3",
  "companyId": "company1"
 },
 {
  "id": "proj4",
  "name": "84 Oak Lane",
  "address": "84 Oak Lane, Hoboken, NJ 07030",
  "number": "",
  "description": "",
  "status": "Active",
  "createdAt": 1784166454696,
  "createdBy": "f4",
  "companyId": "company1"
 }
];
export const COMPANIES = [
 {
  "id": "company1",
  "name": "Ali Electric"
 }
];
export const FOREMEN = [
 {
  "id": "f1",
  "name": "Carlos Rodriguez",
  "email": "carlos.rodriguez@example.com",
  "phone": "(555) 555-0123",
  "pin": "4827",
  "companyRole": "Foreman",
  "baseRole": "foreman",
  "companyId": "company1",
  "currentProject": "7 Fairfield Rd",
  "mostUsed": [
   "cn1",
   "cf1",
   "bx1",
   "wc1",
   "cf3"
  ],
  "recentlyUsed": [
   "wc1",
   "wc2",
   "wc3",
   "cn1",
   "bx1",
   "cf1"
  ],
  "brandPrefs": {
   "wc1": 1,
   "cn1": 0
  }
 },
 {
  "id": "f2",
  "name": "Michael Thompson",
  "email": "michael.thompson@example.com",
  "phone": "(555) 555-0164",
  "pin": "1234",
  "companyRole": "Foreman",
  "baseRole": "foreman",
  "companyId": "company1",
  "currentProject": "12 Lincoln Ave",
  "mostUsed": [
   "wd1",
   "wd3",
   "bx4",
   "wc6"
  ],
  "recentlyUsed": [
   "wd1",
   "wd3",
   "bx4"
  ],
  "brandPrefs": {
   "wd1": 1
  }
 },
 {
  "id": "f3",
  "name": "David Wilson",
  "email": "david.wilson@example.com",
  "phone": "(555) 555-0189",
  "pin": "5566",
  "companyRole": "Foreman",
  "baseRole": "foreman",
  "companyId": "company1",
  "currentProject": "25 Main St",
  "mostUsed": [
   "lt1",
   "lt3",
   "pd2"
  ],
  "recentlyUsed": [
   "lt1",
   "lt3"
  ],
  "brandPrefs": {}
 },
 {
  "id": "f4",
  "name": "James Anderson",
  "email": "james.anderson@example.com",
  "phone": "(555) 555-0142",
  "pin": "9081",
  "companyRole": "Foreman",
  "baseRole": "foreman",
  "companyId": "company1",
  "currentProject": "84 Oak Lane",
  "mostUsed": [
   "cn4",
   "cf7",
   "lv1"
  ],
  "recentlyUsed": [
   "cn4",
   "lv1"
  ],
  "brandPrefs": {}
 },
 {
  "id": "j1",
  "name": "John Martinez",
  "email": "john.martinez@example.com",
  "phone": "(555) 555-0211",
  "pin": "2211",
  "companyRole": "Journeyman",
  "baseRole": "journeyman",
  "companyId": "company1",
  "currentProject": "7 Fairfield Rd",
  "mostUsed": [],
  "recentlyUsed": [],
  "brandPrefs": {}
 },
 {
  "id": "a1",
  "name": "Daniel Perez",
  "email": "daniel.perez@example.com",
  "phone": "(555) 555-0233",
  "pin": "3322",
  "companyRole": "Apprentice",
  "baseRole": "apprentice",
  "companyId": "company1",
  "currentProject": "7 Fairfield Rd",
  "mostUsed": [],
  "recentlyUsed": [],
  "brandPrefs": {}
 },
 {
  "id": "j2",
  "name": "Luis Hernandez",
  "email": "luis.hernandez@example.com",
  "phone": "(555) 555-0244",
  "pin": "4433",
  "companyRole": "Journeyman",
  "baseRole": "journeyman",
  "companyId": "company1",
  "currentProject": "7 Fairfield Rd",
  "mostUsed": [],
  "recentlyUsed": [],
  "brandPrefs": {}
 },
 {
  "id": "a2",
  "name": "Kevin Morales",
  "email": "kevin.morales@example.com",
  "phone": "(555) 555-0255",
  "pin": "5544",
  "companyRole": "Apprentice",
  "baseRole": "apprentice",
  "companyId": "company1",
  "currentProject": "12 Lincoln Ave",
  "mostUsed": [],
  "recentlyUsed": [],
  "brandPrefs": {}
 }
];
export const MANAGERS = [
 {
  "id": "m1",
  "name": "Ana Martinez",
  "email": "ana.martinez@example.com",
  "phone": "(555) 555-0100",
  "pin": "0000",
  "title": "Warehouse Manager",
  "baseRole": "warehouse_manager",
  "companyId": "company1"
 },
 {
  "id": "m2",
  "name": "Jennifer Lopez",
  "email": "jennifer.lopez@example.com",
  "phone": "(555) 555-0166",
  "pin": "6677",
  "title": "Warehouse Manager",
  "baseRole": "warehouse_manager",
  "companyId": "company1"
 },
 {
  "id": "m3",
  "name": "Michael Torres",
  "email": "michael.torres@example.com",
  "phone": "(555) 555-0188",
  "pin": "8899",
  "title": "Warehouse Worker",
  "baseRole": "warehouse_worker",
  "companyId": "company1"
 }
];
export const MEMBERSHIPS = [
 {
  "id": "mem-1001",
  "projectId": "proj1",
  "userId": "f1",
  "projectRole": "Foreman",
  "permissionLevel": "can_edit",
  "assignedAt": 1790214454696,
  "assignedBy": "f1",
  "active": true
 },
 {
  "id": "mem-1002",
  "projectId": "proj2",
  "userId": "f1",
  "projectRole": "Foreman",
  "permissionLevel": "can_edit",
  "assignedAt": 1790214454696,
  "assignedBy": "f1",
  "active": true
 },
 {
  "id": "mem-1003",
  "projectId": "proj2",
  "userId": "f2",
  "projectRole": "Foreman",
  "permissionLevel": "can_edit",
  "assignedAt": 1790214454696,
  "assignedBy": "f2",
  "active": true
 },
 {
  "id": "mem-1004",
  "projectId": "proj3",
  "userId": "f3",
  "projectRole": "Foreman",
  "permissionLevel": "can_edit",
  "assignedAt": 1790214454696,
  "assignedBy": "f3",
  "active": true
 },
 {
  "id": "mem-1005",
  "projectId": "proj4",
  "userId": "f4",
  "projectRole": "Foreman",
  "permissionLevel": "can_edit",
  "assignedAt": 1790214454696,
  "assignedBy": "f4",
  "active": true
 },
 {
  "id": "mem-1006",
  "projectId": "proj1",
  "userId": "j1",
  "projectRole": "Journeyman",
  "permissionLevel": "can_edit",
  "assignedAt": 1790214454696,
  "assignedBy": "f1",
  "active": true
 },
 {
  "id": "mem-1007",
  "projectId": "proj2",
  "userId": "j1",
  "projectRole": "Journeyman",
  "permissionLevel": "viewer",
  "assignedAt": 1790214454696,
  "assignedBy": "f1",
  "active": true
 },
 {
  "id": "mem-1008",
  "projectId": "proj1",
  "userId": "a1",
  "projectRole": "Apprentice",
  "permissionLevel": "viewer",
  "assignedAt": 1790214454696,
  "assignedBy": "f1",
  "active": true
 },
 {
  "id": "mem-1009",
  "projectId": "proj1",
  "userId": "j2",
  "projectRole": "Journeyman",
  "permissionLevel": "can_edit",
  "assignedAt": 1790214454696,
  "assignedBy": "f1",
  "active": true
 },
 {
  "id": "mem-1010",
  "projectId": "proj2",
  "userId": "a2",
  "projectRole": "Apprentice",
  "permissionLevel": "viewer",
  "assignedAt": 1790214454696,
  "assignedBy": "f2",
  "active": true
 }
];
export const INVENTORY = {
 "wc1": {
  "qty": 1988,
  "location": "Shelf A-1"
 },
 "wc2": {
  "qty": 1865,
  "location": "Shelf A-2"
 },
 "wc3": {
  "qty": 1398,
  "location": "Shelf B-1"
 },
 "wc4": {
  "qty": 1727,
  "location": "Shelf B-2"
 },
 "wc5": {
  "qty": 2873,
  "location": "Shelf B-3"
 },
 "wc6": {
  "qty": 2606,
  "location": "Shelf B-4"
 },
 "wc7": {
  "qty": 1932,
  "location": "Shelf C-1"
 },
 "cn1": {
  "qty": 234,
  "location": "Shelf C-2"
 },
 "cn2": {
  "qty": 143,
  "location": "Wire Rack 1"
 },
 "cn3": {
  "qty": 209,
  "location": "Wire Rack 2"
 },
 "cn4": {
  "qty": 206,
  "location": "Wire Rack 3"
 },
 "cn5": {
  "qty": 138,
  "location": "Conduit Rack 1"
 },
 "cn6": {
  "qty": 14,
  "location": "Conduit Rack 2"
 },
 "cn7": {
  "qty": 8,
  "location": "Bin D-1"
 },
 "cf1": {
  "qty": 131,
  "location": "Bin D-2"
 },
 "cf2": {
  "qty": 180,
  "location": "Shelf A-1"
 },
 "cf3": {
  "qty": 147,
  "location": "Shelf A-2"
 },
 "cf4": {
  "qty": 114,
  "location": "Shelf B-1"
 },
 "cf5": {
  "qty": 186,
  "location": "Shelf B-2"
 },
 "cf6": {
  "qty": 151,
  "location": "Shelf B-3"
 },
 "cf7": {
  "qty": 5,
  "location": "Shelf B-4"
 },
 "bx1": {
  "qty": 94,
  "location": "Shelf C-1"
 },
 "bx2": {
  "qty": 184,
  "location": "Shelf C-2"
 },
 "bx3": {
  "qty": 205,
  "location": "Wire Rack 1"
 },
 "bx4": {
  "qty": 153,
  "location": "Wire Rack 2"
 },
 "bx5": {
  "qty": 5,
  "location": "Wire Rack 3"
 },
 "bx6": {
  "qty": 179,
  "location": "Conduit Rack 1"
 },
 "sp1": {
  "qty": 174,
  "location": "Conduit Rack 2"
 },
 "sp2": {
  "qty": 5,
  "location": "Bin D-1"
 },
 "sp3": {
  "qty": 226,
  "location": "Bin D-2"
 },
 "sp4": {
  "qty": 139,
  "location": "Shelf A-1"
 },
 "sp5": {
  "qty": 129,
  "location": "Shelf A-2"
 },
 "sp6": {
  "qty": 221,
  "location": "Shelf B-1"
 },
 "pd1": {
  "qty": 96,
  "location": "Shelf B-2"
 },
 "pd2": {
  "qty": 210,
  "location": "Shelf B-3"
 },
 "pd3": {
  "qty": 223,
  "location": "Shelf B-4"
 },
 "pd4": {
  "qty": 169,
  "location": "Shelf C-1"
 },
 "pd5": {
  "qty": 130,
  "location": "Shelf C-2"
 },
 "pd6": {
  "qty": 2,
  "location": "Wire Rack 1"
 },
 "wd1": {
  "qty": 116,
  "location": "Wire Rack 2"
 },
 "wd2": {
  "qty": 94,
  "location": "Wire Rack 3"
 },
 "wd3": {
  "qty": 91,
  "location": "Conduit Rack 1"
 },
 "wd4": {
  "qty": 210,
  "location": "Conduit Rack 2"
 },
 "wd5": {
  "qty": 100,
  "location": "Bin D-1"
 },
 "wd6": {
  "qty": 91,
  "location": "Bin D-2"
 },
 "lt1": {
  "qty": 137,
  "location": "Shelf A-1"
 },
 "lt2": {
  "qty": 96,
  "location": "Shelf A-2"
 },
 "lt3": {
  "qty": 94,
  "location": "Shelf B-1"
 },
 "lt4": {
  "qty": 100,
  "location": "Shelf B-2"
 },
 "lt5": {
  "qty": 2,
  "location": "Shelf B-3"
 },
 "lt6": {
  "qty": 192,
  "location": "Shelf B-4"
 },
 "lv1": {
  "qty": 13,
  "location": "Shelf C-1"
 },
 "lv2": {
  "qty": 0,
  "location": "Shelf C-2"
 },
 "lv3": {
  "qty": 3100,
  "location": "Wire Rack 1"
 },
 "lv4": {
  "qty": 23,
  "location": "Wire Rack 2"
 },
 "lv5": {
  "qty": 150,
  "location": "Wire Rack 3"
 },
 "lv6": {
  "qty": 141,
  "location": "Conduit Rack 1"
 },
 "fa1": {
  "qty": 235,
  "location": "Conduit Rack 2"
 },
 "fa2": {
  "qty": 87,
  "location": "Bin D-1"
 },
 "fa3": {
  "qty": 3,
  "location": "Bin D-2"
 },
 "fa4": {
  "qty": 24,
  "location": "Shelf A-1"
 },
 "fa5": {
  "qty": 90,
  "location": "Shelf A-2"
 },
 "fa6": {
  "qty": 228,
  "location": "Shelf B-1"
 },
 "ee1": {
  "qty": 132,
  "location": "Shelf B-2"
 },
 "ee2": {
  "qty": 113,
  "location": "Shelf B-3"
 },
 "ee3": {
  "qty": 183,
  "location": "Shelf B-4"
 },
 "ee4": {
  "qty": 204,
  "location": "Shelf C-1"
 },
 "ee5": {
  "qty": 5,
  "location": "Shelf C-2"
 },
 "ee6": {
  "qty": 162,
  "location": "Wire Rack 1"
 }
};
export const SUPPLIERS = [
 {
  "id": "sup1",
  "name": "Metro Electrical Supply",
  "address": "118 Industrial Pkwy",
  "phone": "(555) 201-3344",
  "distance": 2.4
 },
 {
  "id": "sup2",
  "name": "Fairview Electric Wholesale",
  "address": "950 Commerce Dr",
  "phone": "(555) 488-7712",
  "distance": 4.1
 },
 {
  "id": "sup3",
  "name": "Union Electrical Distributors",
  "address": "22 Depot St",
  "phone": "(555) 776-2201",
  "distance": 6.8
 }
];
export const JOB_KITS = [
 {
  "id": "kit-panel",
  "name": "Panel Installation",
  "type": "Company",
  "createdBy": "company",
  "description": "Standard materials for a typical panel install and feed.",
  "dateCreated": 1782438454696,
  "dateUpdated": 1787622454696,
  "timesUsed": 14,
  "materials": [
   {
    "productId": "wc1",
    "qty": 500,
    "unit": "FT"
   },
   {
    "productId": "wc2",
    "qty": 500,
    "unit": "FT"
   },
   {
    "productId": "wc3",
    "qty": 500,
    "unit": "FT"
   },
   {
    "productId": "cf1",
    "qty": 50,
    "unit": "EA"
   },
   {
    "productId": "cf3",
    "qty": 50,
    "unit": "EA"
   },
   {
    "productId": "bx1",
    "qty": 25,
    "unit": "EA"
   },
   {
    "productId": "bx2",
    "qty": 25,
    "unit": "EA"
   },
   {
    "productId": "sp5",
    "qty": 20,
    "unit": "EA"
   },
   {
    "productId": "cf4",
    "qty": 10,
    "unit": "EA"
   }
  ]
 },
 {
  "id": "kit-emt-roughin",
  "name": "EMT Rough-In",
  "type": "Company",
  "createdBy": "company",
  "description": "Conduit, fittings and wire for a standard commercial EMT rough-in run.",
  "dateCreated": 1782438454697,
  "dateUpdated": 1788486454697,
  "timesUsed": 22,
  "materials": [
   {
    "productId": "cn1",
    "qty": 20,
    "unit": "EA"
   },
   {
    "productId": "cn2",
    "qty": 10,
    "unit": "EA"
   },
   {
    "productId": "cf1",
    "qty": 30,
    "unit": "EA"
   },
   {
    "productId": "cf3",
    "qty": 20,
    "unit": "EA"
   },
   {
    "productId": "cf5",
    "qty": 20,
    "unit": "EA"
   },
   {
    "productId": "cf6",
    "qty": 20,
    "unit": "EA"
   },
   {
    "productId": "sp5",
    "qty": 30,
    "unit": "EA"
   },
   {
    "productId": "sp1",
    "qty": 2,
    "unit": "EA"
   },
   {
    "productId": "fa1",
    "qty": 20,
    "unit": "EA"
   },
   {
    "productId": "wc1",
    "qty": 300,
    "unit": "FT"
   },
   {
    "productId": "wc2",
    "qty": 300,
    "unit": "FT"
   },
   {
    "productId": "wc3",
    "qty": 300,
    "unit": "FT"
   }
  ]
 },
 {
  "id": "kit-lighting",
  "name": "Lighting Installation",
  "type": "Company",
  "createdBy": "company",
  "description": "Fixtures and branch wiring for a standard lighting install.",
  "dateCreated": 1782438454697,
  "dateUpdated": 1786326454697,
  "timesUsed": 9,
  "materials": [
   {
    "productId": "lt1",
    "qty": 10,
    "unit": "EA"
   },
   {
    "productId": "lt2",
    "qty": 6,
    "unit": "EA"
   },
   {
    "productId": "lt3",
    "qty": 8,
    "unit": "EA"
   },
   {
    "productId": "pd2",
    "qty": 4,
    "unit": "EA"
   },
   {
    "productId": "wc1",
    "qty": 200,
    "unit": "FT"
   },
   {
    "productId": "wc2",
    "qty": 200,
    "unit": "FT"
   },
   {
    "productId": "wc3",
    "qty": 200,
    "unit": "FT"
   },
   {
    "productId": "sp6",
    "qty": 10,
    "unit": "EA"
   }
  ]
 },
 {
  "id": "kit-device",
  "name": "Device Installation",
  "type": "Company",
  "createdBy": "company",
  "description": "Receptacles, switches and boxes for a device rough-in/trim package.",
  "dateCreated": 1782438454697,
  "dateUpdated": 1788918454697,
  "timesUsed": 17,
  "materials": [
   {
    "productId": "wd1",
    "qty": 20,
    "unit": "EA"
   },
   {
    "productId": "wd2",
    "qty": 6,
    "unit": "EA"
   },
   {
    "productId": "wd3",
    "qty": 15,
    "unit": "EA"
   },
   {
    "productId": "wd4",
    "qty": 5,
    "unit": "EA"
   },
   {
    "productId": "wd5",
    "qty": 4,
    "unit": "EA"
   },
   {
    "productId": "wd6",
    "qty": 20,
    "unit": "EA"
   },
   {
    "productId": "bx1",
    "qty": 20,
    "unit": "EA"
   },
   {
    "productId": "bx4",
    "qty": 15,
    "unit": "EA"
   },
   {
    "productId": "cf1",
    "qty": 20,
    "unit": "EA"
   },
   {
    "productId": "cf3",
    "qty": 20,
    "unit": "EA"
   }
  ]
 },
 {
  "id": "kit-temp-power",
  "name": "Temporary Power",
  "type": "Company",
  "createdBy": "company",
  "description": "Basic materials for a temporary construction power setup.",
  "dateCreated": 1782438454697,
  "dateUpdated": 1785030454697,
  "timesUsed": 5,
  "materials": [
   {
    "productId": "pd4",
    "qty": 1,
    "unit": "EA"
   },
   {
    "productId": "pd5",
    "qty": 1,
    "unit": "EA"
   },
   {
    "productId": "wc7",
    "qty": 150,
    "unit": "FT"
   },
   {
    "productId": "cn5",
    "qty": 4,
    "unit": "EA"
   },
   {
    "productId": "sp3",
    "qty": 4,
    "unit": "EA"
   },
   {
    "productId": "sp4",
    "qty": 4,
    "unit": "EA"
   },
   {
    "productId": "ee4",
    "qty": 1,
    "unit": "EA"
   },
   {
    "productId": "fa1",
    "qty": 10,
    "unit": "EA"
   }
  ]
 },
 {
  "id": "kit-service",
  "name": "Service Installation",
  "type": "Company",
  "createdBy": "company",
  "description": "Core materials for a new electrical service installation.",
  "dateCreated": 1782438454697,
  "dateUpdated": 1785894454697,
  "timesUsed": 6,
  "materials": [
   {
    "productId": "pd1",
    "qty": 1,
    "unit": "EA"
   },
   {
    "productId": "pd4",
    "qty": 1,
    "unit": "EA"
   },
   {
    "productId": "pd5",
    "qty": 1,
    "unit": "EA"
   },
   {
    "productId": "wc7",
    "qty": 100,
    "unit": "FT"
   },
   {
    "productId": "cn5",
    "qty": 6,
    "unit": "EA"
   },
   {
    "productId": "cf6",
    "qty": 10,
    "unit": "EA"
   },
   {
    "productId": "sp4",
    "qty": 6,
    "unit": "EA"
   }
  ]
 }
];
export const ORDERS = [
 {
  "id": "ORD-1001",
  "foremanId": "f1",
  "foremanName": "Carlos Rodriguez",
  "phone": "(555) 555-0123",
  "project": "7 Fairfield Rd",
  "priority": "High",
  "neededBy": 1790233200000,
  "notes": "Need these materials before 7:00 AM tomorrow because we are starting the panel installation.",
  "status": "Pending",
  "createdAt": 1790203654697,
  "packedAt": null,
  "shippedAt": null,
  "completedAt": null,
  "items": [
   {
    "productId": "cn1",
    "qty": 50,
    "collected": false
   },
   {
    "productId": "cf1",
    "qty": 50,
    "collected": false
   },
   {
    "productId": "bx1",
    "qty": 25,
    "collected": false
   },
   {
    "productId": "bx2",
    "qty": 25,
    "collected": false
   },
   {
    "productId": "wc1",
    "qty": 500,
    "collected": false
   },
   {
    "productId": "wc2",
    "qty": 500,
    "collected": false
   },
   {
    "productId": "wc3",
    "qty": 500,
    "collected": false
   },
   {
    "productId": "sp5",
    "qty": 20,
    "collected": false
   },
   {
    "productId": "cf4",
    "qty": 10,
    "collected": false
   }
  ]
 },
 {
  "id": "ORD-1002",
  "foremanId": "f2",
  "foremanName": "Michael Thompson",
  "phone": "(555) 555-0164",
  "project": "12 Lincoln Ave",
  "priority": "Normal",
  "neededBy": 1790413200000,
  "notes": "",
  "status": "Packed",
  "createdAt": 1790178454697,
  "packedAt": 1790207254697,
  "shippedAt": null,
  "completedAt": null,
  "items": [
   {
    "productId": "wd1",
    "qty": 20,
    "collected": true
   },
   {
    "productId": "wd3",
    "qty": 10,
    "collected": true
   },
   {
    "productId": "bx4",
    "qty": 15,
    "collected": true
   },
   {
    "productId": "wc6",
    "qty": 300,
    "collected": true
   },
   {
    "productId": "wd6",
    "qty": 20,
    "collected": true
   }
  ]
 },
 {
  "id": "ORD-1003",
  "foremanId": "f3",
  "foremanName": "David Wilson",
  "phone": "(555) 555-0189",
  "project": "25 Main St",
  "priority": "Normal",
  "neededBy": 1790323200000,
  "notes": "Second floor lighting retrofit.",
  "status": "In Progress",
  "createdAt": 1790128054697,
  "packedAt": null,
  "shippedAt": null,
  "completedAt": null,
  "items": [
   {
    "productId": "lt1",
    "qty": 18,
    "collected": true
   },
   {
    "productId": "lt3",
    "qty": 12,
    "collected": false
   },
   {
    "productId": "pd2",
    "qty": 4,
    "collected": false
   },
   {
    "productId": "sp1",
    "qty": 6,
    "collected": false
   }
  ]
 }
];
export const ACTIVITY = [];
export const ORDER_SEQ = 1003;
export const PROJECT_SEQ = 100;
export const KIT_SEQ = 100;
export const ID_SEQ = 1010;
