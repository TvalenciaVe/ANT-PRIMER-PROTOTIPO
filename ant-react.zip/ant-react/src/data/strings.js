// EN/ES interface text. Product names, brands, part numbers, project names and notes are never translated.
export const STRINGS = {
 "home": {
  "en": "Home",
  "es": "Inicio"
 },
 "good_morning": {
  "en": "Good morning",
  "es": "Buenos días"
 },
 "good_afternoon": {
  "en": "Good afternoon",
  "es": "Buenas tardes"
 },
 "good_evening": {
  "en": "Good evening",
  "es": "Buenas noches"
 },
 "projects": {
  "en": "Projects",
  "es": "Proyectos"
 },
 "orders": {
  "en": "Orders",
  "es": "Órdenes"
 },
 "profile": {
  "en": "Profile",
  "es": "Perfil"
 },
 "inventory": {
  "en": "Inventory",
  "es": "Inventario"
 },
 "packing": {
  "en": "Packing",
  "es": "Empaque"
 },
 "search_materials": {
  "en": "Search materials, size or part #",
  "es": "Buscar material, tamaño o número de parte"
 },
 "change": {
  "en": "Change",
  "es": "Cambiar"
 },
 "see_all": {
  "en": "See all",
  "es": "Ver todos"
 },
 "added": {
  "en": "Added",
  "es": "Agregado"
 },
 "add": {
  "en": "Add",
  "es": "Agregar"
 },
 "what_materials": {
  "en": "What materials do you need?",
  "es": "¿Qué materiales necesitas?"
 },
 "request_materials": {
  "en": "Request materials",
  "es": "Solicitar materiales"
 },
 "current_project": {
  "en": "Current project",
  "es": "Proyecto actual"
 },
 "change_project": {
  "en": "Change project",
  "es": "Cambiar proyecto"
 },
 "start_packing": {
  "en": "Start packing",
  "es": "Empezar a empacar"
 },
 "view_full_list": {
  "en": "View full list",
  "es": "Ver lista completa"
 },
 "skip_for_now": {
  "en": "Skip for now",
  "es": "Saltar por ahora"
 },
 "mark_short": {
  "en": "Mark short",
  "es": "Marcar faltante"
 },
 "pack": {
  "en": "Pack",
  "es": "Empacar"
 },
 "need": {
  "en": "Need",
  "es": "Necesita"
 },
 "available": {
  "en": "Available",
  "es": "Disponible"
 },
 "location": {
  "en": "Location",
  "es": "Ubicación"
 },
 "packing_complete": {
  "en": "Packing complete",
  "es": "Empaque completo"
 },
 "done": {
  "en": "Done",
  "es": "Listo"
 },
 "view_only": {
  "en": "View Only",
  "es": "Solo ver"
 },
 "can_request_materials": {
  "en": "Can Request Materials",
  "es": "Puede solicitar materiales"
 },
 "requested": {
  "en": "Requested",
  "es": "Solicitado"
 },
 "packing_stage": {
  "en": "Packing",
  "es": "Empacando"
 },
 "ready_to_ship": {
  "en": "Ready to Ship",
  "es": "Listo para enviar"
 },
 "on_the_way": {
  "en": "On the Way",
  "es": "En camino"
 },
 "delivered": {
  "en": "Delivered",
  "es": "Entregado"
 },
 "warehouse_inventory": {
  "en": "Warehouse Inventory",
  "es": "Inventario del almacén"
 },
 "did_everything_arrive": {
  "en": "Did everything arrive?",
  "es": "¿Llegó todo?"
 },
 "yes_everything_arrived": {
  "en": "Yes, everything arrived",
  "es": "Sí, todo llegó"
 },
 "something_missing": {
  "en": "Something is missing",
  "es": "Falta algo"
 },
 "submit": {
  "en": "Submit",
  "es": "Enviar"
 },
 "categories": {
  "en": "Categories",
  "es": "Categorías"
 },
 "job_kits": {
  "en": "Job Kits",
  "es": "Kits de trabajo"
 },
 "recently_used": {
  "en": "Recently used",
  "es": "Usados recientemente"
 },
 "most_used_by_you": {
  "en": "Most used by you",
  "es": "Más usados por ti"
 },
 "add_to_material_request": {
  "en": "Add to material request",
  "es": "Agregar a la solicitud"
 },
 "continue_label": {
  "en": "Continue",
  "es": "Continuar"
 },
 "cancel": {
  "en": "Cancel",
  "es": "Cancelar"
 },
 "language": {
  "en": "Language",
  "es": "Idioma"
 },
 "text_size": {
  "en": "Text size",
  "es": "Tamaño de texto"
 },
 "standard": {
  "en": "Standard",
  "es": "Estándar"
 },
 "large": {
  "en": "Large",
  "es": "Grande"
 },
 "preferences": {
  "en": "Preferences",
  "es": "Preferencias"
 },
 "view_only_access_project": {
  "en": "You have view-only access on",
  "es": "Tienes acceso de solo lectura en"
 },
 "view_only_access_requests": {
  "en": "You have view-only access to material requests on this project.",
  "es": "Tienes acceso de solo lectura a las solicitudes de materiales en este proyecto."
 },
 "no_permission_submit": {
  "en": "You don't have permission to submit material requests for this project.",
  "es": "No tienes permiso para enviar solicitudes de materiales en este proyecto."
 },
 "err_name_required": {
  "en": "Enter your name to continue.",
  "es": "Ingresa tu nombre para continuar."
 },
 "err_email_invalid": {
  "en": "Enter a valid email address, like name@company.com.",
  "es": "Ingresa un correo válido, como nombre@empresa.com."
 },
 "err_phone_invalid": {
  "en": "Enter a valid 10-digit phone number.",
  "es": "Ingresa un número de teléfono válido de 10 dígitos."
 },
 "err_pin_invalid": {
  "en": "PIN must be exactly 4 digits.",
  "es": "El PIN debe tener exactamente 4 dígitos."
 },
 "err_company_required": {
  "en": "Enter your company name to continue.",
  "es": "Ingresa el nombre de tu empresa para continuar."
 },
 "err_email_taken": {
  "en": "An account with this email already exists. Try logging in instead.",
  "es": "Ya existe una cuenta con este correo. Intenta iniciar sesión."
 },
 "err_phone_taken": {
  "en": "An account with this phone number already exists. Try logging in instead.",
  "es": "Ya existe una cuenta con este número. Intenta iniciar sesión."
 },
 "err_cart_empty": {
  "en": "Add at least one material to continue.",
  "es": "Agrega al menos un material para continuar."
 },
 "err_needed_date": {
  "en": "Choose when these materials are needed.",
  "es": "Elige cuándo se necesitan estos materiales."
 },
 "err_priority": {
  "en": "Choose a priority to continue.",
  "es": "Elige una prioridad para continuar."
 },
 "err_no_project": {
  "en": "Select a project before submitting a request.",
  "es": "Selecciona un proyecto antes de enviar una solicitud."
 }
};
