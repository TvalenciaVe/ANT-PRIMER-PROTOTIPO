import { createRoot } from 'react-dom/client';
import './styles.css';
import App from './App.jsx';
import { loadAppData } from './lib/db.js';

loadAppData();  // restore saved data, or seed the demo data on first run
createRoot(document.getElementById('root')).render(<App />);
