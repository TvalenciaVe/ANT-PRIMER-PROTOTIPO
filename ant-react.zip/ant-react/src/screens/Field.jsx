import { ui } from '../lib/store.js';
import { db } from '../lib/db.js';
import { t, greeting } from '../lib/i18n.js';
import { canRequestNow, projectByName, myProjects, currentProjectContextLine } from '../lib/permissions.js';
import {
  getProduct, brandOf, searchProducts, familiesByCategory, areaByKey, groupByKey,
  CATALOG_GROUPS, PRODUCTS, LEGACY_CAT_TO_AREA,
} from '../lib/catalog.js';
import { cartCount } from '../lib/cart.js';
import {
  Icon, ProductImage, ProductCardWithAdd, ProductCard, CatalogCard, FieldNav, CartFab, Header, Empty, QtyStepper,
} from '../components/common.jsx';
import * as A from '../lib/actions.js';
import * as F from '../lib/actionsField.js';
import * as P from '../lib/actionsProjects.js';

const companyKits = () => db.JOB_KITS.filter((k) => k.type === 'Company');
const myKits = () => (ui.currentUser ? db.JOB_KITS.filter((k) => k.type === 'Personal' && k.createdBy === ui.currentUser.id) : []);

function Rail({ title, action, children }) {
  return (
    <div className="rail">
      <div className="rail-head"><div className="h2">{title}</div>{action}</div>
      <div className="rail-scroll">{children}</div>
    </div>
  );
}
export function ProductRail({ title, ids }) {
  const items = (ids || []).map(getProduct).filter(Boolean);
  if (!items.length) return null;
  return <Rail title={title}>{items.map((p) => <ProductCardWithAdd key={p.id} p={p} />)}</Rail>;
}
function KitRail() {
  const kits = companyKits().concat(myKits()).slice(0, 10);
  if (!kits.length) return null;
  return (
    <Rail title={t('job_kits')} action={<button className="btn-ghost" onClick={() => A.goto('fJobKits')}>{t('see_all')}</button>}>
      {kits.map((k) => (
        <button key={k.id} className="prodcard" onClick={() => F.openKit(k.id)}>
          <div className="thumb"><Icon name="box" /></div>
          <div className="pbody"><div className="pname">{k.name}</div><div className="pdesc">{k.materials.length} material{k.materials.length === 1 ? '' : 's'}</div></div>
        </button>
      ))}
    </Rail>
  );
}
const groupCount = (g) => { const seen = {}; g.areas.forEach((a) => familiesByCategory(a).forEach((f) => { seen[f.id] = 1; })); return Object.keys(seen).length; };
function CategoryList() {
  return (
    <div className="rail">
      <div className="rail-head"><div className="h2">{t('categories')}</div></div>
      <div className="section-pad" style={{ paddingTop: 0, paddingBottom: 0 }}>
        {CATALOG_GROUPS.map((g) => {
          const n = groupCount(g);
          return (
            <button key={g.key} className="cat-row" onClick={() => A.openCategory(g.key)}>
              <span className="cat-row-label">{g.label}</span>
              <span className="cat-row-meta">{n} product{n === 1 ? '' : 's'}</span>
              <Icon name="chev" />
            </button>
          );
        })}
      </div>
    </div>
  );
}
function SearchResults() {
  const results = searchProducts(ui.searchQuery);
  return (
    <>
      <div className="section-pad"><div className="h2">{results.length} result{results.length === 1 ? '' : 's'} for "{ui.searchQuery}"</div></div>
      <div className="gridlist" style={{ marginTop: 12 }}>
        {results.slice(0, 40).map((item) => <CatalogCard key={item.id} item={item} />)}
      </div>
      {results.length > 40 ? <div className="tiny muted" style={{ textAlign: 'center', padding: '10px 20px' }}>Showing the 40 best matches. Add a size or type to narrow it down.</div> : null}
      {results.length === 0 ? <Empty icon="search" title="No materials found"><div>Try another name, size, or part number.</div></Empty> : null}
      <div style={{ height: 12 }} />
    </>
  );
}

export function FieldHome() {
  const u = ui.currentUser;
  const firstName = u.name.split(' ')[0];
  const title = <div><div className="brand-tag">ANT</div><div className="h1" style={{ marginBottom: 0 }}>{greeting()}, {firstName}</div></div>;
  if (myProjects(u).length === 0) {
    const isForeman = u.companyRole === 'Foreman';
    return (
      <>
        <div className="app-header">{title}</div>
        <div className="content no-nav">
          <Empty icon="projects" title={isForeman ? 'No projects yet' : 'No projects assigned yet'}>
            {isForeman
              ? <><div>Add your first project to start requesting materials.</div><button className="btn btn-primary" onClick={() => A.goto('fAddProject')}>Add project</button></>
              : <div>Once your Foreman adds you to a project, it will appear here.</div>}
          </Empty>
        </div>
        <FieldNav active="home" />
      </>
    );
  }
  const proj = projectByName(ui.currentProject);
  return (
    <>
      <div className="app-header" style={{ flexDirection: 'column', alignItems: 'stretch', gap: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center' }}><div style={{ flex: 1 }}>{title}</div></div>
        <div className="searchbar" style={{ minHeight: 56 }}>
          <Icon name="search" />
          <input type="text" id="home-search-input" placeholder={t('search_materials')} value={ui.searchQuery}
            onChange={(e) => A.search(e.target.value)} aria-label={t('search_materials')} />
          {ui.searchQuery ? <button type="button" className="cart-remove" style={{ width: 32, height: 32 }} onClick={A.clearSearch} aria-label="Clear search"><Icon name="close" /></button> : null}
        </div>
        <div className="compact-project-row">
          <button className="cpr-main" onClick={() => P.openProjectWorkspace(proj ? proj.id : null)}>
            <span className="cpr-icon"><Icon name="projects" /></span>
            <div className="cpr-text">
              <div className="cpr-name">{ui.currentProject}</div>
              <div className="cpr-label">{currentProjectContextLine(u, proj)}</div>
            </div>
          </button>
          <button className="cpr-change" onClick={A.openSwitcher}>{t('change')} <Icon name="chev" /></button>
        </div>
      </div>
      <div className="content" id="home-body">
        {ui.searchQuery.trim() ? <SearchResults /> : (
          <>
            <KitRail />
            <ProductRail title={t('recently_used')} ids={u.recentlyUsed} />
            <CategoryList />
            <ProductRail title={t('most_used_by_you')} ids={u.mostUsed} />
            <div style={{ height: 12 }} />
          </>
        )}
      </div>
      <CartFab />
      <FieldNav active="home" />
    </>
  );
}

// Home group -> (area list when the group has several) -> area products by subcategory.
export function Category() {
  const key = ui.categoryKey;
  const g = groupByKey(key);
  if (g && g.areas.length > 1) {
    return (
      <>
        <Header onBack={() => A.goto('fHome')} title={g.label} sub={g.areas.length + ' sections'} />
        <div className="content section-pad">
          {g.areas.map((a) => {
            const n = familiesByCategory(a).length;
            return (
              <button key={a} className="cat-row" onClick={() => A.openCategory(a)}>
                <span className="cat-row-label">{areaByKey(a).label}</span>
                <span className="cat-row-meta">{n} product{n === 1 ? '' : 's'}</span><Icon name="chev" />
              </button>
            );
          })}
        </div>
        <FieldNav active="home" />
      </>
    );
  }
  const areaKey = g ? g.areas[0] : LEGACY_CAT_TO_AREA[key] || key;
  const area = areaByKey(areaKey);
  const fams = familiesByCategory(areaKey);
  const legacy = PRODUCTS.filter((p) => !p.hidden && LEGACY_CAT_TO_AREA[p.cat] === areaKey);
  const subs = [];
  fams.forEach((f) => { if (subs.indexOf(f.sub) === -1) subs.push(f.sub); });
  const total = fams.length + legacy.length;
  return (
    <>
      <Header onBack={() => (ui.categoryParent ? A.openCategory(ui.categoryParent) : A.goto('fHome'))}
        title={area ? area.label : 'Category'} sub={total + ' product' + (total === 1 ? '' : 's')} />
      <div className="content">
        {subs.map((sub) => (
          <div key={sub}>
            <div className="section-pad" style={{ paddingBottom: 0 }}><div className="h2" style={{ fontSize: 18 }}>{sub}</div></div>
            <div className="gridlist" style={{ marginTop: 10 }}>
              {fams.filter((f) => f.sub === sub).map((f) => <CatalogCard key={f.id} item={f} />)}
            </div>
          </div>
        ))}
        {legacy.length ? <div className="gridlist" style={{ marginTop: 16 }}>{legacy.map((p) => <ProductCard key={p.id} p={p} />)}</div> : null}
        {total === 0 ? <Empty title="No products in this section yet" /> : null}
        <div style={{ height: 16 }} />
      </div>
      <FieldNav active="home" />
    </>
  );
}

export function Cart() {
  const items = ui.cart.map((c) => ({ c, p: getProduct(c.productId) })).filter((x) => x.p);
  const n = cartCount();
  const canOrder = canRequestNow();
  return (
    <>
      <Header onBack={() => A.goto('fHome')} title="Material Request" sub={n + ' item' + (n === 1 ? '' : 's')} subId="cart-count-label" />
      <div className="content no-nav" id="cart-body">
        {items.length === 0 ? (
          <Empty icon="box" title="Your material request is empty">
            <div>Search or browse the catalog to add materials.</div>
            <button className="btn btn-primary" onClick={() => A.goto('fHome')}>Browse materials</button>
          </Empty>
        ) : items.map(({ c, p }) => (
          <div className="cart-item" key={c.productId + '#' + (c.brandIdx || 0)}>
            <div className="thumb"><ProductImage p={p} /></div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="ciname">{p.name}</div>
              <div className="cimeta">{(p.size || '') + ' \u00b7 ' + brandOf(p, c.brandIdx || 0).mfr}</div>
              <div className="ciqty">
                <QtyStepper small value={c.qty} onStep={(d) => A.stepCartQty(c.productId, c.brandIdx || 0, d)} onSet={(v) => A.setCartQty(c.productId, c.brandIdx || 0, v)} />
                <span className="unit-tag">{p.unit}</span>
              </div>
            </div>
            <button className="cart-remove" onClick={() => A.removeCartItem(c.productId, c.brandIdx || 0)} aria-label={'Remove ' + p.name}><Icon name="close" /></button>
          </div>
        ))}
      </div>
      {items.length > 0 ? (
        <div style={{ position: 'fixed', left: '50%', bottom: 0, transform: 'translateX(-50%)', width: '100%', maxWidth: 460, background: 'var(--paper)', borderTop: '1px solid var(--line)', padding: '14px 18px', paddingBottom: 'calc(14px + env(safe-area-inset-bottom,0px))' }}>
          {canOrder
            ? <button className="btn btn-primary" onClick={() => A.goto('fOrderForm')}>Continue</button>
            : <><button className="btn btn-primary" disabled>Continue</button><div className="tiny muted" style={{ textAlign: 'center', marginTop: 8 }}>{t('view_only_access_project')} {ui.currentProject}.</div></>}
        </div>
      ) : null}
    </>
  );
}
