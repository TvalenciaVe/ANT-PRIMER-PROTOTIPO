import { ui } from '../lib/store.js';
import { getProduct, searchProducts, familySpecRange } from '../lib/catalog.js';
import { companyKits, myKits, getSuggestedMaterials } from '../lib/orders.js';
import { Icon, Header, ProductImage, MaterialRow, ErrorBanner } from '../components/common.jsx';
import * as A from '../lib/actions.js';
import * as F from '../lib/actionsField.js';

function KitRow({ kit }) {
  const n = kit.materials.length;
  return (
    <button className="profile-pick" onClick={() => F.openKit(kit.id)}>
      <div className="ricon" style={{ width: 42, height: 42, borderRadius: 10 }}><Icon name="box" /></div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div className="pname">{kit.name}</div>
        <div className="pmeta">{n} material{n === 1 ? '' : 's'}{kit.description ? ' · ' + kit.description : ''}</div>
      </div>
      <div className="chev"><Icon name="chev" /></div>
    </button>
  );
}

export function JobKits() {
  const comp = companyKits();
  const mine = myKits(ui.currentUser);
  const suggested = getSuggestedMaterials(ui.currentUser).slice(0, 5).map(getProduct).filter(Boolean);
  return (
    <>
      <Header onBack={() => A.goto('fHome')} title="Job Kits" sub="Grab a full set of materials in one tap" />
      <div className="content no-nav section-pad">
        <button className="btn btn-primary" style={{ marginBottom: 24 }} onClick={() => A.goto('fCreateKit')}><Icon name="plus" /> Create Job Kit</button>
        <div className="h2" style={{ marginBottom: 10 }}>Company Kits</div>
        {comp.length ? comp.map((k) => <KitRow key={k.id} kit={k} />) : <div className="empty" style={{ padding: '20px 6px' }}><div className="etitle">No company kits yet</div></div>}
        <div className="divider" />
        <div className="h2" style={{ marginBottom: 10 }}>My Kits</div>
        {mine.length ? mine.map((k) => <KitRow key={k.id} kit={k} />) : (
          <div className="empty" style={{ padding: '20px 6px' }}>
            <div className="etitle">No personal kits yet</div>
            <div>Create one above, or open a past order in My Orders and tap Save as Job Kit.</div>
          </div>
        )}
        {suggested.length ? (
          <>
            <div className="divider" />
            <div className="h2" style={{ marginBottom: 4 }}>Suggested for you</div>
            <div className="tiny muted" style={{ marginBottom: 12 }}>Based on materials from your past orders — a simple history rule, not AI.</div>
            <div className="info-card">
              {suggested.map((p) => <div className="spec-row" key={p.id}><span className="k">{p.name}</span><span className="v">{p.size || ''}</span></div>)}
              <div style={{ height: 12 }} />
              <button className="btn btn-secondary btn-sm" style={{ width: '100%' }} onClick={F.addSuggestedToRequest}>Add these to my request</button>
            </div>
          </>
        ) : null}
        <div style={{ height: 16 }} />
      </div>
    </>
  );
}

export function CreateKit() {
  const nk = ui.newKit;
  const results = ui.newKitSearch.trim() ? searchProducts(ui.newKitSearch).slice(0, 8) : [];
  return (
    <>
      <Header onBack={() => A.goto('fJobKits')} title="Create Job Kit" />
      <div className="content no-nav section-pad">
        <ErrorBanner />
        <div className="field"><label htmlFor="nk-name">Kit name</label>
          <input type="text" id="nk-name" value={nk.name} placeholder={'e.g. 3/4" EMT Rough-In'} onChange={(e) => F.setNewKitField('name', e.target.value)} /></div>
        <div className="field"><label htmlFor="nk-desc">Description (optional)</label>
          <textarea id="nk-desc" value={nk.description} placeholder="Standard materials I normally use for..." onChange={(e) => F.setNewKitField('description', e.target.value)} /></div>
        <div className="field"><label htmlFor="nk-search-input">Add materials</label>
          <div className="searchbar"><Icon name="search" />
            <input type="text" id="nk-search-input" placeholder="Search the catalog..." value={ui.newKitSearch} onChange={(e) => F.newKitSearch(e.target.value)} /></div>
        </div>
        <div id="ck-body">
          {results.length ? (
            <div style={{ margin: '-6px 0 6px' }}>
              {results.map((p) => (
                <div className="check-item" key={p.id}>
                  <div className="thumb" style={{ width: 42, height: 42, borderRadius: 8, flexShrink: 0 }}><ProductImage p={p} key={p.id} /></div>
                  <div style={{ flex: 1, minWidth: 0 }}><div className="ciname">{p.name}</div><div className="ciqty">{p.variants ? familySpecRange(p) : p.size || ''}</div></div>
                  {p.variants
                    ? <button className="btn-sm btn-secondary" onClick={() => A.openFamilyForKit(p.id)}>Choose</button>
                    : <button className="btn-sm btn-secondary" onClick={() => F.addToNewKit(p.id)}>Add</button>}
                </div>
              ))}
            </div>
          ) : null}
          <div className="h2" style={{ margin: '18px 0 6px' }}>Materials in this kit ({nk.items.length})</div>
          {nk.items.length ? nk.items.map((it, idx) => {
            const p = getProduct(it.productId);
            return p ? <MaterialRow key={it.productId} p={p} qty={it.qty} meta={p.size || ''}
              onStep={(d) => F.stepNewKitQty(idx, d)} onSet={(v) => F.setNewKitQty(idx, v)} onRemove={() => F.removeNewKitItem(idx)} /> : null;
          }) : <div className="empty" style={{ padding: '24px 6px' }}><div className="etitle">No materials added yet</div><div>Search above and tap Add.</div></div>}
        </div>
        <div style={{ height: 20 }} />
        <button className="btn btn-primary" onClick={F.saveNewKit}>Save kit</button>
      </div>
    </>
  );
}
