import { ui } from '../lib/store.js';
import { db } from '../lib/db.js';
import { initials } from '../lib/validation.js';
import { Icon, Header, ErrorBanner } from '../components/common.jsx';
import * as A from '../lib/actions.js';

function RoleCard({ icon, title, sub, onClick, dashed }) {
  return (
    <button className="role-card" onClick={onClick} style={dashed ? { borderStyle: 'dashed', justifyContent: 'center' } : undefined}>
      <div className="ricon"><Icon name={icon} /></div>
      <div><div className="rtitle">{title}</div><div className="rsub">{sub}</div></div>
      {dashed ? null : <div className="chev"><Icon name="chev" /></div>}
    </button>
  );
}

export function RoleSelect() {
  return (
    <div className="content no-nav" style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '32px 24px' }}>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginBottom: 36 }}>
        <div className="brand-mark">ANT</div>
        <div style={{ fontSize: 26, fontWeight: 800, marginTop: 16, letterSpacing: '-0.01em', color: 'var(--ink)' }}>ANT</div>
        <div className="muted small" style={{ marginTop: 4, textAlign: 'center' }}>Move materials. Keep work moving.</div>
      </div>
      <RoleCard icon="projects" title="I'm on the Field Team" sub="Foreman, journeyman, or apprentice" onClick={() => A.chooseRole('foreman')} />
      <RoleCard icon="box" title="I'm on the Warehouse Team" sub="Warehouse manager or warehouse worker" onClick={() => A.chooseRole('manager')} />
      <button className="btn-ghost" style={{ marginTop: 28, color: 'var(--mist)', fontSize: 13 }} onClick={A.confirmResetDemoData}>Reset demo data</button>
    </div>
  );
}

export function ProfilePicker({ role }) {
  const list = role === 'foreman' ? db.FOREMEN : db.MANAGERS;
  return (
    <>
      <Header onBack={A.back} title="Select your profile" />
      <div className="content no-nav section-pad">
        {list.map((p) => (
          <button key={p.id} className="profile-pick" onClick={() => A.pickProfile(role, p.id)}>
            <div className="avatar">{initials(p.name)}</div>
            <div>
              <div className="pname">{p.name}</div>
              <div className="pmeta">{role === 'foreman' ? p.companyRole + ' \u00b7 ' + (p.currentProject || 'No project yet') : p.title}</div>
            </div>
            <div className="chev"><Icon name="chev" /></div>
          </button>
        ))}
        <RoleCard dashed icon="plus" title="Create new profile" sub="First time using ANT"
          onClick={() => A.startOnboarding(role === 'foreman' ? 'field' : 'warehouse')} />
      </div>
    </>
  );
}

export function Pin() {
  const p = ui.pendingProfile;
  const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', 'back'];
  return (
    <>
      <Header onBack={A.back} title="Enter PIN" />
      <div className="content no-nav pinpad-wrap">
        <div className="avatar" style={{ width: 60, height: 60, fontSize: 18 }}>{initials(p.name)}</div>
        <div style={{ fontWeight: 700, fontSize: 16, marginTop: 12 }}>{p.name}</div>
        <div className="muted small">Enter your 4-digit access code</div>
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className={'pindot' + (i < ui.pinValue.length ? ' filled' : '') + (ui.pinError ? ' err' : '')} />
        ))}
        <div className="pin-error" role="alert">{ui.pinError ? 'Incorrect PIN. Try again.' : ''}</div>
        <div className="padgrid">
          {keys.map((k, i) => {
            if (k === '') return <div key={i} />;
            if (k === 'back') return <button key={i} className="padkey ghost" onClick={A.pinBackspace} aria-label="Delete"><Icon name="back" /></button>;
            return <button key={i} className="padkey" onClick={() => A.pinDigit(k)}>{k}</button>;
          })}
        </div>
      </div>
    </>
  );
}

const FIELD_ROLES = [
  ['Foreman', 'Manage project materials, team access, and Material Requests.'],
  ['Journeyman', 'Work with project materials and request materials when authorized by the Foreman.'],
  ['Apprentice', 'View project materials and request materials when authorized by the Foreman.'],
];
const WAREHOUSE_ROLES = [
  ['Warehouse Manager', 'Manage warehouse operations, inventory, fulfillment, restocking, and dispatch.'],
  ['Warehouse Worker', 'Pick and pack materials, complete checklists, and view warehouse inventory.'],
];

export function NewProfileRole() {
  const field = ui.newProfile.workArea === 'field';
  return (
    <>
      <Header onBack={A.back} title="What's your role?" />
      <div className="content no-nav section-pad">
        {(field ? FIELD_ROLES : WAREHOUSE_ROLES).map(([role, sub]) => (
          <RoleCard key={role} icon={field ? 'projects' : 'box'} title={role} sub={sub} onClick={() => A.selectOnboardingRole(role)} />
        ))}
      </div>
    </>
  );
}

function Field({ label, k, type, placeholder, ...rest }) {
  return (
    <div className="field">
      <label htmlFor={'np-' + k}>{label}</label>
      <input id={'np-' + k} type={type || 'text'} placeholder={placeholder} value={ui.newProfile[k]}
        onChange={(e) => A.setNewProfileField(k, e.target.value)} {...rest} />
    </div>
  );
}

export function NewProfile() {
  const np = ui.newProfile;
  return (
    <>
      <Header onBack={A.back} title="Create profile" />
      <div className="content no-nav section-pad">
        <ErrorBanner />
        <div className="info-card" style={{ marginBottom: 18, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div><div className="tiny muted" style={{ fontWeight: 700 }}>Role</div><div style={{ fontWeight: 700, fontSize: 16, marginTop: 2 }}>{np.role}</div></div>
          <span className="badge badge-current">{np.workArea === 'field' ? 'Field' : 'Warehouse'}</span>
        </div>
        <Field label="Full name" k="name" placeholder="e.g. Luis Ramirez" />
        <Field label="Email" k="email" type="email" placeholder="name@example.com" />
        <Field label="Phone number" k="phone" type="tel" placeholder="(555) 555-0100" />
        <Field label="Create a 4-digit PIN" k="pin" inputMode="numeric" maxLength={4} placeholder="4 digits" />
        <Field label="Company" k="company" placeholder="e.g. Ali Electric" />
        <button className="btn btn-primary" onClick={A.submitNewProfile}>Create profile</button>
      </div>
    </>
  );
}
