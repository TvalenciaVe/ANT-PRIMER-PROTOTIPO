import { ui } from '../lib/store.js';
import { db } from '../lib/db.js';
import { t } from '../lib/i18n.js';
import {
  myProjects, membershipFor, canCreateProject, canViewProject, canCreateMaterialRequest, canManageProjectTeam,
  projectById, projectStats, activityForProject, foremanNameForProject, teamForProject, permLabel,
} from '../lib/permissions.js';
import { getProduct } from '../lib/catalog.js';
import { orderProgress, fmtNeeded, relTime, statusPillClass, orderById } from '../lib/orders.js';
import { Icon, Header, Empty, FieldNav, ErrorBanner, Sheet, QtyStepper } from '../components/common.jsx';
import * as A from '../lib/actions.js';
import * as P from '../lib/actionsProjects.js';

const plural = (n, word, many) => n + ' ' + (n === 1 ? word : many || word + 's');
const shortLine = (prog) => (
  <span className={'tiny' + (prog.shorted > 0 ? '' : ' muted')} style={prog.shorted > 0 ? { color: 'var(--warning)', fontWeight: 700 } : undefined}>
    {prog.done}/{prog.total}{prog.shorted > 0 ? ' processed (' + prog.shorted + ' short)' : ' collected'}
  </span>
);

function ProjectRow({ p }) {
  const u = ui.currentUser;
  const st = projectStats(p.id);
  const m = membershipFor(u.id, p.id);
  return (
    <div className="info-card" style={{ marginBottom: 12 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <div style={{ fontWeight: 700, fontSize: 17, color: 'var(--ink)' }}>{p.name}</div>
          <div className="tiny muted" style={{ marginTop: 2 }}>{p.status}{m ? ' · ' + m.projectRole : ''}</div>
        </div>
        {p.name === ui.currentProject ? <span className="badge badge-current">Current</span> : null}
      </div>
      <div className="tiny muted" style={{ marginTop: 10 }}>
        {plural(st.teamCount, 'team member')} · {st.openRequests > 0 ? plural(st.openRequests, 'open request') : 'No open requests'}
        {st.upcomingDeliveries > 0 ? ' · ' + plural(st.upcomingDeliveries, 'upcoming delivery', 'upcoming deliveries') : ''}
      </div>
      <div style={{ height: 12 }} />
      <button className="btn btn-secondary btn-sm" style={{ width: '100%' }} onClick={() => P.openProjectWorkspace(p.id)}>Open project</button>
    </div>
  );
}

export function ProjectsList() {
  const u = ui.currentUser;
  const projects = myProjects(u);
  const active = projects.filter((p) => p.status === 'Active');
  const completed = projects.filter((p) => p.status !== 'Active');
  return (
    <>
      <div className="app-header"><div className="htitle">Projects</div></div>
      <div className="content section-pad">
        <div className="h2" style={{ marginBottom: 12 }}>My Projects</div>
        {active.length ? active.map((p) => <ProjectRow key={p.id} p={p} />) : (
          <div className="empty" style={{ padding: '24px 6px' }}>
            <div className="etitle">{projects.length === 0 ? 'No projects yet' : 'No active projects'}</div>
            {projects.length === 0 ? <div>{canCreateProject(u) ? 'Create a project below to get started.' : 'Ask a Foreman to add you to a project.'}</div> : null}
          </div>
        )}
        {completed.length ? <><div className="divider" /><div className="h2" style={{ marginBottom: 12 }}>Completed Projects</div>{completed.map((p) => <ProjectRow key={p.id} p={p} />)}</> : null}
        <div style={{ height: 8 }} />
        {canCreateProject(u) ? <button className="btn btn-secondary" onClick={() => A.goto('fAddProject')}><Icon name="plus" /> Add project</button> : null}
        <div style={{ height: 12 }} />
      </div>
      <FieldNav active="projects" />
    </>
  );
}

export function AddProject() {
  const d = ui.addProjectDraft;
  const F = ({ k, label, placeholder, area }) => (
    <div className="field"><label htmlFor={'ap-' + k}>{label}</label>
      {area
        ? <textarea id={'ap-' + k} value={d[k]} placeholder={placeholder} onChange={(e) => P.setProjectField(k, e.target.value)} />
        : <input type="text" id={'ap-' + k} value={d[k]} placeholder={placeholder} onChange={(e) => P.setProjectField(k, e.target.value)} />}
    </div>
  );
  return (
    <>
      <Header onBack={() => A.goto('fProjects')} title="Add project" />
      <div className="content no-nav section-pad">
        <ErrorBanner />
        {F({ k: 'name', label: 'Project name', placeholder: 'e.g. Hackensack Medical Center Renovation' })}
        {F({ k: 'address', label: 'Project address', placeholder: 'e.g. 30 Prospect Ave, Hackensack, NJ' })}
        {F({ k: 'number', label: 'Project number (optional)', placeholder: 'e.g. AEC-2026-014' })}
        {F({ k: 'description', label: 'Description (optional)', placeholder: 'e.g. 3rd Floor Electrical Renovation', area: true })}
        <button className="btn btn-primary" onClick={P.reviewCreateProject}>Create project</button>
      </div>
    </>
  );
}

const StatTile = ({ value, label }) => (
  <div className="info-card" style={{ textAlign: 'center', padding: '14px 6px' }}>
    <div style={{ fontSize: 21, fontWeight: 800, color: 'var(--ink)' }}>{value}</div>
    <div className="tiny muted" style={{ marginTop: 2 }}>{label}</div>
  </div>
);

function OverviewTab({ proj }) {
  const st = projectStats(proj.id);
  const activity = activityForProject(proj.id).slice(0, 6);
  return (
    <div className="section-pad">
      <div className="info-card" style={{ marginBottom: 16 }}>
        <div className="spec-row"><span className="k">Address</span><span className="v">{proj.address || '\u2014'}</span></div>
        {proj.number ? <div className="spec-row"><span className="k">Project number</span><span className="v">{proj.number}</span></div> : null}
        <div className="spec-row"><span className="k">Status</span><span className="v">{proj.status}</span></div>
        <div className="spec-row" style={{ borderBottom: 'none' }}><span className="k">Foreman</span><span className="v">{foremanNameForProject(proj.id)}</span></div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10, marginBottom: 16 }}>
        <StatTile value={st.teamCount} label="Team" /><StatTile value={st.openRequests} label="Open requests" /><StatTile value={st.upcomingDeliveries} label="Upcoming" />
      </div>
      {proj.description ? (
        <div className="info-card" style={{ marginBottom: 16 }}>
          <div className="tiny muted" style={{ fontWeight: 700 }}>Description</div>
          <div className="small" style={{ marginTop: 4, color: 'var(--ink)' }}>{proj.description}</div>
        </div>
      ) : null}
      <div className="h2" style={{ marginBottom: 10 }}>Recent activity</div>
      {activity.length ? activity.map((a) => (
        <div className="spec-row" key={a.id}>
          <span className="k" style={{ flex: 1, color: 'var(--ink-soft)' }}>{a.text}</span>
          <span className="v tiny muted" style={{ fontWeight: 400, whiteSpace: 'nowrap' }}>{relTime(a.at)}</span>
        </div>
      )) : <div className="empty" style={{ padding: '20px 0' }}><div className="etitle">No activity yet</div></div>}
    </div>
  );
}

const BUCKETS = ['Requested', 'Being Prepared', 'On the Way', 'Delivered'];
function bucketOf(status) {
  if (['Pending', 'In Progress', 'Partially Packed'].indexOf(status) !== -1) return 'Requested';
  if (['Packed', 'Ready to Ship'].indexOf(status) !== -1) return 'Being Prepared';
  if (status === 'Shipped') return 'On the Way';
  if (status === 'Completed') return 'Delivered';
  return status;
}
function MaterialsTab({ proj }) {
  const orders = db.ORDERS.filter((o) => o.project === proj.name);
  const canReq = canCreateMaterialRequest(ui.currentUser, proj.id);
  const any = orders.length > 0;
  return (
    <div className="section-pad">
      {canReq
        ? <button className="btn btn-primary" style={{ marginBottom: 18 }} onClick={() => P.startRequestFromWorkspace(proj.id)}><Icon name="plus" /> Request materials</button>
        : <div className="alert-banner" style={{ background: 'var(--sunken)', color: 'var(--ink-soft)' }}><Icon name="projects" /><span>{t('view_only_access_requests')}</span></div>}
      {BUCKETS.map((b) => {
        const list = orders.filter((o) => bucketOf(o.status) === b);
        if (!list.length) return null;
        return (
          <div key={b}>
            <div className="h2" style={{ margin: '18px 0 10px' }}>{b}</div>
            {list.map((o) => (
              <div className="info-card" style={{ marginBottom: 10 }} key={o.id}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div style={{ fontWeight: 700 }}>{o.id}</div><span className={'badge badge-' + o.priority}>{o.priority}</span>
                </div>
                <div className="tiny muted" style={{ marginTop: 4 }}>{plural(o.items.length, 'material')} · Requested by {o.foremanName}</div>
              </div>
            ))}
          </div>
        );
      })}
      {any ? null : <Empty title="No materials requested yet" />}
    </div>
  );
}

function OrdersTab({ proj }) {
  const orders = db.ORDERS.filter((o) => o.project === proj.name).sort((a, b) => b.createdAt - a.createdAt);
  return (
    <div className="section-pad">
      {orders.length ? orders.map((o) => (
        <div className="info-card" style={{ marginBottom: 10 }} key={o.id}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div><div style={{ fontWeight: 700, fontSize: 15 }}>{o.id}</div><div className="tiny muted">Requested by {o.foremanName}</div></div>
            <span className={'badge badge-' + o.priority}>{o.priority}</span>
          </div>
          <div className="ocmeta2" style={{ marginTop: 8 }}><span>{o.items.length} materials</span><span>·</span><span>Needed {fmtNeeded(o.neededBy)}</span></div>
          <div style={{ marginTop: 8, display: 'flex', alignItems: 'center', gap: 10 }}>
            <span className={'status-pill' + statusPillClass(o.status)}>{o.status}</span>{shortLine(orderProgress(o))}
          </div>
        </div>
      )) : <Empty title="No orders yet" />}
    </div>
  );
}

function DeliveryRow({ o }) {
  const when = o.status === 'Completed' ? (o.completedAt ? 'Delivered ' + relTime(o.completedAt) : 'Delivered') : 'Expected ' + fmtNeeded(o.neededBy);
  let confirm = null;
  if (o.status === 'Completed' && o.fieldConfirmed) {
    confirm = o.deliveryIssues && o.deliveryIssues.length
      ? <div className="tiny" style={{ color: 'var(--warning)', fontWeight: 700, marginTop: 4 }}><Icon name="alert" /> Delivery issue reported</div>
      : <div className="tiny" style={{ color: 'var(--good)', fontWeight: 700, marginTop: 4 }}><Icon name="check" /> Confirmed by {o.fieldConfirmedBy || 'field'}</div>;
  }
  return (
    <div className="info-card" style={{ marginBottom: 10 }}>
      <div style={{ fontWeight: 700 }}>{plural(o.items.length, 'material')}</div>
      <div className="tiny muted" style={{ marginTop: 2 }}>{when} · {o.id}</div>
      {confirm}
    </div>
  );
}
function DeliveriesTab({ proj }) {
  const canConfirm = canCreateMaterialRequest(ui.currentUser, proj.id);
  const shipped = db.ORDERS.filter((o) => o.project === proj.name && o.status === 'Shipped').sort((a, b) => b.createdAt - a.createdAt);
  const delivered = db.ORDERS.filter((o) => o.project === proj.name && o.status === 'Completed').sort((a, b) => (b.completedAt || 0) - (a.completedAt || 0));
  const needs = delivered.filter((o) => !o.fieldConfirmed);
  return (
    <div className="section-pad">
      {canConfirm && needs.length ? (
        <>
          <div className="h2" style={{ marginBottom: 10 }}>Needs confirmation</div>
          {needs.map((o) => (
            <div className="info-card" style={{ marginBottom: 10, borderColor: 'var(--ant-blue)' }} key={o.id}>
              <div style={{ fontWeight: 700 }}>{plural(o.items.length, 'material')} delivered</div>
              <div className="tiny muted" style={{ marginTop: 2 }}>{o.id}</div>
              <button className="btn btn-primary btn-sm" style={{ width: '100%', marginTop: 10 }} onClick={() => P.openDeliveryConfirm(o.id)}>{t('did_everything_arrive')}</button>
            </div>
          ))}
          <div className="divider" />
        </>
      ) : null}
      <div className="h2" style={{ marginBottom: 10 }}>On the way</div>
      {shipped.length ? shipped.map((o) => <DeliveryRow key={o.id} o={o} />) : <div className="empty" style={{ padding: '20px 0' }}><div className="etitle">Nothing on the way</div></div>}
      <div className="divider" />
      <div className="h2" style={{ marginBottom: 10 }}>Delivered</div>
      {delivered.length ? delivered.map((o) => <DeliveryRow key={o.id} o={o} />) : <div className="empty" style={{ padding: '20px 0' }}><div className="etitle">No deliveries yet</div></div>}
    </div>
  );
}

function TeamTab({ proj }) {
  const team = teamForProject(proj.id).sort((a, b) => {
    if (a.membership.projectRole === 'Foreman') return -1;
    if (b.membership.projectRole === 'Foreman') return 1;
    return a.user.name.localeCompare(b.user.name);
  });
  const canManage = canManageProjectTeam(ui.currentUser, proj.id);
  return (
    <div className="section-pad">
      {team.map(({ membership: m, user }) => {
        const isForeman = m.projectRole === 'Foreman';
        return (
          <div className="info-card" style={{ marginBottom: 10 }} key={user.id}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}>
              <div style={{ minWidth: 0 }}><div style={{ fontWeight: 700, fontSize: 15 }}>{user.name}</div><div className="tiny muted">{m.projectRole}</div></div>
              {isForeman ? <span className="badge badge-current" style={{ flexShrink: 0 }}>Foreman</span> : null}
            </div>
            {isForeman ? null : canManage ? (
              <div className="segment" style={{ margin: '12px 0 0' }}>
                {['viewer', 'can_edit'].map((lvl) => (
                  <button key={lvl} className={m.permissionLevel === lvl ? 'on' : ''} onClick={() => P.requestPermissionChange(proj.id, user.id, lvl)}>{permLabel(lvl)}</button>
                ))}
              </div>
            ) : (
              <div style={{ marginTop: 10 }}>
                {m.permissionLevel === 'can_edit'
                  ? <span className="badge badge-current">{permLabel('can_edit')}</span>
                  : <span className="badge" style={{ background: 'var(--sunken)', color: 'var(--ink-soft)' }}>{permLabel('viewer')}</span>}
              </div>
            )}
          </div>
        );
      })}
      {canManage ? <button className="btn btn-secondary" style={{ marginTop: 6 }} onClick={P.openAddTeamMember}><Icon name="plus" /> Add team member</button> : null}
    </div>
  );
}

const TABS = [['overview', 'Overview', OverviewTab], ['materials', 'Materials', MaterialsTab], ['orders', 'Orders', OrdersTab], ['deliveries', 'Deliveries', DeliveriesTab], ['team', 'Team', TeamTab]];
export function ProjectWorkspace() {
  const proj = projectById(ui.projectWorkspaceId);
  const u = ui.currentUser;
  if (!proj || !canViewProject(u, proj.id)) {
    return (
      <>
        <Header onBack={() => A.goto('fProjects')} title="Not available" />
        <div className="content no-nav"><Empty icon="projects" title="You don't have access to this project" /></div>
      </>
    );
  }
  const m = membershipFor(u.id, proj.id);
  const tab = TABS.find((x) => x[0] === ui.projectWorkspaceTab) || TABS[0];
  const Body = tab[2];
  return (
    <>
      <div className="app-header">
        <button className="icon-btn" onClick={() => A.goto('fProjects')} aria-label="Back"><Icon name="back" /></button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="htitle" style={{ fontSize: 19 }}>{proj.name}</div>
          <div className="hsub">{proj.status}{m ? ' · ' + m.projectRole : ''}</div>
        </div>
      </div>
      <div className="tab-row" style={{ marginTop: 14, marginBottom: 2 }}>
        {TABS.map(([k, label]) => <button key={k} className={'chip' + (tab[0] === k ? ' on' : '')} onClick={() => P.setWorkspaceTab(k)}>{label}</button>)}
      </div>
      <div className="content no-nav"><Body proj={proj} /></div>
    </>
  );
}

/* ---------------- sheets ---------------- */
export function DuplicateProjectSheet() {
  const dup = ui.duplicateWarning; if (!dup) return null;
  return (
    <Sheet center onClose={P.dismissDuplicateWarning}>
      <div className="section-pad" style={{ paddingTop: 22 }}>
        <div className="h1" style={{ marginBottom: 6 }}>This project may already exist</div>
        <div className="info-card" style={{ marginBottom: 16 }}>
          <div style={{ fontWeight: 700 }}>{dup.name}</div><div className="tiny muted" style={{ marginTop: 2 }}>{dup.address || ''}</div>
        </div>
        <button className="btn btn-secondary" style={{ marginBottom: 10 }} onClick={P.viewExistingProject}>View existing project</button>
        <button className="btn btn-primary" onClick={P.createProject}>Create anyway</button>
      </div>
    </Sheet>
  );
}

export function AddTeamMemberSheet() {
  const proj = projectById(ui.projectWorkspaceId); if (!proj) return null;
  const existing = teamForProject(proj.id).map((x) => x.user.id);
  const candidates = db.FOREMEN.filter((w) => existing.indexOf(w.id) === -1);
  return (
    <Sheet onClose={P.closeAddTeamMember} title="Add team member">
      <div className="section-pad">
        {candidates.length === 0 ? <div className="empty" style={{ padding: '30px 0' }}><div className="etitle">Everyone is already on this team</div></div>
          : candidates.map((w) => {
            const sel = ui.addTeamMemberSelections[w.id];
            return (
              <div className="info-card" style={{ marginBottom: 10 }} key={w.id}>
                <label className="checkline" style={{ padding: 0, marginBottom: sel ? 12 : 0 }}>
                  <input type="checkbox" checked={!!sel} onChange={() => P.toggleMemberSelection(w.id)} />
                  <span><span style={{ fontWeight: 700, display: 'block' }}>{w.name}</span><span className="tiny muted">{w.companyRole}</span></span>
                </label>
                {sel ? (
                  <div className="segment" style={{ margin: 0 }}>
                    {['viewer', 'can_edit'].map((lvl) => <button key={lvl} className={sel === lvl ? 'on' : ''} onClick={() => P.setMemberPermission(w.id, lvl)}>{permLabel(lvl)}</button>)}
                  </div>
                ) : null}
              </div>
            );
          })}
        {candidates.length ? <button className="btn btn-primary" onClick={P.confirmAddTeamMembers}>Add to project</button> : null}
      </div>
    </Sheet>
  );
}

export function PermissionChangeSheet() {
  const c = ui.permissionChangeConfirm; if (!c) return null;
  const proj = projectById(c.projectId);
  const toEdit = c.to === 'can_edit';
  return (
    <Sheet center onClose={P.cancelPermissionChange}>
      <div className="section-pad" style={{ paddingTop: 22 }}>
        <div className="h1" style={{ marginBottom: 6 }}>{toEdit ? 'Give ' + c.userName + ' permission to request materials?' : 'Change ' + c.userName + ' to view only?'}</div>
        <div className="small muted" style={{ marginBottom: 16 }}>
          {toEdit
            ? c.userName + ' will be able to create and submit material requests for ' + (proj ? proj.name : 'this project') + '.'
            : c.userName + ' will still be able to view project materials, orders, and deliveries, but will no longer be able to create or submit material requests for this project.'}
        </div>
        <button className="btn btn-primary" style={{ marginBottom: 10 }} onClick={P.confirmPermissionChange}>{toEdit ? 'Give access' : 'Change to view only'}</button>
        <button className="btn btn-secondary" onClick={P.cancelPermissionChange}>Cancel</button>
      </div>
    </Sheet>
  );
}

export function DeliveryConfirmSheet() {
  const o = orderById(ui.deliveryConfirmOrderId); if (!o) return null;
  if (ui.deliveryConfirmStep === 'report') {
    return (
      <Sheet onClose={P.closeDeliveryConfirm} title="What arrived?">
        <div className="section-pad" style={{ paddingTop: 0, paddingBottom: 0 }}><div className="tiny muted">{o.id} · {o.project}</div></div>
        <div style={{ height: 12 }} />
        <div className="section-pad" id="delivery-report-rows">
          {o.items.map((it) => {
            const p = getProduct(it.productId); if (!p) return null;
            const arrived = ui.deliveryArrivedQty[it.productId];
            return (
              <div className="info-card" style={{ marginBottom: 10 }} key={it.productId}>
                <div style={{ fontWeight: 700 }}>{p.name}</div>
                <div className="tiny muted" style={{ margin: '2px 0 10px' }}>Expected: {it.qty} {p.unit}</div>
                <label className="tiny muted" style={{ fontWeight: 700, display: 'block', marginBottom: 6 }}>How many arrived?</label>
                <div className="qty-stepper-sm">
                  <button onClick={() => P.setArrivedQty(it.productId, arrived - 1)} aria-label="Decrease"><Icon name="minus" /></button>
                  <input type="number" min="0" value={arrived} onChange={(e) => P.setArrivedQty(it.productId, e.target.value)} />
                  <button onClick={() => P.setArrivedQty(it.productId, arrived + 1)} aria-label="Increase"><Icon name="plus" /></button>
                </div>
                {arrived < it.qty
                  ? <div className="tiny" id={'missing-' + it.productId} style={{ color: 'var(--warning)', fontWeight: 700, marginTop: 8 }}>Missing: {it.qty - arrived} {p.unit}</div>
                  : <div className="tiny" id={'missing-' + it.productId} />}
              </div>
            );
          })}
        </div>
        <div className="section-pad"><button className="btn btn-primary" onClick={P.submitDeliveryReport}>{t('submit')}</button></div>
      </Sheet>
    );
  }
  return (
    <Sheet center onClose={P.closeDeliveryConfirm}>
      <div className="section-pad" style={{ paddingTop: 22 }}>
        <div className="h1" style={{ marginBottom: 6 }}>Delivery arrived</div>
        <div className="small muted" style={{ marginBottom: 18 }}>{o.id} · {o.project}<br />{t('did_everything_arrive')}</div>
        <button className="btn btn-primary" style={{ marginBottom: 10 }} onClick={P.confirmDeliveryComplete}>{t('yes_everything_arrived')}</button>
        <button className="btn btn-secondary" onClick={P.goToReportMissing}>{t('something_missing')}</button>
      </div>
    </Sheet>
  );
}
