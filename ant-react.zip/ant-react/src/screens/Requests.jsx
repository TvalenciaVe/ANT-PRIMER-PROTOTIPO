import { ui } from '../lib/store.js';
import { db } from '../lib/db.js';
import { t } from '../lib/i18n.js';
import { canRequestNow, myProjects } from '../lib/permissions.js';
import { cartCount } from '../lib/cart.js';
import { initials } from '../lib/validation.js';
import { PRIORITIES, orderProgress, fmtNeeded, statusPillClass } from '../lib/orders.js';
import { Icon, Header, Empty, FieldNav, ErrorBanner, Preferences } from '../components/common.jsx';
import { ProductRail } from './Field.jsx';
import * as A from '../lib/actions.js';
import * as F from '../lib/actionsField.js';

export function OrderForm() {
  const d = ui.orderDraft;
  const n = cartCount();
  return (
    <>
      <Header onBack={() => A.goto('fCart')} title="Request details" />
      <div className="content no-nav section-pad">
        <ErrorBanner />
        <div className="info-card" style={{ marginBottom: 18 }}>
          <div className="tiny muted" style={{ fontWeight: 700 }}>Project</div>
          <div style={{ fontWeight: 700, fontSize: 15, marginTop: 2, color: 'var(--ink)' }}>{ui.currentProject}</div>
          <div className="divider" style={{ margin: '12px 0' }} />
          <div className="tiny muted" style={{ fontWeight: 700 }}>Materials</div>
          <div style={{ fontWeight: 700, fontSize: 15, marginTop: 2, color: 'var(--ink)' }}>
            {n} item{n === 1 ? '' : 's'} · {ui.cart.length} line{ui.cart.length === 1 ? '' : 's'}
          </div>
        </div>
        <div className="field"><label htmlFor="needed-date">Needed by — date</label>
          <input type="date" id="needed-date" value={d.neededDate} onChange={(e) => F.setDraft('neededDate', e.target.value)} /></div>
        <div className="field"><label htmlFor="needed-time">Needed by — time</label>
          <input type="time" id="needed-time" value={d.neededTime} onChange={(e) => F.setDraft('neededTime', e.target.value)} /></div>
        <div className="field"><label>Priority</label>
          <div className="chiprow">
            {PRIORITIES.map((pr) => (
              <button key={pr} className={'chip prio-chip' + (d.priority === pr ? ' on' : '')} data-p={pr} onClick={() => F.setPriority(pr)}>{pr}</button>
            ))}
          </div>
        </div>
        <div className="field"><label htmlFor="order-notes">Notes (optional)</label>
          <textarea id="order-notes" value={d.notes} placeholder="Any special instructions for the warehouse..."
            onChange={(e) => F.setDraft('notes', e.target.value)} /></div>
        <button className="btn btn-primary" onClick={F.reviewOrder}>Review request</button>
      </div>
    </>
  );
}

function OrderRow({ o }) {
  const prog = orderProgress(o);
  const can = canRequestNow();
  return (
    <div className="info-card" style={{ margin: '0 18px 12px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div><div style={{ fontWeight: 800, fontSize: 14.5 }}>{o.id}</div><div className="tiny muted">{o.project} · {fmtNeeded(o.neededBy)}</div></div>
        <span className={'badge badge-' + o.priority}>{o.priority}</span>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 10 }}>
        <span className={'status-pill' + statusPillClass(o.status)}>{o.status}</span>
        <span className={'tiny' + (prog.shorted > 0 ? '' : ' muted')} style={prog.shorted > 0 ? { color: 'var(--warning)', fontWeight: 700 } : undefined}>
          {prog.done}/{prog.total}{prog.shorted > 0 ? ' processed (' + prog.shorted + ' short)' : ' collected'}
        </span>
      </div>
      <div style={{ height: 10 }} />
      <div style={{ display: 'flex', gap: 8 }}>
        <button className="btn btn-secondary btn-sm" style={{ flex: 1 }} disabled={!can} onClick={() => F.reorder(o.id)}><Icon name="reorder" /> Reorder</button>
        <button className="btn btn-secondary btn-sm" style={{ flex: 1 }} onClick={() => F.openSaveAsKit(o.id)}><Icon name="box" /> Save as Job Kit</button>
      </div>
    </div>
  );
}

export function MyOrders() {
  const mine = db.ORDERS.filter((o) => o.foremanId === ui.currentUser.id).sort((a, b) => b.createdAt - a.createdAt);
  const done = (o) => ['Completed', 'Shipped'].indexOf(o.status) !== -1;
  const pending = mine.filter((o) => !done(o));
  const past = mine.filter(done);
  const usage = {};
  mine.forEach((o) => o.items.forEach((it) => { usage[it.productId] = (usage[it.productId] || 0) + 1; }));
  const mostUsed = Object.keys(usage).sort((a, b) => usage[b] - usage[a]).slice(0, 8);
  const recent = mine[0] ? mine[0].items.map((i) => i.productId).slice(0, 8) : [];
  return (
    <>
      <div className="app-header"><div className="htitle">Orders</div></div>
      <div className="content">
        <div className="section-pad"><div className="h2">Active requests</div></div>
        {pending.length ? pending.map((o) => <OrderRow key={o.id} o={o} />) : (
          <Empty title="No material requests yet">
            <div>Your submitted requests will appear here.</div>
            <button className="btn btn-primary" onClick={() => A.goto('fHome')}>{t('request_materials')}</button>
          </Empty>
        )}
        {recent.length ? <ProductRail title={t('recently_used')} ids={recent} /> : null}
        {mostUsed.length ? <ProductRail title="Most used materials" ids={mostUsed} /> : null}
        <div className="section-pad" style={{ marginTop: 8 }}><div className="h2">Previous orders</div></div>
        {past.length ? past.map((o) => <OrderRow key={o.id} o={o} />) : (
          <div className="empty" style={{ padding: '24px 30px' }}><div className="etitle">No completed orders yet</div></div>
        )}
        <div style={{ height: 12 }} />
      </div>
      <FieldNav active="orders" />
    </>
  );
}

export function FieldProfile() {
  const u = ui.currentUser;
  const projNames = myProjects(u).map((p) => p.name).join(', ') || '\u2014';
  return (
    <>
      <div className="app-header"><div className="htitle">Profile</div></div>
      <div className="content section-pad">
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 22 }}>
          <div className="avatar" style={{ width: 56, height: 56, fontSize: 18 }}>{initials(u.name)}</div>
          <div><div style={{ fontWeight: 800, fontSize: 17 }}>{u.name}</div><div className="muted small">{u.companyRole}</div></div>
        </div>
        <div className="info-card">
          <div className="spec-row"><span className="k">Email</span><span className="v">{u.email}</span></div>
          <div className="spec-row"><span className="k">Phone</span><span className="v">{u.phone}</span></div>
          <div className="spec-row"><span className="k">PIN</span><span className="v">••••</span></div>
          <div className="spec-row" style={{ borderBottom: 'none' }}><span className="k">Projects</span><span className="v">{projNames}</span></div>
        </div>
        <Preferences />
        <div style={{ height: 24 }} />
        <button className="btn btn-danger" onClick={A.logout}><Icon name="logout" /> Log out</button>
      </div>
      <FieldNav active="profile" />
    </>
  );
}
