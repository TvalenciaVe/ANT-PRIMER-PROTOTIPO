import { ui } from '../lib/store.js';
import { db } from '../lib/db.js';
import { t, greeting } from '../lib/i18n.js';
import { SUPPLIERS, COMPANIES } from '../data/seed.js';
import { projectByName, canPickMaterials, canDispatchOrder, canModifyInventory, canSourceMaterials } from '../lib/permissions.js';
import { getProduct, brandOf, catLabel, PRODUCTS } from '../lib/catalog.js';
import { availableQty, isFamilyVariantId, isLowStock, lowStockProducts, shortageLines, splitLocation } from '../lib/inventory.js';
import { PRIORITY_RANK, ORDER_STAGE_KEYS, orderProgress, statusToStageIndex, statusPillClass, fmtNeeded, relTime, money, orderById } from '../lib/orders.js';
import { initials } from '../lib/validation.js';
import { Icon, ProductImage, Sheet, Empty, Preferences, QtyStepper } from '../components/common.jsx';
import * as A from '../lib/actions.js';
import * as W from '../lib/actionsWarehouse.js';

const byPriorityThenNewest = (a, b) => (PRIORITY_RANK[b.priority] - PRIORITY_RANK[a.priority]) || (b.createdAt - a.createdAt);
const inCompany = (o, u) => { const p = projectByName(o.project); return !!p && p.companyId === u.companyId; };
const companyOrders = (u) => db.ORDERS.filter((o) => inCompany(o, u));
const ordersToPack = (u) => companyOrders(u).filter((o) => ['Pending', 'In Progress', 'Partially Packed'].indexOf(o.status) !== -1).sort(byPriorityThenNewest);
const plural = (n, w) => n + ' ' + w + (n === 1 ? '' : 's');

export function WarehouseNav({ active }) {
  const u = ui.currentUser;
  const items = u.baseRole === 'warehouse_worker'
    ? [['home', t('home'), 'home', 'whHome'], ['packing', t('packing'), 'box', 'whPacking'], ['inventory', t('inventory'), 'store', 'mInventory'], ['profile', t('profile'), 'profile', 'mProfile']]
    : [['home', t('home'), 'home', 'mHome'], ['orders', t('orders'), 'orders', 'mOrders'], ['inventory', t('inventory'), 'store', 'mInventory'], ['profile', t('profile'), 'profile', 'mProfile']];
  return (
    <div className="bottomnav">
      {items.map(([k, label, icon, go]) => (
        <button key={k} className={'navitem' + (active === k ? ' active' : '')} onClick={() => W.mNavTo(k, go)}><Icon name={icon} /><span>{label}</span></button>
      ))}
    </div>
  );
}

// Always paired with the text label, never color alone.
export function OrderTimeline({ status }) {
  const current = statusToStageIndex(status);
  return (
    <div className="order-timeline">
      {ORDER_STAGE_KEYS.map((key, i) => (
        <div key={key} className={'ot-step ' + (i < current ? 'done' : i === current ? 'current' : '')}>
          <span className="ot-dot">{i < current ? <Icon name="check" /> : null}</span><span className="ot-label">{t(key)}</span>
        </div>
      ))}
    </div>
  );
}

function ShortNote({ prog, word }) {
  return (
    <span className={'tiny' + (prog.shorted > 0 ? '' : ' muted')} style={prog.shorted > 0 ? { color: 'var(--warning)', fontWeight: 700 } : undefined}>
      {prog.done}/{prog.total}{prog.shorted > 0 ? ' processed (' + prog.shorted + ' short)' : ' ' + (word || 'collected')}
    </span>
  );
}

export function ManagerOrderCard({ o }) {
  const prog = orderProgress(o);
  return (
    <button className="order-card" onClick={() => W.openOrder(o.id)}>
      <div className={'stripe stripe-' + o.priority} />
      <div className="ocbody">
        <div className="ocrow1"><div className="ocneeded">Needed {fmtNeeded(o.neededBy)}</div><span className={'badge badge-' + o.priority}>{o.priority}</span></div>
        <div className="ocproj">{o.project}</div>
        <div className="ocmeta2"><span>{o.foremanName}</span><span>·</span><span>{plural(prog.total, 'material')}</span></div>
        <div className="ocfooter">
          <span className={'status-pill' + statusPillClass(o.status)}>{o.status}</span>
          {(prog.done > 0 && prog.done < prog.total) || prog.shorted > 0 ? <ShortNote prog={prog} /> : null}
          <span className="octime">Created {relTime(o.createdAt)}</span>
        </div>
      </div>
    </button>
  );
}

function PackCard({ o }) {
  const prog = orderProgress(o);
  return (
    <div className="info-card" style={{ marginBottom: 12 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div><div style={{ fontWeight: 700, fontSize: 16, color: 'var(--ink)' }}>{o.project}</div><div className="tiny muted">{plural(o.items.length, 'material')}</div></div>
        <span className={'badge badge-' + o.priority}>{o.priority}</span>
      </div>
      <div className={'tiny' + (prog.shorted > 0 ? '' : ' muted')} style={{ marginTop: 6, ...(prog.shorted > 0 ? { color: 'var(--warning)', fontWeight: 700 } : {}) }}>
        Needed {fmtNeeded(o.neededBy)} · {prog.done}/{prog.total}{prog.shorted > 0 ? ' processed (' + prog.shorted + ' short)' : ' packed'}
      </div>
      <button className="btn btn-primary btn-sm" style={{ width: '100%', marginTop: 10 }} onClick={() => W.startPackingMode(o.id)}>Start packing</button>
    </div>
  );
}

const Greeting = () => (
  <div className="app-header"><div><div className="brand-tag">ANT</div><div className="h1" style={{ marginBottom: 0 }}>{greeting()}, {ui.currentUser.name.split(' ')[0]}</div></div></div>
);
const StatLink = ({ value, label, onClick }) => (
  <button className="info-card" style={{ textAlign: 'center', padding: '16px 8px' }} onClick={onClick}>
    <div style={{ fontSize: 22, fontWeight: 800, color: 'var(--ink)' }}>{value}</div><div className="tiny muted" style={{ marginTop: 2 }}>{label}</div>
  </button>
);

export function ManagerHome() {
  const active = companyOrders(ui.currentUser).filter((o) => o.status !== 'Completed');
  const emergency = active.filter((o) => o.priority === 'Emergency');
  const high = active.filter((o) => o.priority === 'High');
  const incoming = active.filter((o) => o.status === 'Pending').sort(byPriorityThenNewest);
  const inProgress = active.filter((o) => ['In Progress', 'Partially Packed'].indexOf(o.status) !== -1);
  const ready = active.filter((o) => o.status === 'Ready to Ship');
  const needSourcing = new Set(shortageLines().map((s) => s.item.productId)).size;
  return (
    <>
      <Greeting />
      <div className="content"><div className="section-pad">
        {emergency.length + high.length > 0 ? (
          <>
            <div className="h2" style={{ marginBottom: 10 }}>Needs attention</div>
            {emergency.length ? <div className="alert-banner" style={{ background: 'var(--emergency-bg)', color: 'var(--emergency)' }}><Icon name="alert" /><span>{plural(emergency.length, 'emergency request')}</span></div> : null}
            {high.length ? <div className="alert-banner" style={{ background: 'var(--high-bg)', color: 'var(--high)' }}><Icon name="alert" /><span>{plural(high.length, 'high priority request')}</span></div> : null}
          </>
        ) : null}
        <div className="h2" style={{ margin: '18px 0 10px' }}>Incoming requests</div>
        {incoming.length ? incoming.slice(0, 4).map((o) => <ManagerOrderCard key={o.id} o={o} />) : <div className="empty" style={{ padding: '20px 0' }}><div className="etitle">Nothing incoming</div></div>}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 6 }}>
          <StatLink value={inProgress.length} label="Packing in progress" onClick={() => W.mNavTo('orders', 'mOrders')} />
          <StatLink value={ready.length} label="Ready to ship" onClick={() => W.mNavTo('orders', 'mOrders')} />
          <StatLink value={lowStockProducts().length} label="Low stock items" onClick={() => W.mNavTo('inventory', 'mInventory')} />
          <StatLink value={needSourcing} label="Need sourcing" onClick={() => W.mNavTo('inventory', 'mInventory')} />
        </div>
      </div></div>
      <WarehouseNav active="home" />
    </>
  );
}

export function WorkerHome() {
  const toPack = ordersToPack(ui.currentUser);
  return (
    <>
      <Greeting />
      <div className="content"><div className="section-pad">
        <div className="h2" style={{ marginBottom: 10 }}>Orders to pack</div>
        {toPack.length ? toPack.slice(0, 5).map((o) => <PackCard key={o.id} o={o} />) : (
          <div className="empty" style={{ padding: '24px 0' }}><div className="etitle">No orders to pack</div><div>New packing assignments will appear here.</div></div>
        )}
        <div className="divider" />
        <div className="h2" style={{ marginBottom: 10 }}>Warehouse inventory</div>
        <button className="btn btn-secondary" onClick={() => W.mNavTo('inventory', 'mInventory')}><Icon name="search" /> Search inventory</button>
      </div></div>
      <WarehouseNav active="home" />
    </>
  );
}

const STATUS_FILTERS = ['All', 'New', 'In Progress', 'Packed', 'Ready to Ship', 'Completed'];
const PRIORITY_FILTERS = ['All', 'Emergency', 'High', 'Normal', 'Low'];
function matchesStatus(o, f) {
  if (f === 'All') return true;
  if (f === 'New') return o.status === 'Pending';
  if (f === 'In Progress') return ['In Progress', 'Partially Packed'].indexOf(o.status) !== -1;
  if (f === 'Completed') return ['Completed', 'Shipped'].indexOf(o.status) !== -1;
  return o.status === f;
}
export function ManagerOrders() {
  const list = companyOrders(ui.currentUser)
    .filter((o) => matchesStatus(o, ui.mStatusFilter) && (ui.mPriorityFilter === 'All' || o.priority === ui.mPriorityFilter))
    .sort(byPriorityThenNewest);
  return (
    <>
      <div className="app-header"><div><div className="brand-tag">ANT</div><div className="htitle">Orders</div><div className="hsub">{plural(list.length, 'order')} shown</div></div></div>
      <div className="content">
        <div className="tab-row" style={{ marginTop: 14 }}>
          {STATUS_FILTERS.map((s) => <button key={s} className={'chip' + (ui.mStatusFilter === s ? ' on' : '')} onClick={() => W.setStatusFilter(s)}>{s}</button>)}
        </div>
        <div className="tab-row" style={{ marginTop: 8, marginBottom: 6 }}>
          {PRIORITY_FILTERS.map((s) => <button key={s} className={'chip' + (ui.mPriorityFilter === s ? ' on' : '')} onClick={() => W.setPriorityFilter(s)}>{s}</button>)}
        </div>
        <div style={{ height: 12 }} />
        {list.length ? list.map((o) => <ManagerOrderCard key={o.id} o={o} />) : (
          <Empty icon="orders" title="No orders match these filters">
            <div>Try a different status or priority.</div>
            <button className="btn btn-secondary btn-sm" onClick={W.clearOrderFilters}>Clear filters</button>
          </Empty>
        )}
        <div style={{ height: 12 }} />
      </div>
      <WarehouseNav active="orders" />
    </>
  );
}

export function WarehousePacking() {
  const toPack = ordersToPack(ui.currentUser);
  return (
    <>
      <div className="app-header"><div className="htitle">Packing</div><div className="hsub">{plural(toPack.length, 'order')} to pack</div></div>
      <div className="content">
        <div style={{ height: 12 }} />
        {toPack.length ? toPack.map((o) => <PackCard key={o.id} o={o} />) : <Empty title="No orders to pack"><div>New packing assignments will appear here.</div></Empty>}
      </div>
      <WarehouseNav active="packing" />
    </>
  );
}

export function PackingMode() {
  const o = orderById(ui.packingOrderId);
  if (!o) return <WorkerHome />;
  const items = o.items;
  const doneCount = items.filter((x) => x.collected || (x.shortQty || 0) > 0).length;
  if (doneCount >= items.length) {
    return (
      <div className="content no-nav" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '100vh', padding: 40, textAlign: 'center' }}>
        <div className="checkbox on" style={{ width: 56, height: 56, borderRadius: '50%', marginBottom: 18 }}><Icon name="check" /></div>
        <div className="h1">{t('packing_complete')}</div>
        <div className="muted" style={{ marginBottom: 26 }}>{o.id} · {items.length} of {items.length} materials packed</div>
        <button className="btn btn-primary" style={{ maxWidth: 280 }} onClick={W.exitPackingMode}>{t('done')}</button>
      </div>
    );
  }
  let idx = ui.packingIndex;
  if (idx < 0 || idx >= items.length || items[idx].collected || (items[idx].shortQty || 0) > 0) { idx = W.firstUnresolvedIndex(o); ui.packingIndex = idx; }
  const it = items[idx];
  const p = getProduct(it.productId);
  const avail = availableQty(it.productId);
  const enough = avail >= it.qty;
  const loc = splitLocation(it.productId);
  const pct = Math.round((doneCount / items.length) * 100);
  return (
    <>
      <div className="app-header">
        <button className="icon-btn" onClick={W.exitPackingMode} aria-label="Exit packing"><Icon name="close" /></button>
        <div><div className="htitle" style={{ fontSize: 18 }}>{o.id}</div><div className="hsub">{o.project} · Needed {fmtNeeded(o.neededBy)}</div></div>
      </div>
      <div className="content no-nav"><div className="section-pad">
        <div className="pm-progress"><span>{t('packing')}</span><span>{doneCount + 1} of {items.length}</span></div>
        <div className="progress-bar" style={{ marginBottom: 24 }}><div className={'progress-fill' + (pct === 100 ? ' complete' : '')} style={{ width: pct + '%' }} /></div>
        <div className="detail-photo" style={{ height: 210, marginLeft: 0, marginRight: 0 }}><ProductImage p={p} large key={p.id} /></div>
        <div className="h1" style={{ textAlign: 'center', marginTop: 16, marginBottom: 2 }}>{p.name}</div>
        {p.size ? <div className="pm-size">{p.size}</div> : null}
        <div className="pm-stats">
          <div className="pm-stat"><div className="pm-stat-label">{t('need')}</div><div className="pm-stat-value">{it.qty} {p.unit}</div></div>
          <div className="pm-stat"><div className="pm-stat-label">{t('location')}</div><div className="pm-stat-value">{loc.code}</div></div>
          <div className="pm-stat"><div className="pm-stat-label">{t('available')}</div><div className="pm-stat-value" style={{ color: enough ? 'var(--good)' : 'var(--warning)' }}>{avail} {p.unit}</div></div>
        </div>
        {enough
          ? <button className="btn btn-primary" style={{ marginTop: 22 }} onClick={W.packCurrentFull}><Icon name="check" /> {t('pack')} {it.qty} {p.unit}</button>
          : <>
              <div className="alert-banner" style={{ background: 'var(--warning-bg)', color: 'var(--warning)', marginTop: 22 }}><Icon name="alert" /><span>Only {avail} {p.unit} available — not enough to pack {it.qty}.</span></div>
              <button className="btn btn-secondary" onClick={W.packCurrentShort}>{t('mark_short')}</button>
            </>}
        <div style={{ display: 'flex', justifyContent: 'center', gap: 18, marginTop: 16 }}>
          <button className="btn-ghost" onClick={W.packingSkip}>{t('skip_for_now')}</button>
          <button className="btn-ghost" onClick={W.viewFullListFromPacking}>{t('view_full_list')}</button>
        </div>
      </div></div>
    </>
  );
}

function LocationBlock({ productId }) {
  const loc = splitLocation(productId);
  return (
    <div className="loc-block">
      <div><div className="loc-label">Location</div><div className="loc-value">{loc.code}</div></div>
      {loc.area ? <div className="loc-area">{loc.area}</div> : null}
    </div>
  );
}

function InventoryRow({ p, canEdit }) {
  const qty = availableQty(p.id);
  const low = isLowStock(p.id);
  return (
    <div className="info-card" style={{ marginBottom: 10 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 }}>
        <div className="thumb check-thumb" style={{ borderRadius: 8 }}><ProductImage p={p} key={p.id} /></div>
        <div style={{ flex: 1, minWidth: 0 }}><div style={{ fontWeight: 700, color: 'var(--ink)' }}>{p.name}</div><div className="tiny muted" style={{ marginTop: 2 }}>{p.size || ''}</div></div>
        <span className="badge" style={{ flexShrink: 0, ...(low ? { background: 'var(--warning-bg)', color: 'var(--warning)' } : { background: 'var(--good-bg)', color: 'var(--good)' }) }}>{qty} {p.unit}</span>
      </div>
      <LocationBlock productId={p.id} />
      {canEdit ? (
        <div style={{ marginTop: 10 }}>
          <QtyStepper small value={qty} onStep={(d) => W.adjustInventory(p.id, d)} onSet={(v) => W.setInventoryQty(p.id, v)} />
        </div>
      ) : null}
    </div>
  );
}

export function Inventory() {
  const canEdit = canModifyInventory(ui.currentUser);
  const q = ui.invSearch.trim().toLowerCase();
  // Pool = every legacy product plus every configured variant that has real stock records.
  const pool = PRODUCTS.concat(Object.keys(db.INVENTORY).filter(isFamilyVariantId).map(getProduct).filter(Boolean));
  const list = q ? pool.filter((p) => (p.name + ' ' + (p.size || '') + ' ' + catLabel(p.cat) + ' ' + (p.displayName || '')).toLowerCase().indexOf(q) !== -1) : null;
  const shortages = shortageLines();
  const lowStock = lowStockProducts();
  return (
    <>
      <div className="app-header" style={{ flexDirection: 'column', alignItems: 'stretch', gap: 14 }}>
        <div><div className="htitle">Inventory</div><div className="hsub">Warehouse stock on hand</div></div>
        <div className="searchbar"><Icon name="search" />
          <input type="text" id="inv-search-input" placeholder="Search inventory" value={ui.invSearch} onChange={(e) => W.invSearch(e.target.value)} aria-label="Search inventory" /></div>
      </div>
      <div className="content" id="inv-body"><div className="section-pad">
        {list ? (
          <>
            <div className="h2" style={{ marginBottom: 10 }}>{plural(list.length, 'result')}</div>
            {list.length ? list.map((p) => <InventoryRow key={p.id} p={p} canEdit={canEdit} />)
              : <Empty title="No inventory items found"><div>Try another name, size, or part number.</div></Empty>}
          </>
        ) : canEdit ? (
          <>
            <div className="h2" style={{ marginBottom: 10 }}>Restock</div>
            {shortages.map((s, i) => {
              const p = getProduct(s.item.productId); if (!p) return null;
              return (
                <div className="info-card" style={{ marginBottom: 10 }} key={s.order.id + i}>
                  <div style={{ fontWeight: 700 }}>{p.name}</div>
                  <div className="tiny muted" style={{ marginTop: 2 }}><b style={{ color: 'var(--warning)' }}>Short {s.item.shortQty} {p.unit}</b> · {s.order.id} ({s.order.project})</div>
                </div>
              );
            })}
            {lowStock.length ? <><div className="h2" style={{ margin: '18px 0 10px' }}>Low stock</div>{lowStock.map((p) => <InventoryRow key={p.id} p={p} canEdit />)}</> : null}
            {!shortages.length && !lowStock.length ? <div className="empty" style={{ padding: '20px 0' }}><div className="etitle">Nothing needs restocking</div></div> : null}
            <button className="btn btn-secondary" style={{ marginTop: 12 }} onClick={() => A.goto('mSuppliers')}><Icon name="store" /> Browse suppliers</button>
          </>
        ) : <div className="tiny muted">Search above to find where a material is and how much is available.</div>}
      </div></div>
      <WarehouseNav active="inventory" />
    </>
  );
}

const SupplierHead = ({ s }) => (
  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
    <div><div style={{ fontWeight: 800, fontSize: 15 }}>{s.name}</div><div className="tiny muted">{s.distance} miles · {s.address}</div></div>
    <Icon name="store" />
  </div>
);
export function Suppliers() {
  return (
    <>
      <div className="app-header">
        <button className="icon-btn" onClick={() => A.goto('mInventory')} aria-label="Back"><Icon name="back" /></button>
        <div><div className="htitle">Suppliers</div><div className="hsub">Nearby electrical supply stores</div></div>
      </div>
      <div className="content no-nav">
        <div style={{ height: 14 }} />
        {SUPPLIERS.map((s) => <div className="supplier-card" key={s.name}><SupplierHead s={s} /><div className="srow"><span>Phone</span><b>{s.phone}</b></div></div>)}
        <div className="section-pad"><div className="tiny muted">Open an order and tap "Find suppliers" to compare estimated availability and pricing for that order's materials.</div></div>
      </div>
    </>
  );
}

export function History() {
  const done = companyOrders(ui.currentUser).filter((o) => ['Completed', 'Shipped'].indexOf(o.status) !== -1).sort((a, b) => b.createdAt - a.createdAt);
  return (
    <>
      <div className="app-header">
        <button className="icon-btn" onClick={() => A.goto('mOrders')} aria-label="Back"><Icon name="back" /></button>
        <div><div className="htitle">History</div><div className="hsub">{plural(done.length, 'completed order')}</div></div>
      </div>
      <div className="content no-nav">
        <div style={{ height: 12 }} />
        {done.length ? done.map((o) => <ManagerOrderCard key={o.id} o={o} />) : <Empty icon="history" title="No completed orders yet" />}
      </div>
    </>
  );
}

export function WarehouseProfile() {
  const u = ui.currentUser;
  const company = COMPANIES.find((c) => c.id === u.companyId);
  return (
    <>
      <div className="app-header"><div className="htitle">Profile</div></div>
      <div className="content section-pad">
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 22 }}>
          <div className="avatar" style={{ width: 56, height: 56, fontSize: 18 }}>{initials(u.name)}</div>
          <div><div style={{ fontWeight: 800, fontSize: 17 }}>{u.name}</div><div className="muted small">{u.title}</div></div>
        </div>
        <div className="info-card">
          <div className="spec-row"><span className="k">Work area</span><span className="v">Warehouse</span></div>
          <div className="spec-row"><span className="k">Role</span><span className="v">{u.title}</span></div>
          <div className="spec-row"><span className="k">Company</span><span className="v">{company ? company.name : '\u2014'}</span></div>
          <div className="spec-row"><span className="k">Email</span><span className="v">{u.email}</span></div>
          <div className="spec-row"><span className="k">Phone</span><span className="v">{u.phone}</span></div>
          <div className="spec-row" style={{ borderBottom: 'none' }}><span className="k">PIN</span><span className="v">••••</span></div>
        </div>
        {u.baseRole === 'warehouse_worker' ? <div className="tiny muted" style={{ marginTop: 10 }}>Warehouse Worker access is limited to picking, packing, and viewing inventory.</div> : null}
        <Preferences />
        <div style={{ height: 24 }} />
        <button className="btn btn-danger" onClick={A.logout}><Icon name="logout" /> Log out</button>
      </div>
      <WarehouseNav active="profile" />
    </>
  );
}

/* ---------------- sheets ---------------- */
function ChecklistLine({ o, it, canPick }) {
  const p = getProduct(it.productId);
  if (!p) return null;
  const brand = brandOf(p, it.brandIdx || 0);
  const toggle = () => W.toggleItemCollected(o.id, it.productId, it.brandIdx || 0);
  if (it.collected) {
    return (
      <button className="check-item" onClick={canPick ? toggle : undefined} style={canPick ? undefined : { cursor: 'default' }}>
        <span className="checkbox on"><Icon name="check" /></span>
        <div className="thumb check-thumb"><ProductImage p={p} key={p.id} /></div>
        <span style={{ flex: 1 }}>
          <span className="ciname done" style={{ display: 'block' }}>{p.name}</span>
          <span className="ciqty" style={{ display: 'block' }}><b>{it.qty} {p.unit}</b> · {p.size || ''} · {brand.mfr}</span>
        </span>
      </button>
    );
  }
  if ((it.shortQty || 0) > 0) {
    return (
      <div className="check-item" style={{ cursor: 'default' }}>
        <span className="checkbox" style={{ background: 'var(--warning-bg)', borderColor: 'var(--warning)', color: 'var(--warning)' }}><Icon name="alert" /></span>
        <div className="thumb check-thumb"><ProductImage p={p} key={p.id} /></div>
        <span style={{ flex: 1 }}>
          <span className="ciname" style={{ display: 'block' }}>{p.name}</span>
          <span className="ciqty" style={{ display: 'block' }}><b style={{ color: 'var(--warning)' }}>Short {it.shortQty} {p.unit}</b> · packed {it.packedQty || 0} of {it.qty} {p.unit}</span>
        </span>
      </div>
    );
  }
  const avail = availableQty(it.productId);
  const need = <span className="ciqty" style={{ display: 'block' }}>Need <b>{it.qty} {p.unit}</b> · {avail} available · {p.size || ''}</span>;
  if (avail >= it.qty && canPick) {
    return (
      <button className="check-item" style={{ flexWrap: 'wrap' }} onClick={toggle}>
        <span className="checkbox"><Icon name="check" /></span>
        <div className="thumb check-thumb"><ProductImage p={p} key={p.id} /></div>
        <span style={{ flex: 1, minWidth: 160 }}><span className="ciname" style={{ display: 'block' }}>{p.name}</span>{need}</span>
        <div style={{ width: '100%' }}><LocationBlock productId={it.productId} /></div>
      </button>
    );
  }
  return (
    <div className="check-item" style={{ cursor: 'default', flexWrap: 'wrap' }}>
      <span className="checkbox" style={{ opacity: 0.35 }}><Icon name="check" /></span>
      <div className="thumb check-thumb"><ProductImage p={p} key={p.id} /></div>
      <span style={{ flex: 1 }}><span className="ciname" style={{ display: 'block' }}>{p.name}</span>{need}</span>
      {canPick ? <button className="btn-sm btn-secondary" style={{ flexShrink: 0 }} onClick={() => W.markItemShort(o.id, it.productId, it.brandIdx || 0)}>Mark short</button> : null}
    </div>
  );
}

export function OrderDetailSheet() {
  const o = orderById(ui.openOrderId);
  if (!o) return null;
  const u = ui.currentUser;
  const prog = orderProgress(o);
  const canPick = canPickMaterials(u);
  let action = null;
  if (canDispatchOrder(u)) {
    if (o.status === 'Packed') action = <button className="btn btn-primary" onClick={() => W.markReadyToShip(o.id)}>Mark as ready to ship</button>;
    else if (o.status === 'Ready to Ship') action = <button className="btn btn-primary" onClick={() => W.markShipped(o.id)}><Icon name="truck" /> Mark as shipped</button>;
    else if (o.status === 'Shipped') action = <button className="btn btn-primary" onClick={() => W.markCompleted(o.id)}>Mark as completed</button>;
  }
  const fill = prog.pct === 100 && prog.shorted === 0 ? ' complete' : prog.shorted > 0 ? ' warning' : '';
  return (
    <Sheet onClose={W.closeOrder} title={o.id}>
      <div className="section-pad">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14 }}>
          <div><div style={{ fontWeight: 700, fontSize: 18, color: 'var(--ink)' }}>{o.foremanName}</div><div className="muted small">{o.project}</div></div>
          <span className={'badge badge-' + o.priority}>{o.priority}</span>
        </div>
        <OrderTimeline status={o.status} />
        <div className="spec-row" style={{ marginTop: 8 }}><span className="k">Phone</span><span className="v">{o.phone}</span></div>
        <div className="spec-row"><span className="k">Needed by</span><span className="v">{fmtNeeded(o.neededBy)}</span></div>
        <div className="spec-row" style={{ borderBottom: 'none' }}><span className="k">Created</span><span className="v">{relTime(o.createdAt)}</span></div>
        {o.notes ? <div className="info-card" style={{ marginTop: 14 }}><div className="tiny muted" style={{ fontWeight: 700 }}>Notes</div><div className="small" style={{ marginTop: 4 }}>{o.notes}</div></div> : null}
      </div>
      <div className="progress-wrap">
        <div className="progress-top"><span>{prog.shorted > 0 ? 'Materials processed' : 'Materials collected'}</span><span>{prog.done} of {prog.total} · {prog.pct}%</span></div>
        <div className="progress-bar"><div className={'progress-fill' + fill} style={{ width: prog.pct + '%' }} /></div>
        {prog.shorted > 0 ? <div className="tiny" style={{ color: 'var(--warning)', fontWeight: 700, marginTop: 6 }}>{plural(prog.shorted, 'item')} short — not a complete pack</div> : null}
      </div>
      {o.items.map((it) => <ChecklistLine key={it.productId + '#' + (it.brandIdx || 0)} o={o} it={it} canPick={canPick} />)}
      {canSourceMaterials(u) || action ? (
        <div className="section-pad" style={{ marginTop: 6 }}>
          {canSourceMaterials(u) ? <button className="btn btn-secondary" style={{ marginBottom: 10 }} onClick={() => W.findSuppliers(o.id)}><Icon name="store" /> Find suppliers</button> : null}
          {action}
        </div>
      ) : null}
    </Sheet>
  );
}

const seededRandom = (seed) => { const x = Math.sin(seed) * 10000; return x - Math.floor(x); };
export function SupplierSheet() {
  const o = orderById(ui.supplierOrderId);
  if (!o) return null;
  const total = o.items.length;
  const units = o.items.reduce((sum, it) => sum + it.qty, 0);
  return (
    <Sheet onClose={W.closeSuppliers} title={'Suppliers for ' + o.id}>
      <div className="section-pad" style={{ paddingTop: 0, paddingBottom: 0 }}>
        <div className="tiny muted">Estimates are illustrative — connect a live supplier feed to replace these with real quotes.</div>
      </div>
      <div style={{ height: 14 }} />
      {SUPPLIERS.map((s, idx) => {
        const seed = (o.id.charCodeAt(o.id.length - 1) + 1) * (idx + 3) * 7.13;
        const avail = Math.max(1, Math.round(total * (0.75 + seededRandom(seed) * 0.25)));
        const est = Math.round((units * (18 + seededRandom(seed + 1) * 14)) / 8);
        return (
          <div className="supplier-card" key={s.name}>
            <SupplierHead s={s} />
            <div className="srow"><span>Estimated availability</span><b>{avail} / {total} items</b></div>
            <div className="srow"><span>Estimated total</span><b>{money(est)}</b></div>
            <div className="srow"><span>Phone</span><b>{s.phone}</b></div>
          </div>
        );
      })}
      <div style={{ height: 8 }} />
    </Sheet>
  );
}
