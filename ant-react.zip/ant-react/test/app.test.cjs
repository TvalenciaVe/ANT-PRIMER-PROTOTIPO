/* ANT end-to-end tests: bundles the real app, loads it in a simulated
   browser (jsdom), and drives it by tapping the same buttons a user would.
   Run with:  npm test  */
const path = require('path');
const { buildSync } = require('esbuild');
const { JSDOM } = require('jsdom');

const bundle = buildSync({
  entryPoints: [path.join(__dirname, 'entry.jsx')], bundle: true, format: 'iife', write: false,
  loader: { '.css': 'empty' }, jsx: 'automatic', define: { 'process.env.NODE_ENV': '"production"' }, logLevel: 'error',
}).outputFiles[0].text;

let pass = 0, fail = 0; const errors = [];
const check = (label, cond) => { if (cond) pass++; else { fail++; console.log('  FAIL -', label); } };
const wait = (ms) => new Promise((r) => setTimeout(r, ms));

function boot(saved) {
  const dom = new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>',
    { runScripts: 'outside-only', pretendToBeVisual: true, url: 'http://localhost/' });
  const W = dom.window;
  W.confirm = () => true;
  W.addEventListener('error', (e) => errors.push(e.message));
  if (saved) W.localStorage.setItem('ant_prototype_data_v1', saved);
  W.eval(bundle);
  return W;
}

(async () => {
  let W = boot(); await wait(80);
  let { A, ui, db, C } = W.__ANT;
  const html = () => W.document.getElementById('root').innerHTML;
  const byId = (id) => W.document.getElementById(id);
  async function click(text, index = 0) {
    const matches = [...W.document.querySelectorAll('button')].filter((b) => b.textContent.trim().includes(text));
    if (!matches[index]) throw new Error('No button containing: ' + text);
    matches[index].dispatchEvent(new W.MouseEvent('click', { bubbles: true }));
    await wait(15);
  }
  async function type(el, value) {
    const proto = el.tagName === 'TEXTAREA' ? W.HTMLTextAreaElement.prototype : W.HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, value);
    el.dispatchEvent(new W.Event('input', { bubbles: true }));
    await wait(5);
  }
  async function login(team, name, pin) {
    if (ui.currentUser) { A.logout(); await wait(15); }
    await click(team === 'field' ? "I'm on the Field Team" : "I'm on the Warehouse Team");
    await click(name);
    for (const d of pin) await click(d);
    await wait(15);
  }
  const newest = () => db.ORDERS.slice().sort((a, b) => parseInt(b.id.slice(4), 10) - parseInt(a.id.slice(4), 10))[0];
  async function sendCurrentCart(priority) {
    A.goto('fOrderForm'); await wait(10);
    if (priority) await click(priority);
    await click('Review request'); await click('Send request'); await wait(550);
    return newest();
  }

  console.log('Login');
  await click("I'm on the Field Team"); await click('Carlos');
  for (const d of '4829') await click(d);
  check('Wrong PIN is rejected', html().includes('Incorrect PIN'));
  await wait(700);
  for (const d of '4827') await click(d);
  await wait(15);
  check('Correct PIN opens Field Home', ui.screen === 'fHome');
  check('Current project shows role', html().includes('7 Fairfield Rd') && html().includes('cpr-label">Foreman<'));
  check('Home shows 12 category groups', (html().match(/cat-row-label/g) || []).length === 12);

  console.log('Search and catalog');
  const search = byId('home-search-input'); search.setAttribute('data-mark', 'same');
  for (const v of ['1', '19', '190', '1900']) await type(byId('home-search-input'), v);
  check('Typing keeps the same search input (keyboard stays open)', byId('home-search-input').getAttribute('data-mark') === 'same');
  const expect = { '1900': 'pf-box-4sq', redhead: 'pf-antishort', smurf: 'cn-family-ent', romex: 'pf-nmb', greenfield: 'pf-fmc',
    Polaris: 'pf-polaris', LB: 'pf-cb-lb', '3/4 EMT connector': 'pf-emt-connector', '1 inch EMT coupling': 'pf-emt-coupling',
    '12 black THHN': 'pf-thhn', '12/2 MC': 'pf-mc', '20 amp GFCI': 'pf-rcpt-gfci', '2 pole 30 amp breaker': 'pf-breaker',
    '3/4 ground bushing': 'pf-groundbushing', '3/8 threaded rod': 'pf-rod', '4 square mud ring': 'pf-mudring' };
  Object.keys(expect).forEach((q) => check('Search "' + q + '" ranks the right family first', C.searchProducts(q)[0].id === expect[q]));
  await click('1900 Box');
  check('1900 box suggests Mud Ring and Ground Screw', html().includes('Frequently used with') && html().includes('Mud Ring') && html().includes('Ground Screw'));
  A.closeFamily(); A.openFamily('pf-breaker'); await wait(10);
  check('Breaker series waits for a manufacturer', html().includes('Choose Manufacturer first'));
  await click('Square D');
  check('Square D offers only Square D series', html().includes('QO (Plug-On)') && !html().includes('BR (Plug-On)'));
  A.closeFamily(); A.clearSearch(); await wait(10);

  console.log('Foreman: full material request');
  await type(byId('home-search-input'), '12 black thhn');
  await click('THHN / THWN-2 Copper');
  check('Search pre-selected #12 and Black', ui.modalFamilySelection.gauge === '#12' && ui.modalFamilySelection.color === 'Black');
  await click('Stranded'); await click('ROLL');
  check('"You are requesting" summary is shown', html().includes('#12 Black Stranded THHN'));
  await click('Add to material request');
  check('Confirmation includes the configuration (no empty "()")', ui.toast.includes('ROLL') && !ui.toast.includes('()'));
  await type(byId('home-search-input'), '3/4 emt connector');
  await click('EMT Set-Screw Connector');
  check('Add stays disabled until every required option is chosen', W.document.querySelector('.sheet .btn-primary').disabled === true);
  await click('Standard');
  await type(byId('family-qty'), '25');
  await click('Add to material request');
  A.clearSearch(); await wait(10);
  await click('Add'); // quick add from Recently Used
  check('Cart has 3 distinct lines', ui.cart.length === 3);
  await click('View material request');
  const qty = W.document.querySelector('.qty-stepper-sm input'); qty.setAttribute('data-mark', 'q');
  await type(qty, '2');
  check('Cart quantity edits keep the same input', W.document.querySelector('.qty-stepper-sm input').getAttribute('data-mark') === 'q');
  await click('Continue');
  check('Needed By defaults to today', byId('needed-date').value.length === 10);
  await type(byId('order-notes'), 'Deliver to gate 3');
  await click('High');
  await click('Review request');
  check('Review sheet opens', html().includes('Send material request?'));
  const count = db.ORDERS.length;
  await click('Send request'); await wait(550);
  const ord = newest();
  check('Order submitted, cart cleared, back on Home', db.ORDERS.length === count + 1 && ui.cart.length === 0 && ui.screen === 'fHome');
  check('Order keeps priority, notes and configured snapshots', ord.priority === 'High' && ord.notes === 'Deliver to gate 3' && ord.items.every((i) => 'configured' in i));
  check('Order keeps the ROLL unit', ord.items.some((i) => i.productId.endsWith('~ROLL') && i.configured.unit === 'ROLL'));

  console.log('My Orders, Reorder, Job Kits');
  await click('Orders');
  check('My Orders lists the order', html().includes(ord.id));
  await click('Reorder');
  check('Reorder restores identical lines', ui.screen === 'fCart' && ui.cart.length === ord.items.length &&
    ui.cart.every((c, i) => c.productId === ord.items[i].productId && c.qty === ord.items[i].qty));
  ui.cart = []; A.fNavTo('orders', 'fMyOrders'); await wait(10);
  await click('Save as Job Kit');
  await type(byId('savekit-name'), 'Gate 3 Kit');
  await click('Save kit');
  check('Order saved as a personal Job Kit', db.JOB_KITS.some((k) => k.name === 'Gate 3 Kit' && k.type === 'Personal'));
  A.goto('fJobKits'); await wait(10);
  check('Suggested materials are labeled as not AI', html().includes('a simple history rule, not AI'));
  await click('Panel Installation');
  await click('Add kit to material request');
  check('Company kit added to the request', ui.screen === 'fCart' && ui.cart.length > 0);
  ui.cart = []; A.goto('fCreateKit'); await wait(10);
  await type(byId('nk-name'), 'Rough-In Test');
  await type(byId('nk-search-input'), 'mud ring');
  await click('Choose');
  check('Configure sheet opens in kit mode', html().includes('Add to kit'));
  await click('1-Gang'); await click('1/2"'); await click('4" Square');
  await click('Add to kit'); await click('Save kit');
  check('Create Job Kit saves a configured item', db.JOB_KITS.some((k) => k.name === 'Rough-In Test' && k.materials[0].productId.startsWith('pf-mudring::')));

  console.log('Projects and team');
  A.fNavTo('projects', 'fProjects'); await wait(10);
  await click('Open project');
  for (const tab of ['Materials', 'Orders', 'Deliveries', 'Team', 'Overview']) await click(tab);
  check('Workspace renders every tab', ui.screen === 'fProjectWorkspace' && html().includes('Recent activity'));
  A.goto('fAddProject'); await wait(10);
  await type(byId('ap-name'), '7 Fairfield Rd'); await type(byId('ap-address'), '1 Test St');
  await click('Create project');
  check('Duplicate project warning appears', !!ui.duplicateWarning);
  await click('Create anyway');
  const proj = db.PROJECTS[db.PROJECTS.length - 1];
  check('Project created with the Foreman membership', db.MEMBERSHIPS.some((m) => m.projectId === proj.id && m.userId === ui.currentUser.id && m.projectRole === 'Foreman'));
  await click('Team'); await click('Add team member');
  const line = [...W.document.querySelectorAll('.sheet .checkline')].find((l) => /Journeyman|Apprentice/.test(l.textContent));
  line.querySelector('input').dispatchEvent(new W.MouseEvent('click', { bubbles: true })); await wait(10);
  await click('Add to project');
  const member = db.MEMBERSHIPS.find((m) => m.projectId === proj.id && m.userId !== ui.currentUser.id);
  check('Member added as View Only', member && member.permissionLevel === 'viewer');
  await click('Can Request Materials');
  check('Permission change asks for confirmation', !!ui.permissionChangeConfirm);
  await click('Give access');
  check('Permission changed without duplicating the membership', member.permissionLevel === 'can_edit' &&
    db.MEMBERSHIPS.filter((m) => m.projectId === proj.id && m.userId === member.userId && m.active).length === 1);

  console.log('Journeyman and Apprentice permissions');
  await login('field', 'John Martinez', '2211');
  A.selectProject('7 Fairfield Rd'); await wait(10);
  check('Journeyman can request on 7 Fairfield Rd', html().includes('Journeyman · Can Request Materials'));
  A.selectProject('12 Lincoln Ave'); await wait(10);
  check('Journeyman is View Only on 12 Lincoln Ave', html().includes('Journeyman · View Only'));
  A.openFamily('pf-thhn'); A.selectFamilyVariant('gauge', '#12'); A.selectFamilyVariant('color', 'Black'); A.selectFamilyVariant('conductor', 'Stranded'); await wait(10);
  check('View Only: Add button is disabled', W.document.querySelector('.sheet .btn-primary').disabled === true);
  A.addFamilyToCart(); await wait(10);
  check('View Only: adding is refused even when called directly', ui.cart.length === 0);
  A.closeFamily();
  ui.cart = [{ productId: 'wc1', qty: 5, brandIdx: 0 }];
  const n0 = db.ORDERS.length; A.goto('fOrderForm'); A.sendOrder(); await wait(550);
  check('View Only: submitting is refused even with a forced cart', db.ORDERS.length === n0);
  ui.cart = [];

  console.log('Warehouse Manager: pack, shortage, dispatch');
  await login('warehouse', 'Ana', '0000');
  check('Manager home shows incoming requests', ui.screen === 'mHome' && html().includes('Incoming requests'));
  const legacy = ord.items.find((i) => !i.productId.includes('::'));
  db.INVENTORY[legacy.productId].qty = 0;
  A.openOrder(ord.id); await wait(10);
  await click('Mark short');
  check('Shortage recorded; progress shows the warning, not a clean pack',
    legacy.shortQty > 0 && html().includes('short — not a complete pack') && html().includes('progress-fill warning'));
  let guard = 0;
  while (ord.items.some((i) => !i.collected && !(i.shortQty > 0)) && guard++ < 5) {
    const open = [...W.document.querySelectorAll('.sheet button.check-item')].find((b) => b.querySelector('.checkbox:not(.on)'));
    open.dispatchEvent(new W.MouseEvent('click', { bubbles: true })); await wait(10);
  }
  check('All lines resolved: order is Packed', ord.status === 'Packed');
  const rollLine = ord.items.find((i) => i.productId.endsWith('~ROLL'));
  check('Warehouse sees the exact configuration and unit (' + rollLine.qty + ' ROLL)',
    html().includes('<b>' + rollLine.qty + ' ROLL</b>') && html().includes('#12 · Black · Stranded'));
  A.markShipped(ord.id); await wait(10);
  check('Skipping a step (Packed -> Shipped) is refused', ord.status === 'Packed');
  await click('Mark as ready to ship');
  await click('Mark as shipped');
  check('Packed -> Ready to Ship -> Shipped', ord.status === 'Shipped' && !!ord.shippedAt);
  await click('Find suppliers');
  check('Supplier estimates open', html().includes('Estimates are illustrative'));
  A.closeSuppliers();
  A.goto('mInventory'); await wait(10);
  check('Restock shows the shortage', html().includes('Restock') && html().includes('Short '));
  await type(byId('inv-search-input'), 'thhn');
  check('Inventory search finds the configured THHN stock', html().includes('#12 · Black · Stranded'));
  const inv = W.document.querySelector('#inv-body .qty-stepper-sm input'); inv.setAttribute('data-mark', 'i');
  await type(inv, '42');
  check('Manager edits stock without losing the input', W.document.querySelector('#inv-body .qty-stepper-sm input').getAttribute('data-mark') === 'i');
  A.openOrder(ord.id); await wait(10); await click('Mark as completed');
  check('Shipped -> Completed', ord.status === 'Completed');

  console.log('Warehouse Worker: Packing Mode');
  await login('field', 'Carlos', '4827');
  A.openFamily('pf-ground-screw'); A.selectFamilyVariant('size', '10-32 x 3/8"'); await wait(5); A.addFamilyToCart();
  A.openFamily('pf-lever'); A.selectFamilyVariant('ports', '3-Port'); await wait(5); A.addFamilyToCart();
  const ord2 = await sendCurrentCart();
  await login('warehouse', 'Michael Torres', '8899');
  check('Worker home lists orders to pack', ui.screen === 'whHome' && html().includes('Start packing'));
  check('Worker cannot edit stock', (() => { const before = JSON.stringify(db.INVENTORY); A.setInventoryQty('wc1', 1); return JSON.stringify(db.INVENTORY) === before; })());
  A.startPackingMode(ord2.id); await wait(10);
  check('Packing Mode shows Need, Location and Available', html().includes('pm-stats') && html().includes('Available'));
  const first = ui.packingIndex;
  await click('Skip for now');
  check('Skip moves to the next material', ui.packingIndex !== first);
  await click('Pack ');
  check('Pack collects the current material', ord2.items.some((i) => i.collected));
  const rest = ord2.items.find((i) => !i.collected);
  db.INVENTORY[rest.productId] = { qty: 0, location: 'Main Warehouse' };
  ui.packingIndex = ord2.items.indexOf(rest); A.goto('whPackingMode'); await wait(10);
  await click('Mark short');
  check('Packing complete screen appears', html().includes('Packing complete'));
  A.exitPackingMode(); A.openOrder(ord2.id); await wait(10);
  check('Worker has no dispatch or sourcing buttons', !html().includes('Mark as ready to ship') && !html().includes('Find suppliers'));
  A.closeOrder();

  console.log('Delivery confirmation');
  await login('warehouse', 'Ana', '0000');
  A.openOrder(ord2.id); await wait(10);
  await click('Mark as ready to ship'); await click('Mark as shipped'); await click('Mark as completed');
  await login('field', 'Carlos', '4827');
  A.openProjectWorkspace('proj1'); A.setWorkspaceTab('deliveries'); await wait(10);
  check('Deliveries tab asks for confirmation', html().includes('Needs confirmation'));
  await click('Did everything arrive?');
  await click('Something is missing');
  await type(W.document.querySelector('#delivery-report-rows input'), '0');
  check('Missing quantity updates live', html().includes('Missing:'));
  await click('Submit');
  check('Missing items recorded as a delivery issue', db.ORDERS.some((o) => o.fieldConfirmed && o.deliveryIssues && o.deliveryIssues.length));
  await click('Did everything arrive?');
  await click('Yes, everything arrived');
  check('"Everything arrived" confirmation recorded', db.ORDERS.filter((o) => o.fieldConfirmed && !o.deliveryIssues).length >= 1);

  console.log('Preferences and reload');
  A.fNavTo('profile', 'fProfile'); await wait(10);
  await click('Español');
  check('Spanish interface (nav shows "Inicio")', html().includes('Inicio'));
  await click('Grande');
  check('Large text applied', byId('root').classList.contains('text-large'));
  const saved = W.localStorage.getItem('ant_prototype_data_v1');
  W = boot(saved); await wait(80);
  ({ A, ui, db, C } = W.__ANT);
  const again = db.ORDERS.find((o) => o.id === ord.id);
  check('After reload: order is still there', !!again);
  check('After reload: ROLL line still resolves as ROLL', C.getProduct(again.items.find((i) => i.productId.endsWith('~ROLL')).productId).unit === 'ROLL');
  check('After reload: new project persisted', db.PROJECTS.some((p) => p.address === '1 Test St'));
  check('After reload: language and text size persisted', JSON.parse(saved).prefs.language === 'es' && W.document.getElementById('root').classList.contains('text-large'));

  check('No runtime errors', errors.length === 0);
  if (errors.length) console.log(errors.slice(0, 5));
  console.log('\n' + pass + ' passed, ' + fail + ' failed');
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error('TEST ERROR', e.stack); process.exit(1); });
