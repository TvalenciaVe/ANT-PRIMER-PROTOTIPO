// Test-only entry: exposes internals so the simulated browser can drive and inspect the app.
import * as Core from '../src/lib/actions.js';
import * as F from '../src/lib/actionsField.js';
import * as P from '../src/lib/actionsProjects.js';
import * as Wh from '../src/lib/actionsWarehouse.js';
import { ui } from '../src/lib/store.js';
import { db } from '../src/lib/db.js';
import * as C from '../src/lib/catalog.js';
window.__ANT = { A: { ...Core, ...F, ...P, ...Wh }, ui, db, C };
import '../src/main.jsx';
