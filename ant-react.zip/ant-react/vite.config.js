import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
// base './' makes the built app work on GitHub Pages under any repo name.
// The 324-family catalog is intentionally bundled with the app, so the bundle is larger than Vite's default hint.
export default defineConfig({ plugins: [react()], base: './', build: { chunkSizeWarningLimit: 1200 } });
